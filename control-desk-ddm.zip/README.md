# DDM Control Desk

Dashboard de Control Desk para call center: performance de agentes, controle
de pausas (NR17), dimensionamento e canais/rotas.

Projeto 100% autônomo — sem dependência de nenhuma plataforma externa. Login
próprio (usuário/senha), banco MySQL, sem serviços de terceiros.

## Rodando com Docker (recomendado)

Pré-requisito: Docker + Docker Compose instalados.

```bash
cp .env.example .env
# edite o .env e troque as senhas/segredo antes de subir em produção
docker compose up -d --build
```

Isso sobe dois containers: `mysql` (banco) e `app` (servidor + frontend).
Na primeira execução, as migrations do banco são aplicadas automaticamente e
um usuário admin é criado com as credenciais definidas no `.env`
(`DEFAULT_ADMIN_USER` / `DEFAULT_ADMIN_PASSWORD` — padrão: `christyan` / `ddm123`).

Acesse em `http://localhost:3000`.

Para parar: `docker compose down` (os dados do banco persistem no volume
`mysql_data`; use `docker compose down -v` para descartar tudo).

## Rodando sem Docker (banco externo)

Pré-requisitos: Node.js 22+, pnpm, e uma instância MySQL acessível.

```bash
pnpm install
cp .env.example .env
# edite .env: defina DATABASE_URL apontando pro seu MySQL, e JWT_SECRET
pnpm db:push       # cria as tabelas
pnpm dev           # ambiente de desenvolvimento (http://localhost:3000)
# ou, para produção:
pnpm build
pnpm start
```

## Variáveis de ambiente

| Variável | Obrigatória | Descrição |
|---|---|---|
| `DATABASE_URL` | Sim (fora do Docker) | Connection string MySQL. No Docker Compose já vem configurada automaticamente. |
| `JWT_SECRET` | Sim | Segredo usado para assinar o cookie de sessão. Gere com `openssl rand -hex 32`. |
| `DEFAULT_ADMIN_USER` | Não (padrão `christyan`) | Login do usuário admin criado na primeira execução. |
| `DEFAULT_ADMIN_PASSWORD` | Não (padrão `ddm123`) | Senha do usuário admin criado na primeira execução (fica salva como hash no banco). |
| `PORT` | Não (padrão `3000`) | Porta do servidor. |

O admin padrão só é criado se a tabela `users` estiver vazia — depois disso,
gerencie usuários direto no banco.

## Stack

- Frontend: React + Vite + Tailwind + tRPC
- Backend: Express + tRPC + Drizzle ORM
- Banco: MySQL 8
- Autenticação: cookie de sessão (JWT) assinado localmente, senha com hash bcrypt

## O que existe hoje

- **Painel de Agentes (AgentDay)** — visão em tempo real: ociosidade, tempo
  logado, cruzamento com dimensionamento.
- **Controle de Pausas (NR17)** — distribuição por motivo, ranking de
  ofensores, limites de tempo configuráveis em runtime (tela Configurações).
- **Campanhas** e **Tabulações/Disposition** — métricas por agente/campanha.
- **Dimensionamento** — importação de planilha Excel (mapeamento de colunas
  por cabeçalho, não por posição fixa).
- **Canais & Rotas** — uso por rota/campanha.
- **Relatório executivo** — exportação em PNG.
- **Login local** — usuário/senha, sem OAuth externo.

## Em aberto / próximos passos

- Gestão de usuários pela UI (hoje só via banco).
- Reindexação (índices em `sessionId`/`agente`/`login` nas tabelas de
  registro, hoje sem índice).
- Testes automatizados cobrem parsers e logout; routers de métricas ainda
  sem cobertura de teste.
