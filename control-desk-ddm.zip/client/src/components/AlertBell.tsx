import { trpc } from "@/lib/trpc";
import { useDashboard } from "@/contexts/DashboardContext";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Bell, AlertOctagon, Clock, ShieldAlert } from "lucide-react";

// Sininho de alerta — sem e-mail/Slack (evita precisar de credencial SMTP),
// só avisa dentro do próprio app quando tem algo que provavelmente merece
// atenção hoje (zerados, pausas excedidas). Atualiza a cada 5 min.
export default function AlertBell() {
  const { setActiveSection } = useDashboard();
  const { data } = trpc.dashboard.getAlertsSummary.useQuery(undefined, {
    refetchInterval: 5 * 60_000,
  });

  const total =
    (data?.zeradosCount ?? 0) +
    (data?.pausasExcedidasCount ?? 0) +
    (data?.foraHorarioCount ?? 0);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="relative p-2 text-muted-foreground hover:text-foreground transition-colors">
          <Bell className="w-4 h-4" />
          {total > 0 && (
            <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-1">
              {total > 99 ? "99+" : total}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="p-3 border-b border-border">
          <p className="text-sm font-semibold text-foreground">
            Alertas de hoje
          </p>
          <p className="text-xs text-muted-foreground">
            {data?.referenceDate || "—"}
          </p>
        </div>
        {!data?.temDadosHoje ? (
          <p className="text-xs text-muted-foreground p-4 text-center">
            Nenhum dado de hoje importado/sincronizado ainda.
          </p>
        ) : total === 0 ? (
          <p className="text-xs text-muted-foreground p-4 text-center">
            Nada fora do esperado até agora.
          </p>
        ) : (
          <div className="max-h-72 overflow-y-auto">
            {(data?.zeradosCount ?? 0) > 0 && (
              <button
                onClick={() => setActiveSection("agentday")}
                className="w-full text-left p-3 border-b border-border/50 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-2 text-xs font-semibold text-red-400">
                  <AlertOctagon className="w-3.5 h-3.5" />
                  {data!.zeradosCount} agente(s) zerado(s)
                </div>
                <p className="text-[11px] text-muted-foreground mt-1">
                  {data!.zerados
                    .slice(0, 3)
                    .map(z => z.agente)
                    .join(", ")}
                  {data!.zeradosCount > 3 && ` +${data!.zeradosCount - 3}`}
                  {" — ver em Performance em Tempo Real"}
                </p>
              </button>
            )}
            {(data?.pausasExcedidasCount ?? 0) > 0 && (
              <button
                onClick={() => setActiveSection("reasonagent")}
                className="w-full text-left p-3 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                  <Clock className="w-3.5 h-3.5" />
                  {data!.pausasExcedidasCount} pausa(s) excedida(s)
                </div>
                <p className="text-[11px] text-muted-foreground mt-1">
                  Ver detalhes em TEMPOS
                </p>
              </button>
            )}
            {(data?.foraHorarioCount ?? 0) > 0 && (
              <button
                onClick={() => setActiveSection("campaignagent")}
                className="w-full text-left p-3 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-2 text-xs font-semibold text-red-400">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  {data!.foraHorarioCount} ligação(ões) fora do horário
                </div>
                <p className="text-[11px] text-muted-foreground mt-1">
                  Ver em Performance por Campanha → Conformidade
                </p>
              </button>
            )}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
