import { useState, type FormEvent } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LogIn } from "lucide-react";

// Bloqueia o acesso ao painel para quem não está autenticado. O backend
// já exige login em todos os endpoints (protectedProcedure) — este
// componente evita que a tela fique quebrada mostrando erros de tRPC e
// mostra, em vez disso, um formulário de login (usuário + senha locais,
// sem depender de nenhum provedor OAuth externo).
export default function RequireAuth({
  children,
}: {
  children: React.ReactNode;
}) {
  const { loading, isAuthenticated, login, loginLoading, loginError } =
    useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [localError, setLocalError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLocalError(null);
    try {
      await login(username, password);
    } catch (err: any) {
      setLocalError(err?.message || "Usuário ou senha inválidos.");
    }
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-4 bg-background px-4">
        <img
          src="/assets/logo-ddm.png"
          alt="DDM"
          className="w-14 h-14 rounded-xl object-cover"
        />
        <div className="text-center mb-2">
          <h1 className="text-lg font-semibold text-foreground">
            DDM Control Desk
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Faça login para acessar o painel.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="w-full max-w-xs flex flex-col gap-3"
        >
          <Input
            placeholder="Usuário"
            value={username}
            onChange={e => setUsername(e.target.value)}
            autoComplete="username"
            autoFocus
          />
          <Input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={e => setPassword(e.target.value)}
            autoComplete="current-password"
          />
          {(localError || loginError) && (
            <p className="text-xs text-red-400">
              {localError || loginError?.message}
            </p>
          )}
          <Button
            type="submit"
            disabled={loginLoading}
            className="gap-2 w-full"
          >
            <LogIn className="w-4 h-4" />
            {loginLoading ? "Entrando..." : "Entrar"}
          </Button>
        </form>
      </div>
    );
  }

  return <>{children}</>;
}
