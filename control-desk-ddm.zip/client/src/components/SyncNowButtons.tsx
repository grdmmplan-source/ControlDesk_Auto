import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { RefreshCw, Loader2 } from "lucide-react";
import { toast } from "sonner";

type SyncKind = "discagem" | "pausas" | "agentday" | "tabulacoes" | "mailing";

const LABELS: Record<SyncKind, string> = {
  discagem: "Discagem",
  pausas: "Pausas",
  agentday: "Performance",
  tabulacoes: "Tabulações",
  mailing: "Mailing",
};

// Botão(ões) de "Sincronizar agora" pra usar direto na tela de cada
// automação — sem precisar ir pra tela Importar Dados. Some sozinho se a
// sincronização com a OLOS não estiver configurada.
export default function SyncNowButtons({ kinds }: { kinds: SyncKind[] }) {
  const utils = trpc.useUtils();
  const { data: status } = trpc.olosSync.getStatus.useQuery();

  // Chama todos os hooks incondicionalmente (regra do React) e só
  // renderiza os botões pedidos em `kinds`.
  const discagem = trpc.olosSync.syncDiscagemAgora.useMutation({
    onSuccess: r => {
      utils.dashboard.invalidate();
      if (r.success)
        toast.success(
          `Discagem: ${r.totalLinhas.toLocaleString("pt-BR")} linhas (${r.referenceDate})`
        );
      else toast.error(r.message || "Erro ao sincronizar.");
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });
  const pausas = trpc.olosSync.syncPausasAgora.useMutation({
    onSuccess: r => {
      utils.dashboard.invalidate();
      if (r.success)
        toast.success(`Pausas: ${r.totalAgentes} agentes (${r.referenceDate})`);
      else toast.error(r.message || "Erro ao sincronizar.");
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });
  const agentday = trpc.olosSync.syncAgentDayAgora.useMutation({
    onSuccess: r => {
      utils.dashboard.invalidate();
      if (r.success)
        toast.success(
          `Performance: ${r.totalAgentes} agentes (${r.referenceDate})`
        );
      else toast.error(r.message || "Erro ao sincronizar.");
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });
  const tabulacoes = trpc.olosSync.syncTabulacoesAgora.useMutation({
    onSuccess: r => {
      utils.dashboard.invalidate();
      if (r.success)
        toast.success(
          `Tabulações: ${r.totalLinhas.toLocaleString("pt-BR")} linhas (${r.referenceDate})`
        );
      else toast.error(r.message || "Erro ao sincronizar.");
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });
  const mailing = trpc.olosSync.syncMailingAgora.useMutation({
    onSuccess: r => {
      utils.dashboard.invalidate();
      if (r.success)
        toast.success(`Mailing: ${r.totalCampanhas} campanha(s) atualizadas`);
      else toast.error(r.message || "Erro ao sincronizar.");
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const map: Record<SyncKind, { mutate: () => void; isPending: boolean }> = {
    discagem: {
      mutate: () => discagem.mutate({}),
      isPending: discagem.isPending,
    },
    pausas: { mutate: () => pausas.mutate({}), isPending: pausas.isPending },
    agentday: {
      mutate: () => agentday.mutate({}),
      isPending: agentday.isPending,
    },
    tabulacoes: {
      mutate: () => tabulacoes.mutate({}),
      isPending: tabulacoes.isPending,
    },
    mailing: { mutate: () => mailing.mutate({}), isPending: mailing.isPending },
  };

  if (!status?.configured) return null;

  return (
    <div className="flex items-center gap-1.5">
      {kinds.map(k => {
        const m = map[k];
        return (
          <Button
            key={k}
            size="sm"
            variant="outline"
            onClick={m.mutate}
            disabled={m.isPending}
            className="gap-1.5 h-8 text-xs"
          >
            {m.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <RefreshCw className="w-3.5 h-3.5" />
            )}
            {LABELS[k]}
          </Button>
        );
      })}
    </div>
  );
}
