import { useState, useMemo, useRef } from "react";
import { trpc } from "@/lib/trpc";
import SyncNowButtons from "@/components/SyncNowButtons";
import { useDashboard } from "@/contexts/DashboardContext";
import {
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Download,
  Search,
  Phone,
  Target,
  Clock,
  AlertTriangle,
  TrendingUp,
  Award,
  Users,
  Filter,
  LogIn,
  LogOut,
  CheckCircle2,
  XCircle,
  AlertOctagon,
  Copy,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  Legend,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  LabelList,
} from "recharts";
import { toPng } from "html-to-image";
import { toast } from "sonner";

type SortKey =
  | "agente"
  | "chamadasAtendidas"
  | "contatoEfetivo"
  | "tempoLogado"
  | "idleSeg"
  | "tmaSeg"
  | "cpcPct"
  | "tabulacoesSucesso"
  | "tabulacoesSucessoNegocio"
  | "sucessoNegPct"
  | "logins"
  | "pausasImprodutivas";
type SortDir = "asc" | "desc";

function SortIcon({
  col,
  sortKey,
  dir,
}: {
  col: SortKey;
  sortKey: SortKey;
  dir: SortDir;
}) {
  if (col !== sortKey)
    return <ChevronsUpDown className="w-3 h-3 text-muted-foreground/50" />;
  return dir === "asc" ? (
    <ChevronUp className="w-3 h-3 text-primary" />
  ) : (
    <ChevronDown className="w-3 h-3 text-primary" />
  );
}

// Converte HH:MM:SS → segundos
function timeToSec(t: string | null | undefined): number {
  if (!t) return 0;
  const p = t.split(":").map(Number);
  return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : 0;
}

// Formata segundos → HH:MM:SS
function secToHMS(s: number): string {
  if (!s || s <= 0) return "00:00:00";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

// Formata segundos → MM:SS (para Idle e TMA curtos)
function secToMS(s: number): string {
  if (!s || s <= 0) return "00:00";
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

// Calcula quartis (Q1, Q2, Q3) de um array de números
function calcQuartiles(values: number[]): {
  q1: number;
  q2: number;
  q3: number;
} {
  if (values.length === 0) return { q1: 0, q2: 0, q3: 0 };
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  const q2 =
    sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
  const lower = sorted.slice(0, mid);
  const upper =
    sorted.length % 2 === 0 ? sorted.slice(mid) : sorted.slice(mid + 1);
  const q1 = lower.length > 0 ? lower[Math.floor(lower.length / 2)] : sorted[0];
  const q3 =
    upper.length > 0
      ? upper[Math.floor(upper.length / 2)]
      : sorted[sorted.length - 1];
  return { q1, q2, q3 };
}

function getQuartilLabel(
  val: number,
  q1: number,
  q2: number,
  q3: number
): { label: string; color: string; bg: string } {
  if (val >= q3)
    return { label: "Q1", color: "text-emerald-400", bg: "bg-emerald-500/15" };
  if (val >= q2)
    return { label: "Q2", color: "text-blue-400", bg: "bg-blue-500/15" };
  if (val >= q1)
    return { label: "Q3", color: "text-amber-400", bg: "bg-amber-500/15" };
  return { label: "Q4", color: "text-red-400", bg: "bg-red-500/15" };
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-popover border border-border rounded-lg px-3 py-2 shadow-xl text-xs max-w-52">
      <p className="font-semibold text-foreground mb-1 truncate">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.fill || p.color }}>
          {p.name}: {p.value?.toLocaleString?.("pt-BR") ?? p.value}
        </p>
      ))}
    </div>
  );
};

export default function AgentDayPage() {
  const { filters } = useDashboard();
  const utils = trpc.useUtils();
  const [sortKey, setSortKey] = useState<SortKey>("chamadasAtendidas");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [search, setSearch] = useState("");
  const [ufFilter, setUfFilter] = useState("all");
  const [quartilFilter, setQuartilFilter] = useState("all");
  const [turnoFilter, setTurnoFilter] = useState("all");
  const [celulaFilter, setCelulaFilter] = useState("all");
  const [supervisorFilter, setSupervisorFilter] = useState("all");
  const exportRef = useRef<HTMLDivElement>(null);
  const tableExportRef = useRef<HTMLDivElement>(null);
  const loginExportRef = useRef<HTMLDivElement>(null);
  const baixaProducaoExportRef = useRef<HTMLDivElement>(null);
  const [loginCampanhaFilter, setLoginCampanhaFilter] = useState("all");
  const [loginTab, setLoginTab] = useState<"logados" | "nao_logados">(
    "logados"
  );

  const { data: rows = [], isLoading } = trpc.dashboard.getAgentDay.useQuery({
    sessionIds: filters.sessionIds.length > 0 ? filters.sessionIds : undefined,
    agente: filters.agente || undefined,
    uf: filters.uf || undefined,
  });

  const ufs = useMemo(() => {
    const set = new Set(rows.map(r => r.uf).filter(Boolean));
    return Array.from(set).sort() as string[];
  }, [rows]);

  // Listas únicas do dimensionamento
  const turnos = useMemo(() => {
    const set = new Set(rows.map((r: any) => r.turno).filter(Boolean));
    return Array.from(set).sort() as string[];
  }, [rows]);

  const celulas = useMemo(() => {
    const set = new Set(rows.map((r: any) => r.celula).filter(Boolean));
    return Array.from(set).sort() as string[];
  }, [rows]);

  const supervisores = useMemo(() => {
    const set = new Set(rows.map((r: any) => r.supervisorDim).filter(Boolean));
    return Array.from(set).sort() as string[];
  }, [rows]);

  // Filtra BOTs: agentes sem login
  const humanRows = useMemo(
    () => rows.filter(r => r.login && r.login.trim() !== ""),
    [rows]
  );

  // ── Baixa Produção — pensada pra ser DIFERENTE do Quartil (que já
  // ranqueia agente a agente continuamente): aqui o foco é achar ONDE o
  // problema se concentra (célula/campanha ou supervisor), não só listar
  // nomes soltos. Só considera quem já logou pelo menos 30min. ─────────
  const { data: mopAlocacoes } = trpc.mop.getAlocacoes.useQuery();
  function getMopStatus(
    nomeAgente: string,
    celula: string
  ): { alocado: boolean; divergente: boolean; campanhasMop: string[] } {
    const nome = nomeAgente.trim().toUpperCase();
    const minhas = (mopAlocacoes ?? []).filter(
      a => a.operadorNome.trim().toUpperCase() === nome
    );
    if (minhas.length === 0)
      return { alocado: false, divergente: false, campanhasMop: [] };
    const c = celula.trim().toUpperCase();
    const divergente =
      !!c &&
      !minhas.some(
        a =>
          a.campanha.toUpperCase().includes(c) ||
          c.includes(a.campanha.toUpperCase())
      );
    return {
      alocado: true,
      divergente,
      campanhasMop: minhas.map(a => a.campanha),
    };
  }

  const { data: ruidoData } =
    trpc.dashboard.getRuidoPorOrganizacaoHoje.useQuery();
  const ruidoPorOrg = ruidoData?.porOrganizacao ?? [];
  // Match frouxo: célula "Vero" ~ organização "VERO" ou "VERO_PRECHURN" etc
  function getRuidoDaCelula(celula: string): number | null {
    if (!celula) return null;
    const c = celula.trim().toUpperCase();
    const match = ruidoPorOrg.find(
      o =>
        o.organizacao.toUpperCase().includes(c) ||
        c.includes(o.organizacao.toUpperCase())
    );
    return match ? match.pctRuido : null;
  }

  const { data: tendenciaData } =
    trpc.dashboard.getTendenciaSupervisor.useQuery({ dias: 14 });
  const tendenciaChart = (tendenciaData?.porDia ?? []).map(d => ({
    data: d.data.slice(0, 5), // DD/MM, sem o ano, cabe melhor no eixo
    "% Zerados": Number(d.pctZeradosGeral.toFixed(1)),
    "Min. NR17 Excedido": Math.round(d.excedidoSegundosGeral / 60),
  }));

  const { data: baixaProducaoSettings } =
    trpc.dashboard.appSettings.get.useQuery({
      keys: [
        "baixaProducao.tempoMinLogadoMin",
        "baixaProducao.pctZeradosAlerta",
      ],
    });
  const setAppSetting = trpc.dashboard.appSettings.set.useMutation({
    onSuccess: () => {
      utils.dashboard.appSettings.get.invalidate();
      toast.success("Configuração salva.");
    },
  });
  const tempoMinLogadoMin = Number(
    baixaProducaoSettings?.["baixaProducao.tempoMinLogadoMin"] ?? 30
  );
  const pctZeradosAlerta = Number(
    baixaProducaoSettings?.["baixaProducao.pctZeradosAlerta"] ?? 20
  );

  const TEMPO_MIN_SEG = tempoMinLogadoMin * 60;
  const elegiveisBase = useMemo(
    () => humanRows.filter(r => timeToSec(r.tempoLogado) >= TEMPO_MIN_SEG),
    [humanRows]
  );

  const celulasDisponiveis = useMemo(() => {
    const s = new Set(
      elegiveisBase.map(r => (r as any).celula || "Sem célula")
    );
    return Array.from(s).sort();
  }, [elegiveisBase]);

  const [celulasExcluidas, setCelulasExcluidas] = useState<string[]>([]);
  function toggleCelulaExcluida(celula: string) {
    setCelulasExcluidas(prev =>
      prev.includes(celula) ? prev.filter(c => c !== celula) : [...prev, celula]
    );
  }

  // Filtro de supervisor — SEPARADO do de célula, porque uma célula pode
  // ter mais de um supervisor com perfis bem diferentes (ex: Vero tem
  // supervisor de BKO, que fica sempre zerado por natureza da função, e
  // supervisor de discagem normal — excluir a célula inteira esconderia
  // os dois; excluir só o supervisor de BKO resolve sem perder o resto).
  const supervisoresDisponiveis = useMemo(() => {
    const s = new Set(
      elegiveisBase.map(r => (r as any).supervisorDim || "Sem supervisor")
    );
    return Array.from(s).sort();
  }, [elegiveisBase]);

  const [supervisoresExcluidos, setSupervisoresExcluidos] = useState<string[]>(
    []
  );
  function toggleSupervisorExcluido(supervisor: string) {
    setSupervisoresExcluidos(prev =>
      prev.includes(supervisor)
        ? prev.filter(s => s !== supervisor)
        : [...prev, supervisor]
    );
  }

  const baixaProducao = useMemo(() => {
    const elegiveis = elegiveisBase.filter(
      r =>
        !celulasExcluidas.includes((r as any).celula || "Sem célula") &&
        !supervisoresExcluidos.includes(
          (r as any).supervisorDim || "Sem supervisor"
        )
    );

    const zerados = elegiveis
      .filter(r => (r.chamadasAtendidas ?? 0) === 0)
      .sort((a, b) => timeToSec(b.tempoLogado) - timeToSec(a.tempoLogado));

    const mediaGeral =
      elegiveis.length > 0
        ? elegiveis.reduce((s, r) => s + (r.chamadasAtendidas ?? 0), 0) /
          elegiveis.length
        : 0;

    // Agrupa por chave genérica (célula OU supervisor), calcula % zerados
    // e média — ordena pra mostrar primeiro quem tem mais gente zerada.
    function agrupar(chaveFn: (r: (typeof elegiveis)[number]) => string) {
      const grupos = new Map<
        string,
        { total: number; zerados: number; somaChamadas: number }
      >();
      for (const r of elegiveis) {
        const chave = chaveFn(r) || "—";
        const g = grupos.get(chave) || {
          total: 0,
          zerados: 0,
          somaChamadas: 0,
        };
        g.total += 1;
        if ((r.chamadasAtendidas ?? 0) === 0) g.zerados += 1;
        g.somaChamadas += r.chamadasAtendidas ?? 0;
        grupos.set(chave, g);
      }
      return Array.from(grupos.entries())
        .map(([nome, g]) => ({
          nome,
          totalAgentes: g.total,
          zerados: g.zerados,
          pctZerados: g.total > 0 ? (g.zerados / g.total) * 100 : 0,
          mediaChamadas: g.total > 0 ? g.somaChamadas / g.total : 0,
        }))
        .sort(
          (a, b) =>
            b.pctZerados - a.pctZerados || a.mediaChamadas - b.mediaChamadas
        );
    }

    const porCelula = agrupar(r => (r as any).celula || "Sem célula");
    const porSupervisor = agrupar(
      r => (r as any).supervisorDim || "Sem supervisor"
    );

    // ── Baixa Conversão: agente que fala com muita gente (CPC alto) mas
    // fecha pouco acordo/promessa — é baixa produção tanto quanto ficar
    // zerado, só que mais difícil de enxergar (ele "trabalha", só não
    // converte). Só entra quem tem CPC mínimo (senão 1 acordo em 2 CPC
    // dispara a % artificialmente) e fica abaixo de metade da conversão
    // média do grupo elegível. ──────────────────────────────────────────
    const comCpcRelevante = elegiveis.filter(
      r => (r.contatoEfetivo ?? 0) >= 10
    );
    const conversaoMedia =
      comCpcRelevante.length > 0
        ? comCpcRelevante.reduce(
            (s, r) =>
              s +
              (r.contatoEfetivo
                ? (r.tabulacoesSucessoNegocio ?? 0) / r.contatoEfetivo
                : 0),
            0
          ) / comCpcRelevante.length
        : 0;
    const baixaConversao = comCpcRelevante
      .map(r => ({
        ...r,
        pctConversao: r.contatoEfetivo
          ? ((r.tabulacoesSucessoNegocio ?? 0) / r.contatoEfetivo) * 100
          : 0,
      }))
      .filter(r => r.pctConversao < conversaoMedia * 100 * 0.5)
      .sort((a, b) => a.pctConversao - b.pctConversao);

    return {
      zerados,
      mediaGeral,
      porCelula,
      porSupervisor,
      totalElegiveis: elegiveis.length,
      baixaConversao,
      conversaoMediaPct: conversaoMedia * 100,
    };
  }, [elegiveisBase, celulasExcluidas, supervisoresExcluidos]);

  function copiarListaBaixaProducao() {
    const linhas: string[] = [];
    linhas.push(`Baixa Produção — ${new Date().toLocaleDateString("pt-BR")}`);
    linhas.push("");
    if (baixaProducao.zerados.length > 0) {
      linhas.push(`ZERADOS (${baixaProducao.zerados.length}):`);
      baixaProducao.zerados.forEach(r => {
        linhas.push(
          `- ${r.agente} (${(r as any).supervisorDim || "sem supervisor"}) — logado ${r.tempoLogado}, 0 chamadas`
        );
      });
      linhas.push("");
    }
    if (baixaProducao.porSupervisor.length > 0) {
      linhas.push("POR SUPERVISOR (pior primeiro):");
      baixaProducao.porSupervisor.forEach(s => {
        linhas.push(
          `- ${s.nome}: ${s.zerados}/${s.totalAgentes} zerados (${s.pctZerados.toFixed(0)}%), média ${s.mediaChamadas.toFixed(1)} chamadas`
        );
      });
    }
    navigator.clipboard.writeText(linhas.join("\n"));
    toast.success("Lista copiada — cola direto na mensagem pro supervisor.");
  }

  // Calcula quartis baseados em chamadas atendidas
  const quartiles = useMemo(() => {
    const vals = humanRows.map(r => r.chamadasAtendidas ?? 0);
    return calcQuartiles(vals);
  }, [humanRows]);

  // Enriquece cada linha com seu quartil
  const rowsWithQuartil = useMemo(
    () =>
      humanRows.map(r => ({
        ...r,
        _quartil: getQuartilLabel(
          r.chamadasAtendidas ?? 0,
          quartiles.q1,
          quartiles.q2,
          quartiles.q3
        ),
      })),
    [humanRows, quartiles]
  );

  const filtered = useMemo(() => {
    let data = [...rowsWithQuartil];
    if (search)
      data = data.filter(
        r =>
          r.agente?.toLowerCase().includes(search.toLowerCase()) ||
          r.login?.toLowerCase().includes(search.toLowerCase())
      );
    if (ufFilter && ufFilter !== "all")
      data = data.filter(r => r.uf === ufFilter);
    if (quartilFilter && quartilFilter !== "all")
      data = data.filter(r => r._quartil.label === quartilFilter);
    if (turnoFilter && turnoFilter !== "all")
      data = data.filter((r: any) => r.turno === turnoFilter);
    if (celulaFilter && celulaFilter !== "all")
      data = data.filter((r: any) => r.celula === celulaFilter);
    if (supervisorFilter && supervisorFilter !== "all")
      data = data.filter((r: any) => r.supervisorDim === supervisorFilter);
    data.sort((a, b) => {
      const av = (a as any)[sortKey] ?? 0;
      const bv = (b as any)[sortKey] ?? 0;
      if (typeof av === "string" && typeof bv === "string") {
        return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      }
      return sortDir === "asc"
        ? Number(av) - Number(bv)
        : Number(bv) - Number(av);
    });
    return data;
  }, [
    rowsWithQuartil,
    search,
    ufFilter,
    quartilFilter,
    turnoFilter,
    celulaFilter,
    supervisorFilter,
    sortKey,
    sortDir,
  ]);

  // Agrupamento por quartil para os gráficos
  const quartilGroups = useMemo(() => {
    const groups: Record<string, typeof rowsWithQuartil> = {
      Q1: [],
      Q2: [],
      Q3: [],
      Q4: [],
    };
    for (const r of rowsWithQuartil) groups[r._quartil.label].push(r);
    return groups;
  }, [rowsWithQuartil]);

  // Dados para gráfico de barras por quartil (médias)
  const quartilChartData = useMemo(() => {
    return ["Q1", "Q2", "Q3", "Q4"].map(q => {
      const group = quartilGroups[q];
      const n = group.length || 1;
      return {
        quartil: q,
        Chamadas: Math.round(
          group.reduce((s, r) => s + (r.chamadasAtendidas ?? 0), 0) / n
        ),
        CPC: Math.round(
          group.reduce((s, r) => s + (r.contatoEfetivo ?? 0), 0) / n
        ),
        "Tab. Sucesso": Math.round(
          group.reduce((s, r) => s + (r.tabulacoesSucesso ?? 0), 0) / n
        ),
        "Sucesso Neg.": Math.round(
          group.reduce((s, r) => s + (r.tabulacoesSucessoNegocio ?? 0), 0) / n
        ),
        "Idle (min)": Math.round(
          group.reduce((s, r) => s + ((r as any).idleSeg ?? 0), 0) / n / 60
        ),
        count: group.length,
      };
    });
  }, [quartilGroups]);

  const top5 = useMemo(
    () =>
      [...rowsWithQuartil]
        .sort((a, b) => (b.chamadasAtendidas ?? 0) - (a.chamadasAtendidas ?? 0))
        .slice(0, 5),
    [rowsWithQuartil]
  );
  const bottom5 = useMemo(
    () =>
      [...rowsWithQuartil]
        .filter(r => (r.chamadasAtendidas ?? 0) > 0)
        .sort((a, b) => (a.chamadasAtendidas ?? 0) - (b.chamadasAtendidas ?? 0))
        .slice(0, 5),
    [rowsWithQuartil]
  );
  const topIdle = useMemo(
    () =>
      [...rowsWithQuartil]
        .sort((a, b) => ((b as any).idleSeg ?? 0) - ((a as any).idleSeg ?? 0))
        .slice(0, 5),
    [rowsWithQuartil]
  );
  const topPausas = useMemo(
    () =>
      [...rowsWithQuartil]
        .filter(
          r => r.pausasImprodutivas && r.pausasImprodutivas !== "00:00:00"
        )
        .sort(
          (a, b) =>
            timeToSec(b.pausasImprodutivas) - timeToSec(a.pausasImprodutivas)
        )
        .slice(0, 5),
    [rowsWithQuartil]
  );

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const exportPng = async (
    ref: React.RefObject<HTMLDivElement | null>,
    filename: string
  ) => {
    if (!ref.current) {
      toast.error("Nada para exportar");
      return;
    }
    try {
      toast.info("Gerando imagem...");
      const url = await toPng(ref.current, {
        backgroundColor: "#0f1117",
        pixelRatio: 2,
        skipFonts: true,
        cacheBust: true,
        style: { borderRadius: "0" },
      });
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      toast.success("Imagem exportada com sucesso");
    } catch (e) {
      toast.error("Erro ao exportar imagem");
    }
  };

  const handleExportTable = () =>
    exportPng(
      tableExportRef,
      `performance-tabela-${new Date().toISOString().slice(0, 10)}.png`
    );
  const handleExportQuartil = () =>
    exportPng(
      exportRef,
      `performance-quartil-${new Date().toISOString().slice(0, 10)}.png`
    );
  const handleExportLogin = () =>
    exportPng(
      loginExportRef,
      `login-logout-${new Date().toISOString().slice(0, 10)}.png`
    );
  const handleExportBaixaProducao = () =>
    exportPng(
      baixaProducaoExportRef,
      `baixa-producao-${new Date().toISOString().slice(0, 10)}.png`
    );

  // Dados para Login & Logout
  // Quem LOGOU: está no AgentDay (humanRows)
  const logadosHoje = useMemo(
    () =>
      humanRows.map(r => ({
        agente: r.agente || "",
        login: r.login || "",
        campanha: (r as any).celula || (r as any).produto || "",
        supervisor: (r as any).supervisorDim || "",
        primeiroLogin: r.primeiroLogin || "",
        ultimoLogout: r.ultimoLogout || "",
        tempoLogado: r.tempoLogado || "",
      })),
    [humanRows]
  );

  // Quem NÃO LOGOU: está no dimensionamento mas não apareceu no AgentDay
  const { data: dimAll = [] } = trpc.dimensionamento.list.useQuery({
    status: "ATIVO",
  });
  const naoLogados = useMemo(() => {
    const logadosNomes = new Set(
      humanRows.map(r => (r.agente || "").trim().toUpperCase())
    );
    const logadosLogins = new Set(
      humanRows.map(r => (r.login || "").trim().toLowerCase()).filter(Boolean)
    );
    return dimAll.filter(d => {
      const nomeUp = (d.nome || "").trim().toUpperCase();
      const loginLow = (d.login || "").trim().toLowerCase();
      return (
        !logadosNomes.has(nomeUp) && !(loginLow && logadosLogins.has(loginLow))
      );
    });
  }, [dimAll, humanRows]);

  // Campanhas únicas para filtro
  const campanhasLogin = useMemo(() => {
    const s = new Set(logadosHoje.map(r => r.campanha).filter(Boolean));
    return Array.from(s).sort();
  }, [logadosHoje]);
  const campanhasNaoLogin = useMemo(() => {
    const s = new Set(naoLogados.map(r => r.celula || "").filter(Boolean));
    return Array.from(s).sort();
  }, [naoLogados]);

  const logadosFiltrados = useMemo(() => {
    if (loginCampanhaFilter === "all") return logadosHoje;
    return logadosHoje.filter(r => r.campanha === loginCampanhaFilter);
  }, [logadosHoje, loginCampanhaFilter]);

  const naoLogadosFiltrados = useMemo(() => {
    if (loginCampanhaFilter === "all") return naoLogados;
    return naoLogados.filter(r => (r.celula || "") === loginCampanhaFilter);
  }, [naoLogados, loginCampanhaFilter]);

  const QUARTIL_COLORS: Record<string, string> = {
    Q1: "#22c55e",
    Q2: "#3b82f6",
    Q3: "#f59e0b",
    Q4: "#ef4444",
  };

  // Colunas da tabela — nova ordem: KPIs primeiro, depois volumes, depois tempos
  // Ordem: Agente | T.Logado (%) | Idle | TMA | %CPC | CPC# | %SucNeg | SucNeg# | Chamadas | Tab.Suc | Pausas Improd.
  const cols: {
    key: SortKey;
    label: string;
    align?: string;
    tooltip?: string;
  }[] = [
    { key: "agente", label: "Agente" },
    {
      key: "tempoLogado",
      label: "T. Logado",
      align: "text-center",
      tooltip: "Tempo logado + % da jornada (8h)",
    },
    {
      key: "idleSeg",
      label: "Idle",
      align: "text-center",
      tooltip: "Tempo Ocioso ÷ Chamadas Atendidas",
    },
    {
      key: "tmaSeg",
      label: "TMA",
      align: "text-center",
      tooltip: "Tempo Médio de Atendimento = Tempo Falado ÷ Chamadas",
    },
    {
      key: "cpcPct",
      label: "% CPC",
      align: "text-right",
      tooltip: "CPC ÷ Chamadas Atendidas × 100",
    },
    {
      key: "contatoEfetivo",
      label: "CPC",
      align: "text-right",
      tooltip: "Contato Pessoal Confirmado (numérico)",
    },
    {
      key: "sucessoNegPct",
      label: "% Suc.Neg",
      align: "text-right",
      tooltip: "Sucesso Negócio ÷ CPC × 100",
    },
    { key: "tabulacoesSucessoNegocio", label: "Suc.Neg", align: "text-right" },
    { key: "chamadasAtendidas", label: "Chamadas", align: "text-right" },
    {
      key: "logins",
      label: "Logins",
      align: "text-right",
      tooltip: "Quantidade de vezes que logou no dia",
    },
    { key: "tabulacoesSucesso", label: "Tab. Suc.", align: "text-right" },
    { key: "pausasImprodutivas", label: "P. Improd.", align: "text-right" },
  ];

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-xl font-bold text-foreground">
            Performance em Tempo Real
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Relatório AgentDay — {humanRows.length} agentes
            {rows.length - humanRows.length > 0
              ? ` · ${rows.length - humanRows.length} BOTs excluídos`
              : ""}
            {" · "}Q1 ≥ {quartiles.q3} · Q2 ≥ {quartiles.q2} · Q3 ≥{" "}
            {quartiles.q1}
          </p>
        </div>
        <div className="flex gap-2">
          <SyncNowButtons kinds={["agentday"]} />
          <Button
            onClick={handleExportTable}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            <Download className="w-4 h-4" /> PNG Tabela
          </Button>
          <Button
            onClick={handleExportQuartil}
            variant="outline"
            size="sm"
            className="gap-2 border-primary/40 text-primary hover:bg-primary/10"
          >
            <Award className="w-4 h-4" /> PNG Quartil
          </Button>
        </div>
      </div>

      <Tabs defaultValue="tabela">
        <TabsList className="bg-card border border-border">
          <TabsTrigger value="tabela" className="gap-2">
            <ChevronsUpDown className="w-3.5 h-3.5" /> Tabela Completa
          </TabsTrigger>
          <TabsTrigger value="quartil" className="gap-2">
            <Award className="w-3.5 h-3.5" /> Análise por Quartil
          </TabsTrigger>
          <TabsTrigger value="login" className="gap-2">
            <LogIn className="w-3.5 h-3.5" /> Login &amp; Logout
          </TabsTrigger>
          <TabsTrigger value="baixaproducao" className="gap-2">
            <AlertOctagon className="w-3.5 h-3.5" /> Baixa Produção
          </TabsTrigger>
        </TabsList>

        {/* ── Aba: Tabela Completa ── */}
        <TabsContent value="tabela" className="space-y-4 mt-4">
          {/* Filtros */}
          <div className="flex gap-3 flex-wrap">
            <div className="relative flex-1 min-w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar agente ou login..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9 bg-card border-border"
              />
            </div>
            <Select value={turnoFilter} onValueChange={setTurnoFilter}>
              <SelectTrigger className="w-36 bg-card border-border">
                <SelectValue placeholder="Turno" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Turnos</SelectItem>
                {turnos.map(t => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={celulaFilter} onValueChange={setCelulaFilter}>
              <SelectTrigger className="w-40 bg-card border-border">
                <SelectValue placeholder="Célula" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Células</SelectItem>
                {celulas.map(c => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={supervisorFilter}
              onValueChange={setSupervisorFilter}
            >
              <SelectTrigger className="w-40 bg-card border-border">
                <SelectValue placeholder="Supervisor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Supervisores</SelectItem>
                {supervisores.map(s => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={ufFilter} onValueChange={setUfFilter}>
              <SelectTrigger className="w-28 bg-card border-border">
                <SelectValue placeholder="UF" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas UFs</SelectItem>
                {ufs.map(uf => (
                  <SelectItem key={uf} value={uf}>
                    {uf}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={quartilFilter} onValueChange={setQuartilFilter}>
              <SelectTrigger className="w-36 bg-card border-border">
                <SelectValue placeholder="Quartil" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Quartis</SelectItem>
                <SelectItem value="Q1">Q1 — Acima do 3º Quartil</SelectItem>
                <SelectItem value="Q2">Q2 — Acima da Média</SelectItem>
                <SelectItem value="Q3">Q3 — Abaixo da Média</SelectItem>
                <SelectItem value="Q4">Q4 — Ofensores</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Área exportável da tabela completa */}
          <div
            ref={tableExportRef}
            className="bg-[#0f1117] rounded-xl space-y-3 p-4"
          >
            {/* Cabeçalho do PNG da tabela */}
            <div className="flex items-center justify-between border-b border-border/50 pb-3 mb-1">
              <div>
                <h3 className="text-sm font-bold text-foreground">
                  Performance em Tempo Real — Tabela Completa
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {new Date().toLocaleDateString("pt-BR", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                  {" · "}
                  {filtered.length} agentes
                  {turnoFilter !== "all" && ` · Turno: ${turnoFilter}`}
                  {celulaFilter !== "all" && ` · Célula: ${celulaFilter}`}
                </p>
              </div>
              <div className="flex gap-2">
                {(["Q1", "Q2", "Q3", "Q4"] as const).map(q => (
                  <div
                    key={q}
                    className={`text-xs font-bold px-2 py-0.5 rounded ${
                      q === "Q1"
                        ? "bg-emerald-500/20 text-emerald-400"
                        : q === "Q2"
                          ? "bg-blue-500/20 text-blue-400"
                          : q === "Q3"
                            ? "bg-amber-500/20 text-amber-400"
                            : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {q}: {quartilGroups[q].length}
                  </div>
                ))}
              </div>
            </div>

            {/* Tabela */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full data-table">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="px-3 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider w-8">
                        #
                      </th>
                      <th className="px-3 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider w-10">
                        Q
                      </th>
                      {cols.map(col => (
                        <th
                          key={col.key}
                          onClick={() => handleSort(col.key)}
                          title={col.tooltip}
                          className={`px-3 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider cursor-pointer hover:text-foreground select-none ${col.align || "text-left"}`}
                        >
                          <div
                            className={`flex items-center gap-1 ${col.align === "text-right" ? "justify-end" : col.align === "text-center" ? "justify-center" : ""}`}
                          >
                            {col.label}
                            <SortIcon
                              col={col.key}
                              sortKey={sortKey}
                              dir={sortDir}
                            />
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      Array.from({ length: 8 }).map((_, i) => (
                        <tr key={i} className="border-b border-border/50">
                          {Array.from({ length: 13 }).map((_, j) => (
                            <td key={j} className="px-3 py-3">
                              <Skeleton className="h-4 w-full" />
                            </td>
                          ))}
                        </tr>
                      ))
                    ) : filtered.length === 0 ? (
                      <tr>
                        <td
                          colSpan={13}
                          className="px-4 py-12 text-center text-muted-foreground text-sm"
                        >
                          Nenhum dado disponível. Importe um relatório AgentDay.
                        </td>
                      </tr>
                    ) : (
                      filtered.map((row, i) => {
                        const r = row as any;
                        return (
                          <tr
                            key={row.id}
                            className="border-b border-border/50 hover:bg-accent/20 transition-colors"
                          >
                            <td className="px-3 py-2.5 text-xs text-muted-foreground">
                              {i + 1}
                            </td>
                            <td className="px-3 py-2.5">
                              <span
                                className={`text-xs font-bold px-1.5 py-0.5 rounded ${row._quartil.bg} ${row._quartil.color}`}
                              >
                                {row._quartil.label}
                              </span>
                            </td>
                            {/* Agente */}
                            <td className="px-3 py-2.5 min-w-[140px]">
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <p className="text-sm font-medium text-foreground leading-tight">
                                    {row.agente}
                                  </p>
                                  {r.noDimensionamento === false && (
                                    <span
                                      title="Agente não encontrado no dimensionamento"
                                      className="text-[9px] px-1.5 py-0 rounded-full bg-yellow-500/15 text-yellow-400 border border-yellow-500/30 font-semibold uppercase tracking-wide shrink-0"
                                    >
                                      Pendente
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center gap-1.5 mt-0.5">
                                  <p className="text-xs text-muted-foreground">
                                    {row.login}
                                  </p>
                                  {r.turno && (
                                    <span className="text-[10px] px-1 py-0 rounded bg-primary/10 text-primary font-mono">
                                      {r.turno}
                                    </span>
                                  )}
                                  {r.celula && (
                                    <span className="text-[10px] px-1 py-0 rounded bg-blue-500/10 text-blue-400 font-mono truncate max-w-[80px]">
                                      {r.celula}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </td>
                            {/* T. Logado + % */}
                            <td className="px-3 py-2.5 text-center">
                              <div>
                                <span className="text-sm text-foreground font-mono">
                                  {row.tempoLogado || "—"}
                                </span>
                                {r.tempoLogadoPct > 0 && (
                                  <div className="text-[10px] text-muted-foreground mt-0.5">
                                    {r.tempoLogadoPct}%
                                  </div>
                                )}
                              </div>
                            </td>
                            {/* Idle */}
                            <td className="px-3 py-2.5 text-center">
                              <span
                                className={`text-sm font-mono ${r.idleSeg > 120 ? "text-amber-400 font-semibold" : "text-foreground"}`}
                              >
                                {r.idleSeg > 0 ? secToMS(r.idleSeg) : "—"}
                              </span>
                            </td>
                            {/* TMA */}
                            <td className="px-3 py-2.5 text-center">
                              <span className="text-sm font-mono text-foreground">
                                {r.tmaSeg > 0 ? secToMS(r.tmaSeg) : "—"}
                              </span>
                            </td>
                            {/* % CPC */}
                            <td className="px-3 py-2.5 text-right">
                              <span
                                className={`text-sm font-semibold tabular-nums ${r.cpcPct >= 30 ? "text-emerald-400" : r.cpcPct >= 15 ? "text-amber-400" : "text-red-400"}`}
                              >
                                {r.cpcPct > 0 ? `${r.cpcPct}%` : "—"}
                              </span>
                            </td>
                            {/* CPC numérico */}
                            <td className="px-3 py-2.5 text-right">
                              <span className="text-sm font-semibold text-emerald-400 tabular-nums">
                                {(row.contatoEfetivo ?? 0).toLocaleString(
                                  "pt-BR"
                                )}
                              </span>
                            </td>
                            {/* % Sucesso Neg */}
                            <td className="px-3 py-2.5 text-right">
                              <span
                                className={`text-sm font-semibold tabular-nums ${r.sucessoNegPct >= 20 ? "text-violet-400" : r.sucessoNegPct >= 10 ? "text-amber-400" : "text-muted-foreground"}`}
                              >
                                {r.sucessoNegPct > 0
                                  ? `${r.sucessoNegPct}%`
                                  : "—"}
                              </span>
                            </td>
                            {/* Sucesso Neg numérico */}
                            <td className="px-3 py-2.5 text-right">
                              <span className="text-sm text-violet-400 tabular-nums">
                                {(
                                  row.tabulacoesSucessoNegocio ?? 0
                                ).toLocaleString("pt-BR")}
                              </span>
                            </td>
                            {/* Chamadas */}
                            <td className="px-3 py-2.5 text-right">
                              <span className="text-sm font-semibold text-blue-400 tabular-nums">
                                {(row.chamadasAtendidas ?? 0).toLocaleString(
                                  "pt-BR"
                                )}
                              </span>
                            </td>
                            {/* Logins */}
                            <td className="px-3 py-2.5 text-right">
                              <span className="text-sm text-muted-foreground tabular-nums">
                                {(row.logins ?? 0).toLocaleString("pt-BR")}
                              </span>
                            </td>
                            {/* Tab. Sucesso */}
                            <td className="px-3 py-2.5 text-right">
                              <span className="text-sm text-cyan-400 tabular-nums">
                                {(row.tabulacoesSucesso ?? 0).toLocaleString(
                                  "pt-BR"
                                )}
                              </span>
                            </td>
                            {/* Pausas Improdutivas */}
                            <td className="px-3 py-2.5 text-right">
                              <span
                                className={`text-sm tabular-nums font-mono font-semibold ${timeToSec(row.pausasImprodutivas) > 0 ? "text-red-400" : "text-muted-foreground"}`}
                              >
                                {row.pausasImprodutivas ?? "00:00:00"}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          {/* fim tableExportRef */}
        </TabsContent>

        {/* ── Aba: Análise por Quartil ── */}
        <TabsContent value="quartil" className="space-y-5 mt-4" forceMount>
          {/* Cards de resumo por quartil */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {(["Q1", "Q2", "Q3", "Q4"] as const).map(q => {
              const group = quartilGroups[q];
              const labels: Record<string, { text: string; desc: string }> = {
                Q1: {
                  text: "Acima do 3º Quartil",
                  desc: "Acima do 3º quartil",
                },
                Q2: { text: "Acima da Média", desc: "Entre Q2 e Q3" },
                Q3: { text: "Abaixo da Média", desc: "Entre Q1 e Q2" },
                Q4: { text: "Ofensores", desc: "Abaixo do 1º quartil" },
              };
              const avgIdle =
                group.length > 0
                  ? Math.round(
                      group.reduce((s, r) => s + ((r as any).idleSeg ?? 0), 0) /
                        group.length
                    )
                  : 0;
              const avgTma =
                group.length > 0
                  ? Math.round(
                      group.reduce((s, r) => s + ((r as any).tmaSeg ?? 0), 0) /
                        group.length
                    )
                  : 0;
              const avgCpcPct =
                group.length > 0
                  ? Math.round(
                      (group.reduce((s, r) => s + ((r as any).cpcPct ?? 0), 0) /
                        group.length) *
                        10
                    ) / 10
                  : 0;
              return (
                <div
                  key={q}
                  className="bg-card border border-border rounded-xl p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded ${
                        q === "Q1"
                          ? "bg-emerald-500/15 text-emerald-400"
                          : q === "Q2"
                            ? "bg-blue-500/15 text-blue-400"
                            : q === "Q3"
                              ? "bg-amber-500/15 text-amber-400"
                              : "bg-red-500/15 text-red-400"
                      }`}
                    >
                      {q}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {group.length} agentes
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-foreground">
                    {labels[q].text}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {labels[q].desc}
                  </p>
                  <div className="mt-3 pt-3 border-t border-border space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">
                        Média chamadas
                      </span>
                      <span className="font-semibold text-foreground tabular-nums">
                        {group.length > 0
                          ? Math.round(
                              group.reduce(
                                (s, r) => s + (r.chamadasAtendidas ?? 0),
                                0
                              ) / group.length
                            ).toLocaleString("pt-BR")
                          : "—"}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">% CPC médio</span>
                      <span
                        className={`font-semibold tabular-nums ${avgCpcPct >= 30 ? "text-emerald-400" : avgCpcPct >= 15 ? "text-amber-400" : "text-red-400"}`}
                      >
                        {avgCpcPct > 0 ? `${avgCpcPct}%` : "—"}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Idle médio</span>
                      <span
                        className={`font-semibold font-mono tabular-nums ${avgIdle > 120 ? "text-amber-400" : "text-foreground"}`}
                      >
                        {avgIdle > 0 ? secToMS(avgIdle) : "—"}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">TMA médio</span>
                      <span className="font-semibold font-mono tabular-nums text-foreground">
                        {avgTma > 0 ? secToMS(avgTma) : "—"}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Gráficos de médias por quartil */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-400" /> Chamadas e CPC —
                Média por Quartil
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  data={quartilChartData}
                  margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.25 0.012 240)"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="quartil"
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 11 }}
                  />
                  <YAxis
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="Chamadas" radius={[4, 4, 0, 0]}>
                    {quartilChartData.map(entry => (
                      <Cell
                        key={entry.quartil}
                        fill={QUARTIL_COLORS[entry.quartil]}
                        fillOpacity={0.85}
                      />
                    ))}
                    <LabelList
                      dataKey="Chamadas"
                      position="top"
                      style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    />
                  </Bar>
                  <Bar
                    dataKey="CPC"
                    fill="#22c55e"
                    radius={[4, 4, 0, 0]}
                    fillOpacity={0.6}
                  >
                    <LabelList
                      dataKey="CPC"
                      position="top"
                      style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" /> Tab. Sucesso e
                Sucesso Neg. — Média por Quartil
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  data={quartilChartData}
                  margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.25 0.012 240)"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="quartil"
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 11 }}
                  />
                  <YAxis
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar
                    dataKey="Tab. Sucesso"
                    fill="#06b6d4"
                    radius={[4, 4, 0, 0]}
                  >
                    <LabelList
                      dataKey="Tab. Sucesso"
                      position="top"
                      style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    />
                  </Bar>
                  <Bar
                    dataKey="Sucesso Neg."
                    fill="#a855f7"
                    radius={[4, 4, 0, 0]}
                  >
                    <LabelList
                      dataKey="Sucesso Neg."
                      position="top"
                      style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Gráfico Idle */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" /> Idle Médio por
              Quartil (seg/chamada)
            </h3>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart
                data={quartilChartData}
                layout="vertical"
                margin={{ top: 0, right: 60, left: 20, bottom: 0 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="oklch(0.25 0.012 240)"
                  horizontal={false}
                />
                <XAxis
                  type="number"
                  tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                />
                <YAxis
                  type="category"
                  dataKey="quartil"
                  tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 11 }}
                  width={30}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="Idle (min)" radius={[0, 4, 4, 0]}>
                  {quartilChartData.map(entry => (
                    <Cell
                      key={entry.quartil}
                      fill={QUARTIL_COLORS[entry.quartil]}
                      fillOpacity={0.7}
                    />
                  ))}
                  <LabelList
                    dataKey="Idle (min)"
                    position="right"
                    style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    formatter={(v: number) => `${v} min`}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Tabela de agentes por quartil — área exportável */}
          <div
            ref={exportRef}
            className="bg-[#0f1117] rounded-xl p-6 space-y-5 border border-border"
          >
            {/* Cabeçalho do PNG */}
            <div className="flex items-center justify-between border-b border-border/50 pb-4">
              <div>
                <h3 className="text-base font-bold text-foreground">
                  Performance em Tempo Real — Resumo por Quartil
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {new Date().toLocaleDateString("pt-BR", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div className="flex gap-2">
                {(["Q1", "Q2", "Q3", "Q4"] as const).map(q => (
                  <div
                    key={q}
                    className={`text-xs font-bold px-2 py-1 rounded ${
                      q === "Q1"
                        ? "bg-emerald-500/20 text-emerald-400"
                        : q === "Q2"
                          ? "bg-blue-500/20 text-blue-400"
                          : q === "Q3"
                            ? "bg-amber-500/20 text-amber-400"
                            : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {q}: {quartilGroups[q].length}
                  </div>
                ))}
              </div>
            </div>

            {/* Grid de 4 quartis */}
            <div className="grid grid-cols-2 gap-4">
              {(["Q1", "Q2", "Q3", "Q4"] as const).map(q => {
                const group = quartilGroups[q].slice(0, 8);
                const qLabels: Record<string, string> = {
                  Q1: "Acima do 3º Quartil",
                  Q2: "Acima da Média",
                  Q3: "Abaixo da Média",
                  Q4: "Ofensores",
                };
                const qColors: Record<string, string> = {
                  Q1: "text-emerald-400",
                  Q2: "text-blue-400",
                  Q3: "text-amber-400",
                  Q4: "text-red-400",
                };
                return (
                  <div
                    key={q}
                    className="bg-card/50 rounded-lg p-4 border border-border/50"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <span
                        className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                          q === "Q1"
                            ? "bg-emerald-500/15 text-emerald-400"
                            : q === "Q2"
                              ? "bg-blue-500/15 text-blue-400"
                              : q === "Q3"
                                ? "bg-amber-500/15 text-amber-400"
                                : "bg-red-500/15 text-red-400"
                        }`}
                      >
                        {q}
                      </span>
                      <span className={`text-sm font-semibold ${qColors[q]}`}>
                        {qLabels[q]}
                      </span>
                      <span className="text-xs text-muted-foreground ml-auto">
                        {quartilGroups[q].length} agentes
                      </span>
                    </div>
                    {/* Mini tabela */}
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-border/30">
                          <th className="pb-1.5 text-left text-muted-foreground font-medium">
                            Agente
                          </th>
                          <th className="pb-1.5 text-right text-muted-foreground font-medium">
                            Cham.
                          </th>
                          <th className="pb-1.5 text-right text-muted-foreground font-medium">
                            %CPC
                          </th>
                          <th className="pb-1.5 text-right text-muted-foreground font-medium">
                            Idle
                          </th>
                          <th className="pb-1.5 text-right text-muted-foreground font-medium">
                            TMA
                          </th>
                          <th className="pb-1.5 text-right text-muted-foreground font-medium">
                            %SN
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {group.map((r, idx) => {
                          const rr = r as any;
                          return (
                            <tr
                              key={r.id}
                              className={`border-b border-border/20 ${idx % 2 === 0 ? "bg-transparent" : "bg-white/[0.02]"}`}
                            >
                              <td className="py-1.5 text-foreground font-medium truncate max-w-[100px]">
                                {r.agente?.split(" ").slice(0, 2).join(" ")}
                              </td>
                              <td className="py-1.5 text-right text-blue-400 tabular-nums font-semibold">
                                {(r.chamadasAtendidas ?? 0).toLocaleString(
                                  "pt-BR"
                                )}
                              </td>
                              <td
                                className={`py-1.5 text-right tabular-nums font-semibold ${rr.cpcPct >= 30 ? "text-emerald-400" : rr.cpcPct >= 15 ? "text-amber-400" : "text-red-400"}`}
                              >
                                {rr.cpcPct > 0 ? `${rr.cpcPct}%` : "—"}
                              </td>
                              <td
                                className={`py-1.5 text-right font-mono tabular-nums ${rr.idleSeg > 120 ? "text-amber-400" : "text-muted-foreground"}`}
                              >
                                {rr.idleSeg > 0 ? secToMS(rr.idleSeg) : "—"}
                              </td>
                              <td className="py-1.5 text-right font-mono tabular-nums text-foreground">
                                {rr.tmaSeg > 0 ? secToMS(rr.tmaSeg) : "—"}
                              </td>
                              <td
                                className={`py-1.5 text-right tabular-nums ${rr.sucessoNegPct >= 20 ? "text-violet-400" : "text-muted-foreground"}`}
                              >
                                {rr.sucessoNegPct > 0
                                  ? `${rr.sucessoNegPct}%`
                                  : "—"}
                              </td>
                            </tr>
                          );
                        })}
                        {group.length === 0 && (
                          <tr>
                            <td
                              colSpan={6}
                              className="py-3 text-center text-muted-foreground"
                            >
                              Sem agentes neste quartil
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>

            {/* Rodapé com top ofensores */}
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border/50">
              <div>
                <h4 className="text-xs font-semibold text-amber-400 mb-2 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" /> Top 5 — Maior Idle
                  (seg/chamada)
                </h4>
                {topIdle.map((r, i) => {
                  const rr = r as any;
                  return (
                    <div
                      key={r.id}
                      className="flex items-center justify-between gap-2 py-0.5"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-xs text-muted-foreground w-4">
                          {i + 1}.
                        </span>
                        <span className="text-xs text-foreground truncate">
                          {r.agente?.split(" ").slice(0, 2).join(" ")}
                        </span>
                      </div>
                      <span className="text-xs font-mono font-semibold text-amber-400 shrink-0">
                        {rr.idleSeg > 0 ? secToMS(rr.idleSeg) : "—"}
                      </span>
                    </div>
                  );
                })}
              </div>
              <div>
                <h4 className="text-xs font-semibold text-red-400 mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> Top 5 — Maior Pausa
                  Improdutiva
                </h4>
                {topPausas.length > 0 ? (
                  topPausas.map((r, i) => (
                    <div
                      key={r.id}
                      className="flex items-center justify-between gap-2 py-0.5"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-xs text-muted-foreground w-4">
                          {i + 1}.
                        </span>
                        <span className="text-xs text-foreground truncate">
                          {r.agente?.split(" ").slice(0, 2).join(" ")}
                        </span>
                      </div>
                      <span className="text-xs font-mono font-semibold text-red-400 shrink-0">
                        {r.pausasImprodutivas}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-muted-foreground">
                    Nenhuma pausa improdutiva registrada
                  </p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* ── Aba: Login & Logout ── */}
        <TabsContent value="login" className="space-y-4 mt-4">
          {/* Toolbar */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <Select
                value={loginCampanhaFilter}
                onValueChange={v => {
                  setLoginCampanhaFilter(v);
                }}
              >
                <SelectTrigger className="w-48 bg-card border-border">
                  <SelectValue placeholder="Todas as campanhas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as campanhas</SelectItem>
                  {(loginTab === "logados"
                    ? campanhasLogin
                    : campanhasNaoLogin
                  ).map(c => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex rounded-lg border border-border overflow-hidden">
                <button
                  onClick={() => {
                    setLoginTab("logados");
                    setLoginCampanhaFilter("all");
                  }}
                  className={`px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    loginTab === "logados"
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "text-muted-foreground hover:bg-card"
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> Logados (
                  {logadosHoje.length})
                </button>
                <button
                  onClick={() => {
                    setLoginTab("nao_logados");
                    setLoginCampanhaFilter("all");
                  }}
                  className={`px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 transition-colors border-l border-border ${
                    loginTab === "nao_logados"
                      ? "bg-red-500/20 text-red-300"
                      : "text-muted-foreground hover:bg-card"
                  }`}
                >
                  <XCircle className="w-3.5 h-3.5" /> Não Logados (
                  {naoLogados.length})
                </button>
              </div>
            </div>
            <Button
              onClick={handleExportLogin}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Download className="w-4 h-4" /> Exportar PNG
            </Button>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-card border border-border rounded-xl p-4">
              <p className="text-xs text-muted-foreground mb-1">Logados Hoje</p>
              <p className="text-2xl font-black text-emerald-400">
                {logadosHoje.length}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Aparecem no AgentDay
              </p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <p className="text-xs text-muted-foreground mb-1">Não Logados</p>
              <p
                className={`text-2xl font-black ${naoLogados.length > 0 ? "text-red-400" : "text-emerald-400"}`}
              >
                {naoLogados.length}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                No dimensionamento, sem login
              </p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <p className="text-xs text-muted-foreground mb-1">
                Taxa de Login
              </p>
              <p className="text-2xl font-black text-foreground">
                {dimAll.length > 0
                  ? Math.round(
                      (logadosHoje.length /
                        (logadosHoje.length + naoLogados.length)) *
                        100
                    )
                  : 0}
                %
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {logadosHoje.length} de {logadosHoje.length + naoLogados.length}{" "}
                ativos
              </p>
            </div>
          </div>

          {/* Tabela exportável */}
          <div
            ref={loginExportRef}
            className="bg-[#0f1117] rounded-xl border border-border overflow-hidden"
          >
            {/* Header do export */}
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold text-xs">
                  DDM
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">
                    Controle de Login &amp; Logout
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date().toLocaleDateString("pt-BR", {
                      day: "2-digit",
                      month: "long",
                      year: "numeric",
                    })}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs px-2 py-1 rounded-full font-semibold ${
                    loginTab === "logados"
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-red-500/20 text-red-300"
                  }`}
                >
                  {loginTab === "logados"
                    ? `✓ ${logadosFiltrados.length} Logados`
                    : `✗ ${naoLogadosFiltrados.length} Não Logados`}
                </span>
              </div>
            </div>

            {loginTab === "logados" ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-card/50">
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        #
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Agente
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Login
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Campanha
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Supervisor
                      </th>
                      <th className="text-center px-4 py-3 text-muted-foreground font-medium text-xs">
                        1º Login
                      </th>
                      <th className="text-center px-4 py-3 text-muted-foreground font-medium text-xs">
                        Últ. Logout
                      </th>
                      <th className="text-center px-4 py-3 text-muted-foreground font-medium text-xs">
                        T. Logado
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {logadosFiltrados.length === 0 ? (
                      <tr>
                        <td
                          colSpan={8}
                          className="text-center py-8 text-muted-foreground"
                        >
                          Nenhum agente logado encontrado.
                        </td>
                      </tr>
                    ) : (
                      logadosFiltrados.map((r, i) => (
                        <tr
                          key={i}
                          className={`border-b border-border/50 hover:bg-card/30 ${i % 2 === 0 ? "" : "bg-card/10"}`}
                        >
                          <td className="px-4 py-2.5 text-muted-foreground text-xs">
                            {i + 1}
                          </td>
                          <td className="px-4 py-2.5 text-foreground font-medium text-sm">
                            {r.agente}
                          </td>
                          <td className="px-4 py-2.5 text-muted-foreground font-mono text-xs">
                            {r.login || "—"}
                          </td>
                          <td className="px-4 py-2.5 text-xs">
                            {r.campanha ? (
                              <span className="px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-300 text-xs">
                                {r.campanha}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </td>
                          <td className="px-4 py-2.5 text-muted-foreground text-xs">
                            {r.supervisor || "—"}
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <span className="text-xs font-mono text-emerald-400">
                              {r.primeiroLogin || "—"}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <span className="text-xs font-mono text-amber-400">
                              {r.ultimoLogout || "—"}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <span className="text-xs font-mono text-foreground">
                              {r.tempoLogado || "—"}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-card/50">
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        #
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Agente
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Login
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Campanha
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Supervisor
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Turno
                      </th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium text-xs">
                        Horário
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {naoLogadosFiltrados.length === 0 ? (
                      <tr>
                        <td
                          colSpan={7}
                          className="text-center py-8 text-muted-foreground"
                        >
                          Todos os operadores ativos estão logados!
                        </td>
                      </tr>
                    ) : (
                      naoLogadosFiltrados.map((d, i) => (
                        <tr
                          key={i}
                          className={`border-b border-border/50 hover:bg-card/30 ${i % 2 === 0 ? "" : "bg-card/10"}`}
                        >
                          <td className="px-4 py-2.5 text-muted-foreground text-xs">
                            {i + 1}
                          </td>
                          <td className="px-4 py-2.5 text-foreground font-medium text-sm">
                            {d.nome}
                          </td>
                          <td className="px-4 py-2.5 text-muted-foreground font-mono text-xs">
                            {d.login || "—"}
                          </td>
                          <td className="px-4 py-2.5 text-xs">
                            {d.celula ? (
                              <span className="px-1.5 py-0.5 rounded bg-orange-500/15 text-orange-300 text-xs">
                                {d.celula}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </td>
                          <td className="px-4 py-2.5 text-muted-foreground text-xs">
                            {d.supervisor || "—"}
                          </td>
                          <td className="px-4 py-2.5 text-xs">
                            {d.turno ? (
                              <span
                                className={`px-1.5 py-0.5 rounded text-xs ${
                                  d.turno === "MANHÃ"
                                    ? "bg-blue-500/15 text-blue-300"
                                    : d.turno === "TARDE"
                                      ? "bg-orange-500/15 text-orange-300"
                                      : "bg-purple-500/15 text-purple-300"
                                }`}
                              >
                                {d.turno}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </td>
                          <td className="px-4 py-2.5 text-muted-foreground text-xs font-mono">
                            {d.entrada && d.saida
                              ? `${d.entrada}–${d.saida}`
                              : "—"}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </TabsContent>

        {/* ── Aba: Baixa Produção ── */}
        <TabsContent value="baixaproducao" className="space-y-4 mt-4">
          <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-300">
            <AlertOctagon className="w-3.5 h-3.5 mt-0.5 shrink-0" />
            <span>
              Diferente da aba Quartil (que ranqueia agente por agente): aqui o
              foco é achar <b>onde</b> o problema se concentra — célula/
              campanha ou supervisor. Considera só quem já logou{" "}
              {tempoMinLogadoMin}min+.
              {celulasExcluidas.length > 0 &&
                ` ${celulasExcluidas.length} célula(s) excluída(s) do cálculo.`}
            </span>
          </div>

          {/* Tendência — é um dia ruim isolado ou um padrão? */}
          {tendenciaChart.length > 1 && (
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                Tendência — últimos {tendenciaChart.length} dias com dado
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart
                  data={tendenciaChart}
                  margin={{ top: 5, right: 20, left: 0, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.25 0.012 240)"
                  />
                  <XAxis
                    dataKey="data"
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                  />
                  <YAxis
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "#15171b",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Line
                    type="monotone"
                    dataKey="% Zerados"
                    stroke="#ef4444"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="Min. NR17 Excedido"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Limiares configuráveis */}
          <details className="bg-card border border-border rounded-xl p-3 text-xs">
            <summary className="cursor-pointer text-muted-foreground font-medium select-none">
              Ajustar limiares
            </summary>
            <div className="flex flex-wrap gap-4 mt-3">
              <label className="flex items-center gap-2">
                <span className="text-muted-foreground">
                  Tempo mínimo logado pra entrar no cálculo (min)
                </span>
                <Input
                  type="number"
                  min={0}
                  defaultValue={tempoMinLogadoMin}
                  className="w-20 h-7 text-xs"
                  onBlur={e => {
                    const v = e.target.value.trim();
                    if (v && Number(v) !== tempoMinLogadoMin) {
                      setAppSetting.mutate({
                        key: "baixaProducao.tempoMinLogadoMin",
                        value: v,
                      });
                    }
                  }}
                />
              </label>
              <label className="flex items-center gap-2">
                <span className="text-muted-foreground">
                  % de zerados no grupo pra virar alerta vermelho
                </span>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  defaultValue={pctZeradosAlerta}
                  className="w-20 h-7 text-xs"
                  onBlur={e => {
                    const v = e.target.value.trim();
                    if (v && Number(v) !== pctZeradosAlerta) {
                      setAppSetting.mutate({
                        key: "baixaProducao.pctZeradosAlerta",
                        value: v,
                      });
                    }
                  }}
                />
              </label>
            </div>
          </details>

          {/* Filtro de célula/campanha — exclui as que não quer mais ver */}
          {celulasDisponiveis.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-3">
              <p className="text-xs text-muted-foreground mb-2">
                Excluir célula/campanha do cálculo:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {celulasDisponiveis.map(c => {
                  const excluida = celulasExcluidas.includes(c);
                  return (
                    <button
                      key={c}
                      onClick={() => toggleCelulaExcluida(c)}
                      className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${
                        excluida
                          ? "border-border text-muted-foreground/50 line-through bg-muted/20"
                          : "border-primary/40 text-foreground bg-primary/10"
                      }`}
                    >
                      {c}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Filtro de supervisor — separado do de célula, pra excluir só
              o time de um supervisor específico (ex: BKO) sem perder o
              resto da célula (ex: outros supervisores em Vero). */}
          {supervisoresDisponiveis.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-3">
              <p className="text-xs text-muted-foreground mb-2">
                Excluir supervisor do cálculo (ex: time de BKO, que normalmente
                fica zerado por natureza da função):
              </p>
              <div className="flex flex-wrap gap-1.5">
                {supervisoresDisponiveis.map(s => {
                  const excluido = supervisoresExcluidos.includes(s);
                  return (
                    <button
                      key={s}
                      onClick={() => toggleSupervisorExcluido(s)}
                      className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${
                        excluido
                          ? "border-border text-muted-foreground/50 line-through bg-muted/20"
                          : "border-primary/40 text-foreground bg-primary/10"
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div
            ref={baixaProducaoExportRef}
            className="space-y-4 bg-background p-1"
          >
            <div className="flex justify-end">
              <Button
                onClick={handleExportBaixaProducao}
                variant="outline"
                size="sm"
                className="gap-2"
              >
                <Download className="w-3.5 h-3.5" /> Exportar PNG
              </Button>
            </div>

            {baixaProducao.totalElegiveis === 0 ? (
              <div className="bg-card border border-border rounded-xl p-8 text-center text-sm text-muted-foreground">
                Nenhum agente elegível com os filtros atuais.
              </div>
            ) : (
              <>
                {/* Por Célula/Campanha — onde o problema se concentra */}
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="px-4 py-2.5 bg-muted/30 border-b border-border">
                    <span className="text-sm font-semibold text-foreground">
                      Por Célula/Campanha
                    </span>
                  </div>
                  <table className="w-full text-sm">
                    <thead className="bg-muted/20">
                      <tr>
                        <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                          Célula
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          Agentes
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          Zerados
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          % Zerados
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          Média Chamadas
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {baixaProducao.porCelula.map(g => (
                        <tr key={g.nome} className="border-t border-border/50">
                          <td className="px-4 py-2 font-medium text-foreground">
                            {g.nome}
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums">
                            {g.totalAgentes}
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums text-red-400">
                            {g.zerados}
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums">
                            <span
                              className={
                                g.pctZerados > pctZeradosAlerta
                                  ? "text-red-400 font-semibold"
                                  : g.pctZerados > 0
                                    ? "text-amber-400"
                                    : "text-emerald-400"
                              }
                            >
                              {g.pctZerados.toFixed(0)}%
                            </span>
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">
                            {g.mediaChamadas.toFixed(1)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Por Supervisor — quem precisa de atenção */}
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="px-4 py-2.5 bg-muted/30 border-b border-border">
                    <span className="text-sm font-semibold text-foreground">
                      Por Supervisor
                    </span>
                  </div>
                  <table className="w-full text-sm">
                    <thead className="bg-muted/20">
                      <tr>
                        <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                          Supervisor
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          Agentes
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          Zerados
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          % Zerados
                        </th>
                        <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                          Média Chamadas
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {baixaProducao.porSupervisor.map(g => (
                        <tr key={g.nome} className="border-t border-border/50">
                          <td className="px-4 py-2 font-medium text-foreground">
                            {g.nome}
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums">
                            {g.totalAgentes}
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums text-red-400">
                            {g.zerados}
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums">
                            <span
                              className={
                                g.pctZerados > pctZeradosAlerta
                                  ? "text-red-400 font-semibold"
                                  : g.pctZerados > 0
                                    ? "text-amber-400"
                                    : "text-emerald-400"
                              }
                            >
                              {g.pctZerados.toFixed(0)}%
                            </span>
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">
                            {g.mediaChamadas.toFixed(1)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Zerados — lista individual, só essa é nome a nome
                    (é a única parte que não dá pra resolver olhando só o
                    grupo — precisa saber QUEM especificamente) */}
                {baixaProducao.zerados.length > 0 && (
                  <div className="bg-card border border-red-500/20 rounded-xl overflow-hidden">
                    <div className="px-4 py-2.5 bg-red-500/10 border-b border-red-500/20 flex items-center justify-between">
                      <span className="text-sm font-semibold text-red-300 flex items-center gap-1.5">
                        <AlertOctagon className="w-4 h-4" /> Zerados (nome a
                        nome)
                      </span>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-red-300/70">
                          {baixaProducao.zerados.length} agente(s)
                        </span>
                        <Button
                          onClick={copiarListaBaixaProducao}
                          variant="outline"
                          size="sm"
                          className="h-6 text-xs gap-1"
                        >
                          <Copy className="w-3 h-3" /> Copiar
                        </Button>
                      </div>
                    </div>
                    <table className="w-full text-sm">
                      <thead className="bg-muted/30">
                        <tr>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Agente
                          </th>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Célula
                          </th>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Supervisor
                          </th>
                          <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                            Tempo Logado
                          </th>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Possível Causa
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {baixaProducao.zerados.map((r, i) => {
                          const ruido = getRuidoDaCelula(
                            (r as any).celula || ""
                          );
                          const mop = getMopStatus(
                            r.agente || "",
                            (r as any).celula || ""
                          );
                          return (
                            <tr key={i} className="border-t border-border/50">
                              <td className="px-4 py-2 font-medium text-foreground">
                                {r.agente}
                              </td>
                              <td className="px-4 py-2 text-muted-foreground">
                                {(r as any).celula || "—"}
                              </td>
                              <td className="px-4 py-2 text-muted-foreground">
                                {(r as any).supervisorDim || "—"}
                              </td>
                              <td className="px-4 py-2 text-right font-mono text-red-400">
                                {r.tempoLogado}
                              </td>
                              <td className="px-4 py-2 space-y-1">
                                {ruido !== null && ruido > 20 ? (
                                  <span className="block text-[11px] px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 font-medium w-fit">
                                    Rota com {ruido.toFixed(0)}% de ruído
                                  </span>
                                ) : (
                                  <span className="block text-[11px] text-muted-foreground/50">
                                    Sem indício técnico
                                  </span>
                                )}
                                {!mop.alocado && (
                                  <span className="block text-[11px] px-2 py-0.5 rounded bg-blue-500/15 text-blue-400 font-medium w-fit">
                                    Não alocado no MOP
                                  </span>
                                )}
                                {mop.alocado && mop.divergente && (
                                  <span className="block text-[11px] px-2 py-0.5 rounded bg-purple-500/15 text-purple-400 font-medium w-fit">
                                    MOP diverge: {mop.campanhasMop.join(", ")}
                                  </span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Baixa Conversão — fala com muita gente, fecha pouco.
                    Diferente do Zerados: aqui o agente TRABALHA, só não
                    converte. É baixa produção do mesmo jeito. */}
                {baixaProducao.baixaConversao.length > 0 && (
                  <div className="bg-card border border-amber-500/20 rounded-xl overflow-hidden">
                    <div className="px-4 py-2.5 bg-amber-500/10 border-b border-amber-500/20 flex items-center justify-between">
                      <span className="text-sm font-semibold text-amber-300 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4" /> Baixa Conversão
                        (CPC alto, pouco acordo)
                      </span>
                      <span className="text-xs text-amber-300/70">
                        {baixaProducao.baixaConversao.length} agente(s) · média
                        do grupo: {baixaProducao.conversaoMediaPct.toFixed(1)}%
                      </span>
                    </div>
                    <table className="w-full text-sm">
                      <thead className="bg-muted/30">
                        <tr>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Agente
                          </th>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Célula
                          </th>
                          <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                            Supervisor
                          </th>
                          <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                            CPC
                          </th>
                          <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                            Acordo/Promessa
                          </th>
                          <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                            % Conversão
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {baixaProducao.baixaConversao.map((r, i) => (
                          <tr key={i} className="border-t border-border/50">
                            <td className="px-4 py-2 font-medium text-foreground">
                              {r.agente}
                            </td>
                            <td className="px-4 py-2 text-muted-foreground">
                              {(r as any).celula || "—"}
                            </td>
                            <td className="px-4 py-2 text-muted-foreground">
                              {(r as any).supervisorDim || "—"}
                            </td>
                            <td className="px-4 py-2 text-right tabular-nums text-foreground">
                              {r.contatoEfetivo}
                            </td>
                            <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">
                              {r.tabulacoesSucessoNegocio ?? 0}
                            </td>
                            <td className="px-4 py-2 text-right tabular-nums font-semibold text-amber-400">
                              {r.pctConversao.toFixed(1)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
