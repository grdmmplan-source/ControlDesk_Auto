import { useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  BookMarked,
  Upload,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Calendar,
  Search,
  Layers,
  Table2,
  TrendingUp,
  History,
  BarChart3,
} from "lucide-react";
import { toast } from "sonner";

// Book Operacional — 100% isolado de TEMPOS/AgentDay/etc, por pedido
// explícito. Mesmo relatório OLOS, tabelas e sessões de upload próprias.
// Import genérico: guarda TODAS as colunas como vieram (sem mapear pra um
// schema fixo), pra nunca perder dado de nenhuma aba do Book original.

function useSortableRows<T extends Record<string, any>>(
  rows: T[],
  defaultKey: string,
  defaultDir: "asc" | "desc" = "asc"
) {
  const [sortCol, setSortCol] = useState(defaultKey);
  const [sortDir, setSortDir] = useState<"asc" | "desc">(defaultDir);
  const toggleSort = (col: string) => {
    if (sortCol === col) setSortDir(d => (d === "desc" ? "asc" : "desc"));
    else {
      setSortCol(col);
      setSortDir("desc");
    }
  };
  const sorted = [...rows].sort((a, b) => {
    const va = a[sortCol];
    const vb = b[sortCol];
    const na = parseFloat(String(va).replace(",", "."));
    const nb = parseFloat(String(vb).replace(",", "."));
    if (!isNaN(na) && !isNaN(nb)) return sortDir === "desc" ? nb - na : na - nb;
    const sa = String(va ?? "");
    const sb = String(vb ?? "");
    return sortDir === "desc" ? sb.localeCompare(sa) : sa.localeCompare(sb);
  });
  return { sorted, sortCol, sortDir, toggleSort };
}

export default function BookOperacionalPage() {
  const utils = trpc.useUtils();
  const inputRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState<
    "idle" | "uploading" | "success" | "error"
  >("idle");
  const [resultMsg, setResultMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const processReport = trpc.book.processReport.useMutation();

  // Import em massa (.xlsb original do Book — meses de histórico de uma vez)
  const bulkInputRef = useRef<HTMLInputElement>(null);
  const [bulkStatus, setBulkStatus] = useState<
    "idle" | "uploading" | "success" | "error"
  >("idle");
  const [bulkResult, setBulkResult] = useState<any>(null);
  const [bulkError, setBulkError] = useState<string | null>(null);

  async function handleBulkXlsb(file: File) {
    setBulkStatus("uploading");
    setBulkError(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload-book-xlsb", {
        method: "POST",
        body: formData,
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Erro desconhecido");
      setBulkResult(json);
      setBulkStatus("success");
      utils.book.getAvailableDates.invalidate();
      utils.book.getSheetTypes.invalidate();
      utils.book.getRecords.invalidate();
      utils.book.getKpisPorAgente.invalidate();
      const totalLinhas = json.resultados.reduce(
        (s: number, r: any) => s + r.totalRows,
        0
      );
      toast.success(
        `Import em massa concluído — ${totalLinhas.toLocaleString("pt-BR")} linhas em ${json.resultados.length} aba(s).`
      );
    } catch (e: any) {
      setBulkError(e.message || "Erro ao importar.");
      setBulkStatus("error");
      toast.error("Erro no import em massa: " + (e.message || ""));
    } finally {
      if (bulkInputRef.current) bulkInputRef.current.value = "";
    }
  }

  async function handleFile(file: File) {
    setStatus("uploading");
    setErrorMsg(null);
    try {
      const htmlContent: string = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = reject;
        reader.readAsText(file, "iso-8859-1");
      });
      const result = await processReport.mutateAsync({
        htmlContent,
        fileName: file.name,
      });
      setResultMsg(
        `${result.sheetLabel} — ${result.totalRows.toLocaleString("pt-BR")} linhas — referência ${result.referenceDate}`
      );
      setStatus("success");
      utils.book.getAvailableDates.invalidate();
      utils.book.getSheetTypes.invalidate();
      utils.book.getRecords.invalidate();
      toast.success("Aba do Book importada.");
    } catch (e: any) {
      setErrorMsg(e.message || "Erro ao importar.");
      setStatus("error");
      toast.error("Erro ao importar: " + (e.message || ""));
    } finally {
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  const { data: dates } = trpc.book.getAvailableDates.useQuery();
  const [selectedDate, setSelectedDate] = useState<string | undefined>(
    undefined
  );
  const effectiveDate = selectedDate ?? dates?.[0];

  const { data: sheetTypes } = trpc.book.getSheetTypes.useQuery(
    { referenceDate: effectiveDate! },
    { enabled: !!effectiveDate }
  );
  const [selectedSheet, setSelectedSheet] = useState<string | undefined>(
    undefined
  );
  const effectiveSheet = selectedSheet ?? sheetTypes?.[0]?.sheetType;

  const { data: recordsData, isLoading: loadingRecords } =
    trpc.book.getRecords.useQuery(
      { referenceDate: effectiveDate!, sheetType: effectiveSheet! },
      { enabled: !!effectiveDate && !!effectiveSheet }
    );

  const [search, setSearch] = useState("");
  const linhas = recordsData?.linhas ?? [];
  const colunas = recordsData?.colunas ?? [];

  const filtradas = useMemo(() => {
    if (!search) return linhas;
    const q = search.toLowerCase();
    return linhas.filter(
      l =>
        (l.agente || "").toLowerCase().includes(q) ||
        (l.campanha || "").toLowerCase().includes(q) ||
        (l.motivo || "").toLowerCase().includes(q)
    );
  }, [linhas, search]);

  // Achata pra ordenar por qualquer coluna (incluindo as genéricas dentro de `data`)
  const flatRows = useMemo<Record<string, any>[]>(
    () => filtradas.map(l => ({ ...l.data, __id: l.id })),
    [filtradas]
  );
  const { sorted, sortCol, sortDir, toggleSort } = useSortableRows(
    flatRows,
    colunas[0] || "__id",
    "asc"
  );

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <BookMarked className="w-5 h-5 text-yellow-400" />
          Book Operacional
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Relatório D-1 por campanha — import próprio, separado de TEMPOS/
          Performance em Tempo Real.
        </p>
      </div>

      {/* Import */}
      <div className="space-y-3">
        <div
          onClick={() => inputRef.current?.click()}
          className="border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all border-border hover:border-primary/50 hover:bg-card/50"
        >
          <input
            ref={inputRef}
            type="file"
            accept=".xls,.html,.htm,.txt"
            className="hidden"
            onChange={e => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
            }}
          />
          <div className="flex flex-col items-center gap-2">
            {status === "uploading" ? (
              <Loader2 className="w-6 h-6 text-primary animate-spin" />
            ) : (
              <Upload className="w-6 h-6 text-muted-foreground" />
            )}
            <p className="text-sm text-foreground font-medium">
              {status === "uploading"
                ? "Processando..."
                : "Clique para colar/selecionar o relatório do OLOS (qualquer aba do Book)"}
            </p>
            <p className="text-xs text-muted-foreground">
              Detecta sozinho se é B1, B2, B3, B4, BCampHC, BCamp ou B-abs pelo
              cabeçalho do relatório.
            </p>
          </div>
        </div>
        {status === "success" && resultMsg && (
          <div className="flex items-center gap-3 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-sm">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-emerald-300">{resultMsg}</span>
          </div>
        )}
        {status === "error" && errorMsg && (
          <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="text-red-300">{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Import em massa — o .xlsb original inteiro, meses de história de uma vez */}
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-yellow-400" />
          <h3 className="text-sm font-semibold text-foreground">
            Importar Book antigo (histórico completo)
          </h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Sobe o arquivo <b>.xlsb</b> original inteiro (o mesmo Book Excel de
          sempre) e importa todos os meses de uma vez — cada linha entra na data
          dela, não na data de hoje. Detecta sozinho B1, B2, B3, B4, BCampHC,
          BCamp e B-abs dentro do arquivo.
        </p>
        <input
          ref={bulkInputRef}
          type="file"
          accept=".xlsb,.xlsx,.xls"
          className="hidden"
          onChange={e => {
            const f = e.target.files?.[0];
            if (f) handleBulkXlsb(f);
          }}
        />
        <Button
          onClick={() => bulkInputRef.current?.click()}
          disabled={bulkStatus === "uploading"}
          variant="outline"
          className="gap-2"
        >
          {bulkStatus === "uploading" ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Upload className="w-4 h-4" />
          )}
          {bulkStatus === "uploading"
            ? "Processando (pode levar um tempo)..."
            : "Selecionar .xlsb do Book"}
        </Button>

        {bulkStatus === "success" && bulkResult && (
          <div className="space-y-1.5">
            {bulkResult.resultados.map((r: any) => (
              <div
                key={r.sheetType}
                className="flex items-center gap-2 text-xs text-emerald-300"
              >
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {r.sheetType}: {r.totalRows.toLocaleString("pt-BR")} linhas em{" "}
                  {r.datas} dia(s)
                  {r.semData > 0 &&
                    ` (${r.semData} linhas sem data válida, ignoradas)`}
                </span>
              </div>
            ))}
            {bulkResult.naoEncontradas?.length > 0 && (
              <p className="text-xs text-muted-foreground">
                Não encontradas no arquivo:{" "}
                {bulkResult.naoEncontradas.join(", ")}
              </p>
            )}
          </div>
        )}
        {bulkStatus === "error" && bulkError && (
          <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="text-red-300">{bulkError}</span>
          </div>
        )}
      </div>

      {!effectiveDate ? (
        <p className="text-sm text-muted-foreground py-10 text-center">
          Nenhuma aba do Book importada ainda — use a área acima.
        </p>
      ) : (
        <Tabs defaultValue="dados">
          <TabsList className="bg-card border border-border">
            <TabsTrigger value="dados" className="gap-1.5">
              <Table2 className="w-3.5 h-3.5" /> Dados Brutos
            </TabsTrigger>
            <TabsTrigger value="kpis" className="gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" /> KPIs por Agente
            </TabsTrigger>
            <TabsTrigger value="comparativo" className="gap-1.5">
              <BarChart3 className="w-3.5 h-3.5" /> Comparativo por Organização
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dados" className="space-y-4 mt-4">
            {/* Filtros */}
            <div className="flex items-center gap-3 flex-wrap">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <select
                value={effectiveDate}
                onChange={e => {
                  setSelectedDate(e.target.value);
                  setSelectedSheet(undefined);
                }}
                className="bg-card border border-border rounded-md text-sm px-2 py-1.5 text-foreground"
              >
                {(dates ?? []).map(d => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>

              <Layers className="w-4 h-4 text-muted-foreground ml-2" />
              <select
                value={effectiveSheet}
                onChange={e => setSelectedSheet(e.target.value)}
                className="bg-card border border-border rounded-md text-sm px-2 py-1.5 text-foreground"
              >
                {(sheetTypes ?? []).map(s => (
                  <option key={s.sheetType} value={s.sheetType}>
                    {s.label}
                  </option>
                ))}
              </select>

              <div className="relative ml-auto max-w-xs w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Buscar agente/campanha/motivo..."
                  className="pl-9"
                />
              </div>
            </div>

            {/* Tabela genérica — todas as colunas do relatório original */}
            <div className="rounded-xl border border-border overflow-hidden overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/40">
                  <tr>
                    {colunas.map(c => (
                      <th
                        key={c}
                        onClick={() => toggleSort(c)}
                        className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
                      >
                        {c}{" "}
                        {sortCol === c
                          ? sortDir === "desc"
                            ? "↓"
                            : "↑"
                          : "↕"}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loadingRecords ? (
                    <tr>
                      <td
                        colSpan={colunas.length || 1}
                        className="text-center py-8 text-muted-foreground"
                      >
                        Carregando...
                      </td>
                    </tr>
                  ) : sorted.length === 0 ? (
                    <tr>
                      <td
                        colSpan={colunas.length || 1}
                        className="text-center py-8 text-muted-foreground"
                      >
                        Nenhuma linha encontrada.
                      </td>
                    </tr>
                  ) : (
                    sorted.slice(0, 300).map((row, i) => (
                      <tr
                        key={row.__id ?? i}
                        className="border-t border-border/50 hover:bg-muted/20"
                      >
                        {colunas.map(c => (
                          <td key={c} className="px-3 py-1.5 whitespace-nowrap">
                            {row[c] ?? ""}
                          </td>
                        ))}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
              {sorted.length > 300 && (
                <p className="text-xs text-muted-foreground text-center py-2 border-t border-border/50">
                  Mostrando as primeiras 300 de{" "}
                  {sorted.length.toLocaleString("pt-BR")} linhas — use a busca
                  pra filtrar.
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="kpis" className="mt-4">
            <KpisPorAgenteTab />
          </TabsContent>

          <TabsContent value="comparativo" className="mt-4">
            <ComparativoTab />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

// ─── KPIs por Agente/Mês ─────────────────────────────────────────────────────
// Calculado a partir do BCampHC já importado, usando as fórmulas exatas
// documentadas na aba "Índice" da planilha original do Book.
function KpisPorAgenteTab() {
  const { data, isLoading } = trpc.book.getKpisPorAgente.useQuery();
  const [search, setSearch] = useState("");
  const [campanhaFiltro, setCampanhaFiltro] = useState("all");

  const linhas = data?.linhas ?? [];
  const filtradas = useMemo(() => {
    let rows = linhas;
    if (campanhaFiltro !== "all") {
      rows = rows.filter(l => l.campanha === campanhaFiltro);
    }
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(l => l.agente.toLowerCase().includes(q));
    }
    return rows;
  }, [linhas, search, campanhaFiltro]);

  const { sorted, sortCol, sortDir, toggleSort } = useSortableRows(
    filtradas,
    "atendidas",
    "desc"
  );

  // ── Dashboard: tendência mensal (soma de todos os agentes) ──────────────
  const tendenciaMensal = useMemo(() => {
    const porMes = new Map<
      string,
      {
        atendidas: number;
        cpc: number;
        acordo: number;
        tentativas: number;
        tempoFalando: number;
        tempoTabulacao: number;
        tempoLogado: number;
      }
    >();
    for (const l of linhas) {
      const e = porMes.get(l.anoMes) || {
        atendidas: 0,
        cpc: 0,
        acordo: 0,
        tentativas: 0,
        tempoFalando: 0,
        tempoTabulacao: 0,
        tempoLogado: 0,
      };
      e.atendidas += l.atendidas;
      e.cpc += l.cpc;
      e.acordo += l.acordo;
      e.tentativas += (l as any).tentativas ?? 0;
      e.tempoFalando += (l as any).tempoFalandoBruto ?? 0;
      e.tempoTabulacao += (l as any).tempoTabulacaoBruto ?? 0;
      e.tempoLogado += (l as any).tempoLogadoBruto ?? 0;
      porMes.set(l.anoMes, e);
    }
    return Array.from(porMes.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([mes, v]) => ({
        mes,
        atendidas: v.atendidas,
        pctCpc: v.atendidas > 0 ? (v.cpc / v.atendidas) * 100 : 0,
        pctAcordo: v.atendidas > 0 ? (v.acordo / v.atendidas) * 100 : 0,
        esforcoDiscagem: v.atendidas > 0 ? v.tentativas / v.atendidas : 0,
        tmaMin:
          v.atendidas > 0
            ? (v.tempoFalando + v.tempoTabulacao) / v.atendidas / 60
            : 0,
        pctOcupacao:
          v.tempoLogado > 0
            ? ((v.tempoFalando + v.tempoTabulacao) / v.tempoLogado) * 100
            : 0,
      }));
  }, [linhas]);

  // ── Dashboard: top 10 agentes do mês mais recente por % Acordo ──────────
  const topAgentesMesRecente = useMemo(() => {
    const meses = Array.from(new Set(linhas.map(l => l.anoMes))).sort();
    const ultimoMes = meses[meses.length - 1];
    if (!ultimoMes) return [];
    return linhas
      .filter(l => l.anoMes === ultimoMes && l.atendidas >= 20)
      .sort((a, b) => b.pctAcordo - a.pctAcordo)
      .slice(0, 10)
      .map(l => ({ nome: l.agente.split(" ")[0], pctAcordo: l.pctAcordo }));
  }, [linhas]);

  const Th = ({ col, label }: { col: string; label: string }) => (
    <th
      onClick={() => toggleSort(col)}
      className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
    >
      {label} {sortCol === col ? (sortDir === "desc" ? "↓" : "↑") : "↕"}
    </th>
  );

  if (isLoading) {
    return (
      <p className="text-sm text-muted-foreground py-10 text-center">
        Carregando...
      </p>
    );
  }

  if (linhas.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-10 text-center">
        Nenhum dado BCampHC importado ainda — essa aba precisa do relatório
        "Agente x Campanha" pra calcular os KPIs.
      </p>
    );
  }

  const fmtPct = (n: number) => `${n.toFixed(1)}%`;
  const fmtNum = (n: number) =>
    n.toLocaleString("pt-BR", { maximumFractionDigits: 1 });
  const fmtSeg = (n: number) => {
    const s = Math.round(n);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  return (
    <div className="space-y-4">
      {/* Dashboard interativo */}
      {tendenciaMensal.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {(() => {
            const atual = tendenciaMensal[tendenciaMensal.length - 1];
            const anterior = tendenciaMensal[tendenciaMensal.length - 2];
            const delta = (a: number, b?: number) =>
              b !== undefined && b > 0 ? ((a - b) / b) * 100 : null;
            const cards = [
              {
                label: "Esforço de Discagem",
                valor: `${atual.esforcoDiscagem.toFixed(1)}x`,
                sub: "tentativas por atendida",
                d: delta(atual.esforcoDiscagem, anterior?.esforcoDiscagem),
                menorEhMelhor: true,
              },
              {
                label: "TMA médio",
                valor: `${atual.tmaMin.toFixed(1)} min`,
                sub: "tempo médio de atendimento",
                d: delta(atual.tmaMin, anterior?.tmaMin),
                menorEhMelhor: true,
              },
              {
                label: "% Ocupação",
                valor: `${atual.pctOcupacao.toFixed(1)}%`,
                sub: "tempo falando+tabulando / logado",
                d: delta(atual.pctOcupacao, anterior?.pctOcupacao),
                menorEhMelhor: false,
              },
            ];
            return cards.map(c => (
              <div
                key={c.label}
                className="bg-card border border-border rounded-xl p-4"
              >
                <p className="text-xs text-muted-foreground">{c.label}</p>
                <div className="flex items-baseline gap-2 mt-1">
                  <p className="text-2xl font-bold text-foreground tabular-nums">
                    {c.valor}
                  </p>
                  {c.d !== null && (
                    <span
                      className={`text-xs font-medium ${
                        c.d > 0 !== c.menorEhMelhor
                          ? "text-emerald-400"
                          : "text-red-400"
                      }`}
                    >
                      {c.d > 0 ? "+" : ""}
                      {c.d.toFixed(1)}%
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-muted-foreground/70 mt-0.5">
                  {c.sub} · {atual.mes}
                </p>
              </div>
            ));
          })()}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Tendência mensal — % CPC vs % Acordo (todos os agentes)
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart
              data={tendenciaMensal}
              margin={{ top: 5, right: 20, left: 0, bottom: 0 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="oklch(0.25 0.012 240)"
              />
              <XAxis
                dataKey="mes"
                tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
              />
              <YAxis
                tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                unit="%"
              />
              <Tooltip
                formatter={(v: number) => `${v.toFixed(1)}%`}
                contentStyle={{
                  background: "#15171b",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line
                type="monotone"
                dataKey="pctCpc"
                name="% CPC"
                stroke="#06b6d4"
                strokeWidth={2}
                dot={{ r: 3 }}
              />
              <Line
                type="monotone"
                dataKey="pctAcordo"
                name="% Acordo"
                stroke="#22c55e"
                strokeWidth={2}
                dot={{ r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Top 10 % Acordo — mês mais recente (mín. 20 atendidas)
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart
              data={topAgentesMesRecente}
              layout="vertical"
              margin={{ top: 0, right: 30, left: 0, bottom: 0 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="oklch(0.25 0.012 240)"
                horizontal={false}
              />
              <XAxis
                type="number"
                unit="%"
                tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
              />
              <YAxis
                type="category"
                dataKey="nome"
                width={80}
                tick={{ fill: "oklch(0.65 0.01 240)", fontSize: 10 }}
              />
              <Tooltip
                formatter={(v: number) => `${v.toFixed(1)}%`}
                contentStyle={{
                  background: "#15171b",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Bar dataKey="pctAcordo" fill="#22c55e" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative max-w-xs w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar agente..."
            className="pl-9"
          />
        </div>
        <select
          value={campanhaFiltro}
          onChange={e => setCampanhaFiltro(e.target.value)}
          className="bg-card border border-border rounded-md text-sm px-2 py-1.5 text-foreground"
        >
          <option value="all">Todas as campanhas</option>
          {(data?.campanhasDisponiveis ?? []).map(c => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>
      <div className="rounded-xl border border-border overflow-hidden overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-muted/40">
            <tr>
              <th
                onClick={() => toggleSort("agente")}
                className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
              >
                Agente{" "}
                {sortCol === "agente" ? (sortDir === "desc" ? "↓" : "↑") : "↕"}
              </th>
              <th
                onClick={() => toggleSort("campanha")}
                className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
              >
                Campanha{" "}
                {sortCol === "campanha"
                  ? sortDir === "desc"
                    ? "↓"
                    : "↑"
                  : "↕"}
              </th>
              <th
                onClick={() => toggleSort("anoMes")}
                className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
              >
                Mês{" "}
                {sortCol === "anoMes" ? (sortDir === "desc" ? "↓" : "↑") : "↕"}
              </th>
              <th className="text-center px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">
                Quartil
              </th>
              <Th col="du" label="DU" />
              <Th col="atendidas" label="Atendidas" />
              <Th col="cpc" label="CPC" />
              <Th col="acordo" label="Acordo" />
              <Th col="pctCpc" label="% CPC" />
              <Th col="pctAcordo" label="% Acordo" />
              <Th col="pctAcordoCpc" label="% Acordo-CPC" />
              <Th col="pctAlo" label="% Alô" />
              <Th col="tma" label="TMA" />
              <Th col="pctOcupacao" label="% Ocupação" />
              <Th col="pctPausa" label="% Pausa" />
              <Th col="pctIdle" label="% Idle" />
              <Th col="atendDU" label="Atend/DU" />
              <Th col="cpcDU" label="CPC/DU" />
              <Th col="acordoDU" label="Acordo/DU" />
            </tr>
          </thead>
          <tbody>
            {sorted.map((l, i) => (
              <tr
                key={`${l.agente}-${l.anoMes}-${i}`}
                className="border-t border-border/50 hover:bg-muted/20"
              >
                <td className="px-3 py-1.5 font-medium text-foreground whitespace-nowrap">
                  {l.agente}
                </td>
                <td className="px-3 py-1.5 text-muted-foreground whitespace-nowrap">
                  {l.campanha}
                </td>
                <td className="px-3 py-1.5 text-muted-foreground whitespace-nowrap">
                  {l.anoMes}
                </td>
                <td className="px-3 py-1.5 text-center">
                  {l.quartil && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                        l.quartil === "Q1"
                          ? "bg-emerald-500/15 text-emerald-400"
                          : l.quartil === "Q2"
                            ? "bg-blue-500/15 text-blue-400"
                            : l.quartil === "Q3"
                              ? "bg-amber-500/15 text-amber-400"
                              : "bg-red-500/15 text-red-400"
                      }`}
                    >
                      {l.quartil}
                    </span>
                  )}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">{l.du}</td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.atendidas)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.cpc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.acordo)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctCpc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctAcordo)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctAcordoCpc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctAlo)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums font-mono">
                  {fmtSeg(l.tma)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctOcupacao)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctPausa)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctIdle)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.atendDU)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.cpcDU)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.acordoDU)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-[11px] text-muted-foreground/70 italic">
        Fórmulas exatamente como documentadas na aba "Índice" da planilha
        original: % CPC = CPC/Atendidas, % Acordo = Acordo/Atendidas, %
        Acordo-CPC = Acordo/CPC, DU = dias distintos com dado importado no mês.
        Quartil = ranking de % Acordo dentro do mesmo mês (mín. 10 atendidas pra
        entrar no ranking).
      </p>
    </div>
  );
}

// ─── Comparativo por Organização × Mês ──────────────────────────────────────
// A organização não vem no relatório BCampHC (só Agente x Campanha) — usa o
// mapeamento campanha -> organização que já existe em discagem_records
// (vem certo da OLOS, calculado no backend).
const CORES_ORG = [
  "#8b5cf6",
  "#06b6d4",
  "#f59e0b",
  "#10b981",
  "#ef4444",
  "#3b82f6",
  "#ec4899",
  "#84cc16",
  "#f97316",
  "#6366f1",
];
const METRICAS_COMPARATIVO = [
  { key: "atendidas", label: "Atendidas" },
  { key: "tentativas", label: "Tentativas" },
  { key: "pctAlo", label: "% Alô" },
  { key: "cpc", label: "CPC" },
  { key: "pctCpc", label: "% CPC" },
  { key: "acordo", label: "Acordo" },
  { key: "pctAcordo", label: "% Acordo" },
] as const;

function ComparativoTab() {
  const { data, isLoading } = trpc.book.getComparativoOrganizacao.useQuery();
  const [metrica, setMetrica] =
    useState<(typeof METRICAS_COMPARATIVO)[number]["key"]>("atendidas");
  const [orgsSelecionadas, setOrgsSelecionadas] = useState<string[]>([]);

  const linhas = data?.linhas ?? [];
  const organizacoes = data?.organizacoesDisponiveis ?? [];

  const { sorted, sortCol, sortDir, toggleSort } = useSortableRows(
    linhas,
    "anoMes",
    "desc"
  );

  const Th = ({ col, label }: { col: string; label: string }) => (
    <th
      onClick={() => toggleSort(col)}
      className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
    >
      {label} {sortCol === col ? (sortDir === "desc" ? "↓" : "↑") : "↕"}
    </th>
  );

  // Gráfico: uma linha por organização (ou só as selecionadas, se houver)
  const chartData = useMemo(() => {
    const orgsNoGrafico =
      orgsSelecionadas.length > 0 ? orgsSelecionadas : organizacoes.slice(0, 6);
    const porMes = new Map<string, Record<string, any>>();
    for (const l of linhas) {
      if (!orgsNoGrafico.includes(l.organizacao)) continue;
      const row = porMes.get(l.anoMes) || { mes: l.anoMes };
      row[l.organizacao] = (l as any)[metrica];
      porMes.set(l.anoMes, row);
    }
    return Array.from(porMes.values()).sort((a, b) =>
      a.mes.localeCompare(b.mes)
    );
  }, [linhas, organizacoes, orgsSelecionadas, metrica]);

  const orgsNoGrafico =
    orgsSelecionadas.length > 0 ? orgsSelecionadas : organizacoes.slice(0, 6);

  function toggleOrg(org: string) {
    setOrgsSelecionadas(prev =>
      prev.includes(org) ? prev.filter(o => o !== org) : [...prev, org]
    );
  }

  if (isLoading) {
    return (
      <p className="text-sm text-muted-foreground py-10 text-center">
        Carregando...
      </p>
    );
  }

  if (linhas.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-10 text-center">
        Nenhum dado disponível ainda — precisa do BCampHC importado e de
        discagem sincronizada (é o cruzamento das duas fontes que dá a
        organização de cada campanha).
      </p>
    );
  }

  const fmtNum = (n: number) =>
    n.toLocaleString("pt-BR", { maximumFractionDigits: 1 });
  const fmtPct = (n: number) => `${n.toFixed(1)}%`;

  return (
    <div className="space-y-4">
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Tendência por organização
          </h3>
          <select
            value={metrica}
            onChange={e => setMetrica(e.target.value as any)}
            className="bg-background border border-border rounded-md text-xs px-2 py-1 text-foreground"
          >
            {METRICAS_COMPARATIVO.map(m => (
              <option key={m.key} value={m.key}>
                {m.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap gap-1.5 mb-4">
          {organizacoes.map((org, i) => {
            const ativa = orgsNoGrafico.includes(org);
            const cor = CORES_ORG[i % CORES_ORG.length];
            return (
              <button
                key={org}
                onClick={() => toggleOrg(org)}
                className={
                  ativa
                    ? "text-xs px-2.5 py-1 rounded-full border"
                    : "text-xs px-2.5 py-1 rounded-full border border-border text-muted-foreground/50"
                }
                style={
                  ativa
                    ? {
                        borderColor: cor,
                        color: cor,
                        backgroundColor: `${cor}15`,
                      }
                    : undefined
                }
              >
                {org}
              </button>
            );
          })}
        </div>

        <ResponsiveContainer width="100%" height={280}>
          <LineChart
            data={chartData}
            margin={{ top: 5, right: 20, left: 0, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
            <XAxis dataKey="mes" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} />
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            {orgsNoGrafico.map((org, i) => (
              <Line
                key={org}
                type="monotone"
                dataKey={org}
                stroke={CORES_ORG[i % CORES_ORG.length]}
                strokeWidth={2}
                dot={{ r: 3 }}
                connectNulls
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="rounded-xl border border-border overflow-hidden overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-muted/40">
            <tr>
              <th
                onClick={() => toggleSort("organizacao")}
                className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
              >
                Organização{" "}
                {sortCol === "organizacao"
                  ? sortDir === "desc"
                    ? "↓"
                    : "↑"
                  : "↕"}
              </th>
              <th
                onClick={() => toggleSort("anoMes")}
                className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap cursor-pointer hover:text-foreground select-none"
              >
                Mês{" "}
                {sortCol === "anoMes" ? (sortDir === "desc" ? "↓" : "↑") : "↕"}
              </th>
              <Th col="tentativas" label="Tentativas" />
              <Th col="atendidas" label="Atendidas" />
              <Th col="pctAlo" label="% Alô" />
              <Th col="cpc" label="CPC" />
              <Th col="pctCpc" label="% CPC" />
              <Th col="acordo" label="Acordo" />
              <Th col="pctAcordo" label="% Acordo" />
            </tr>
          </thead>
          <tbody>
            {sorted.map((l, i) => (
              <tr
                key={`${l.organizacao}-${l.anoMes}-${i}`}
                className="border-t border-border/50 hover:bg-muted/20"
              >
                <td className="px-3 py-1.5 font-medium text-foreground whitespace-nowrap">
                  {l.organizacao}
                </td>
                <td className="px-3 py-1.5 text-muted-foreground whitespace-nowrap">
                  {l.anoMes}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.tentativas)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.atendidas)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctAlo)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.cpc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctCpc)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtNum(l.acordo)}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">
                  {fmtPct(l.pctAcordo)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
