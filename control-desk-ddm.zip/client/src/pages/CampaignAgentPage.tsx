import { Fragment, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SyncNowButtons from "@/components/SyncNowButtons";
import {
  Calendar,
  ChevronDown,
  ChevronRight,
  Info,
  Phone,
  Search,
  Building2,
  ShieldAlert,
  Clock,
  Voicemail,
  PhoneOff,
  VolumeX,
  HelpCircle,
  GraduationCap,
  Lightbulb,
  Target,
  BookOpen,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  LabelList,
} from "recharts";
import { toast } from "sonner";

// Performance por Campanha — alimentada pela sincronização automática com
// o banco espelho da OLOS (bilhetagem + tentativas_contato), não mais pelo
// dump manual do TabAuto.
// Funil: Discagens → Atendidas → CPC → CPCA → Promessa (ver server/discagemClassifier.ts).
// "Mailing" também vem automático (COUNT DISTINCT mailing_registro_id) —
// SPIN = Discagens / Mailing.

function pct(n: number) {
  return `${n.toFixed(1)}%`;
}

export default function CampaignAgentPage() {
  const [selectedDate, setSelectedDate] = useState<string | undefined>(
    undefined
  );
  const { data: dates, isLoading: datesLoading } =
    trpc.dashboard.getDiscagemAvailableDates.useQuery();
  const effectiveDate = selectedDate ?? dates?.[0];

  const { data, isLoading } = trpc.dashboard.getDiscagemPorCampanha.useQuery(
    { referenceDate: effectiveDate },
    { enabled: !!effectiveDate }
  );

  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const campanhas = data?.campanhas ?? [];

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return campanhas.filter(
      c =>
        c.campanha.toLowerCase().includes(q) ||
        c.organizacao.toLowerCase().includes(q)
    );
  }, [campanhas, search]);

  function toggleExpand(key: string) {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  if (datesLoading || (isLoading && effectiveDate)) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    );
  }

  if (!effectiveDate) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-3 text-center">
        <Phone className="w-10 h-10 text-muted-foreground/40" />
        <p className="text-foreground font-medium">
          Nenhum dump de discagem importado ainda
        </p>
        <p className="text-sm text-muted-foreground max-w-sm">
          Importe o dump TabAuto na tela "Importar Dado" para ver a performance
          por campanha.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground">
            Performance por Campanha
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Funil de discagem: Discagens → Atendidas → CPC → CPCA → Promessa
          </p>
        </div>
        <div className="flex items-center gap-2">
          <SyncNowButtons kinds={["discagem", "mailing"]} />
          <Calendar className="w-4 h-4 text-muted-foreground" />
          <select
            value={effectiveDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="bg-card border border-border rounded-md text-sm px-2 py-1.5 text-foreground"
          >
            {(dates ?? []).map(d => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
      </div>

      <Tabs defaultValue="geral">
        <TabsList className="bg-card border border-border">
          <TabsTrigger value="geral" className="gap-1.5">
            Todas as Campanhas
          </TabsTrigger>
          <TabsTrigger value="organizacao" className="gap-1.5">
            <Building2 className="w-3.5 h-3.5" /> Por Organização
          </TabsTrigger>
          <TabsTrigger value="qualidade" className="gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5" /> Qualidade Técnica
          </TabsTrigger>
          <TabsTrigger value="conformidade" className="gap-1.5">
            <Clock className="w-3.5 h-3.5" /> Conformidade
          </TabsTrigger>
          <TabsTrigger value="assistencia" className="gap-1.5">
            <GraduationCap className="w-3.5 h-3.5" /> Assistência
          </TabsTrigger>
        </TabsList>

        <TabsContent value="geral" className="space-y-5 mt-4">
          <div className="flex items-start gap-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg text-xs text-blue-300">
            <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
            <span>
              "Mailing" vem direto do banco (quantidade de registros discados na
              campanha), sincronizado automaticamente — não é mais digitado à
              mão. Clique na seta pra ver o detalhe de "CPCA sem Conversão".
            </span>
          </div>

          <div className="relative max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar campanha ou organização..."
              className="pl-9"
            />
          </div>

          <div className="rounded-xl border border-border overflow-hidden overflow-x-auto">
            <table className="w-full text-sm min-w-[900px]">
              <thead className="bg-muted/40">
                <tr>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground w-8"></th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">
                    Organização
                  </th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">
                    Campanha
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    Mailing
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    Discagens
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    SPIN
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    Atendidas
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    CPC
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    CPCA
                  </th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                    Promessa
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(c => {
                  const key = `${c.organizacao}|${c.campanha}`;
                  const isExpanded = expanded.has(key);
                  return (
                    <Fragment key={key}>
                      <tr className="border-t border-border/50 hover:bg-muted/20">
                        <td className="px-3 py-2">
                          <button
                            onClick={() => toggleExpand(key)}
                            className="text-muted-foreground"
                          >
                            {isExpanded ? (
                              <ChevronDown className="w-4 h-4" />
                            ) : (
                              <ChevronRight className="w-4 h-4" />
                            )}
                          </button>
                        </td>
                        <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">
                          {c.organizacao}
                        </td>
                        <td className="px-3 py-2 font-medium text-foreground whitespace-nowrap">
                          {c.campanha}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums text-foreground">
                          {c.mailing > 0
                            ? c.mailing.toLocaleString("pt-BR")
                            : "—"}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          {c.discagens.toLocaleString("pt-BR")}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          {c.spin != null ? c.spin.toFixed(2) : "—"}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          {c.atendidas.toLocaleString("pt-BR")}{" "}
                          <span className="text-xs text-muted-foreground">
                            ({pct(c.pctAtendidas)})
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          {c.cpc.toLocaleString("pt-BR")}{" "}
                          <span className="text-xs text-muted-foreground">
                            ({pct(c.pctCpc)})
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          {c.cpca.toLocaleString("pt-BR")}{" "}
                          <span className="text-xs text-muted-foreground">
                            ({pct(c.pctCpca)})
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          {c.promessa.toLocaleString("pt-BR")}{" "}
                          <span className="text-xs text-muted-foreground">
                            ({pct(c.pctPromessa)})
                          </span>
                        </td>
                      </tr>
                      {isExpanded && (
                        <tr className="bg-muted/10">
                          <td></td>
                          <td colSpan={9} className="px-3 py-3">
                            <p className="text-xs font-semibold text-muted-foreground mb-2">
                              CPCA sem Conversão
                            </p>
                            {c.cpcaSemConversao.length === 0 ? (
                              <p className="text-xs text-muted-foreground italic">
                                Nenhuma ocorrência.
                              </p>
                            ) : (
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="text-muted-foreground">
                                    <th className="text-left font-normal py-1">
                                      Motivo
                                    </th>
                                    <th className="text-right font-normal py-1">
                                      Quantidade
                                    </th>
                                    <th className="text-right font-normal py-1">
                                      % Representatividade
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {c.cpcaSemConversao.map(s => (
                                    <tr
                                      key={s.status}
                                      className="border-t border-border/30"
                                    >
                                      <td className="py-1">{s.status}</td>
                                      <td className="py-1 text-right tabular-nums">
                                        {s.quantidade}
                                      </td>
                                      <td className="py-1 text-right tabular-nums">
                                        {s.pctRepresentatividade.toFixed(1)}%
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            )}
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="p-8 text-center text-sm text-muted-foreground">
                Nenhuma campanha encontrada.
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="organizacao" className="mt-4">
          <PorOrganizacaoTab campanhas={campanhas} />
        </TabsContent>

        <TabsContent value="qualidade" className="mt-4">
          <QualidadeTecnicaTab />
        </TabsContent>

        <TabsContent value="conformidade" className="mt-4">
          <ConformidadeTab />
        </TabsContent>

        <TabsContent value="assistencia" className="mt-4">
          <AssistenciaTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ─── Aba: visão única de uma organização (Anima, Cruzeiro, Vero...) ─────────
// Agrupa por "organizacao" — ex: Anima_EAD, Anima_Manual, Anima_Presencial_Ativo
// e Way_Receptivo_Anima todos entram juntos em "ANIMA".
function PorOrganizacaoTab({ campanhas }: { campanhas: any[] }) {
  const organizacoes = useMemo(
    () => Array.from(new Set(campanhas.map(c => c.organizacao))).sort(),
    [campanhas]
  );
  const [selected, setSelected] = useState<string>("");
  const org = selected || organizacoes[0] || "";

  const campanhasDaOrg = useMemo(
    () => campanhas.filter(c => c.organizacao === org),
    [campanhas, org]
  );

  const totais = useMemo(() => {
    const acc = { discagens: 0, atendidas: 0, cpc: 0, cpca: 0, promessa: 0 };
    const cpcaSemConversaoMap: Record<string, number> = {};
    for (const c of campanhasDaOrg) {
      acc.discagens += c.discagens;
      acc.atendidas += c.atendidas;
      acc.cpc += c.cpc;
      acc.cpca += c.cpca;
      acc.promessa += c.promessa;
      for (const s of c.cpcaSemConversao) {
        cpcaSemConversaoMap[s.status] =
          (cpcaSemConversaoMap[s.status] || 0) + s.quantidade;
      }
    }
    const totalSemConv = Object.values(cpcaSemConversaoMap).reduce(
      (a, b) => a + b,
      0
    );
    const cpcaSemConversao = Object.entries(cpcaSemConversaoMap)
      .map(([status, quantidade]) => ({
        status,
        quantidade,
        pctRepresentatividade:
          totalSemConv > 0 ? (quantidade / totalSemConv) * 100 : 0,
      }))
      .sort((a, b) => b.quantidade - a.quantidade);
    return { ...acc, cpcaSemConversao };
  }, [campanhasDaOrg]);

  if (organizacoes.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-8 text-center">
        Nenhum dado disponível.
      </p>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <Building2 className="w-4 h-4 text-muted-foreground" />
        <select
          value={org}
          onChange={e => setSelected(e.target.value)}
          className="bg-card border border-border rounded-md text-sm px-2 py-1.5 text-foreground"
        >
          {organizacoes.map(o => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
        <span className="text-xs text-muted-foreground">
          {campanhasDaOrg.length} campanha(s) nessa organização
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Discagens", value: totais.discagens },
          {
            label: "Atendidas",
            value: totais.atendidas,
            pct:
              totais.discagens > 0
                ? (totais.atendidas / totais.discagens) * 100
                : 0,
          },
          {
            label: "CPC",
            value: totais.cpc,
            pct:
              totais.atendidas > 0 ? (totais.cpc / totais.atendidas) * 100 : 0,
          },
          {
            label: "CPCA",
            value: totais.cpca,
            pct: totais.cpc > 0 ? (totais.cpca / totais.cpc) * 100 : 0,
          },
          {
            label: "Promessa",
            value: totais.promessa,
            pct: totais.cpca > 0 ? (totais.promessa / totais.cpca) * 100 : 0,
          },
        ].map(kpi => (
          <div
            key={kpi.label}
            className="bg-card border border-border rounded-xl p-4"
          >
            <div className="text-xs text-muted-foreground">{kpi.label}</div>
            <div className="text-2xl font-bold text-foreground mt-1">
              {kpi.value.toLocaleString("pt-BR")}
            </div>
            {kpi.pct !== undefined && (
              <div className="text-xs text-muted-foreground mt-0.5">
                {kpi.pct.toFixed(1)}%
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Dashboard: funil visual + top campanhas por discagem */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Funil da organização
          </h3>
          {(() => {
            const funilData = [
              { etapa: "Discagens", valor: totais.discagens },
              { etapa: "Atendidas", valor: totais.atendidas },
              { etapa: "CPC", valor: totais.cpc },
              { etapa: "CPCA", valor: totais.cpca },
              { etapa: "Promessa", valor: totais.promessa },
            ];
            const cores = [
              "#64748b",
              "#3b82f6",
              "#06b6d4",
              "#14b8a6",
              "#22c55e",
            ];
            return (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  data={funilData}
                  layout="vertical"
                  margin={{ top: 0, right: 50, left: 0, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.25 0.012 240)"
                    horizontal={false}
                  />
                  <XAxis
                    type="number"
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                  />
                  <YAxis
                    type="category"
                    dataKey="etapa"
                    width={80}
                    tick={{ fill: "oklch(0.65 0.01 240)", fontSize: 11 }}
                  />
                  <Tooltip
                    formatter={(v: number) => v.toLocaleString("pt-BR")}
                    contentStyle={{
                      background: "#15171b",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="valor" radius={[0, 4, 4, 0]}>
                    {funilData.map((_, i) => (
                      <Cell key={i} fill={cores[i]} />
                    ))}
                    <LabelList
                      dataKey="valor"
                      position="right"
                      formatter={(v: number) => v.toLocaleString("pt-BR")}
                      style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            );
          })()}
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Discagens por campanha
          </h3>
          {(() => {
            const chartData = [...campanhasDaOrg]
              .sort((a, b) => b.discagens - a.discagens)
              .slice(0, 8)
              .map(c => ({
                nome:
                  c.campanha.length > 18
                    ? c.campanha.slice(0, 18) + "…"
                    : c.campanha,
                discagens: c.discagens,
              }));
            return (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  data={chartData}
                  layout="vertical"
                  margin={{ top: 0, right: 50, left: 0, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.25 0.012 240)"
                    horizontal={false}
                  />
                  <XAxis
                    type="number"
                    tick={{ fill: "oklch(0.55 0.01 240)", fontSize: 10 }}
                  />
                  <YAxis
                    type="category"
                    dataKey="nome"
                    width={110}
                    tick={{ fill: "oklch(0.65 0.01 240)", fontSize: 10 }}
                  />
                  <Tooltip
                    formatter={(v: number) => v.toLocaleString("pt-BR")}
                    contentStyle={{
                      background: "#15171b",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="discagens" fill="#f97316" radius={[0, 4, 4, 0]}>
                    <LabelList
                      dataKey="discagens"
                      position="right"
                      formatter={(v: number) => v.toLocaleString("pt-BR")}
                      style={{ fill: "oklch(0.7 0.01 240)", fontSize: 10 }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            );
          })()}
        </div>
      </div>

      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40">
            <tr>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">
                Campanha
              </th>
              <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                Discagens
              </th>
              <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                Atendidas
              </th>
              <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                CPC
              </th>
              <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                CPCA
              </th>
              <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                Promessa
              </th>
            </tr>
          </thead>
          <tbody>
            {campanhasDaOrg.map(c => (
              <tr key={c.campanha} className="border-t border-border/50">
                <td className="px-3 py-2 font-medium text-foreground">
                  {c.campanha}
                </td>
                <td className="px-3 py-2 text-right tabular-nums">
                  {c.discagens.toLocaleString("pt-BR")}
                </td>
                <td className="px-3 py-2 text-right tabular-nums">
                  {c.atendidas.toLocaleString("pt-BR")}{" "}
                  <span className="text-xs text-muted-foreground">
                    ({pct(c.pctAtendidas)})
                  </span>
                </td>
                <td className="px-3 py-2 text-right tabular-nums">
                  {c.cpc.toLocaleString("pt-BR")}{" "}
                  <span className="text-xs text-muted-foreground">
                    ({pct(c.pctCpc)})
                  </span>
                </td>
                <td className="px-3 py-2 text-right tabular-nums">
                  {c.cpca.toLocaleString("pt-BR")}{" "}
                  <span className="text-xs text-muted-foreground">
                    ({pct(c.pctCpca)})
                  </span>
                </td>
                <td className="px-3 py-2 text-right tabular-nums">
                  {c.promessa.toLocaleString("pt-BR")}{" "}
                  <span className="text-xs text-muted-foreground">
                    ({pct(c.pctPromessa)})
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-card border border-border rounded-xl p-4">
        <h3 className="text-xs font-semibold text-muted-foreground mb-3">
          CPCA sem Conversão (consolidado da organização)
        </h3>
        {totais.cpcaSemConversao.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">
            Nenhuma ocorrência.
          </p>
        ) : (
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted-foreground">
                <th className="text-left font-normal py-1">Motivo</th>
                <th className="text-right font-normal py-1">Quantidade</th>
                <th className="text-right font-normal py-1">
                  % Representatividade
                </th>
              </tr>
            </thead>
            <tbody>
              {totais.cpcaSemConversao.map(s => (
                <tr key={s.status} className="border-t border-border/30">
                  <td className="py-1">{s.status}</td>
                  <td className="py-1 text-right tabular-nums">
                    {s.quantidade}
                  </td>
                  <td className="py-1 text-right tabular-nums">
                    {s.pctRepresentatividade.toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ─── Aba: Qualidade Técnica (caixa postal, caiu/desligou, mudo) ─────────────
// Compara dia a dia — % da discagem que "morreu" em ruído técnico, não em
// simples não-atendimento. Ajuda a identificar rota ruim (tabela por rota
// do dia mais recente) e tendência ao longo do tempo.
// ─── Conformidade de Horário ────────────────────────────────────────────────
// Prática de cobrança recomendada (e exigida em boa parte das regras
// setoriais/CDC): contato só entre 8h-20h, sem domingo. Calculado a partir
// de discagem_records que já está sincronizado — sem chamada nova à OLOS.
function ConformidadeTab() {
  const { data, isLoading } = trpc.dashboard.getConformidadeHorario.useQuery(
    {}
  );

  if (isLoading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    );
  }

  const campanhas = data?.campanhas ?? [];
  const totalForaHorario = campanhas.reduce((s, c) => s + c.foraHorario, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg text-xs text-blue-300">
        <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
        <span>
          Considera fora do horário permitido: ligações antes das 8h ou depois
          das 20h, ou qualquer ligação num domingo. Referência:{" "}
          {data?.referenceDate || "—"}
          {data?.ehDomingo &&
            " (domingo — todo o dia conta como fora do horário)"}
          .
        </span>
      </div>

      {campanhas.length === 0 ? (
        <div className="bg-card border border-emerald-500/20 rounded-xl p-8 text-center">
          <p className="text-sm text-emerald-400 font-medium">
            Nenhuma ligação fora do horário nesse dia.
          </p>
        </div>
      ) : (
        <div className="rounded-xl border border-border overflow-hidden">
          <div className="px-4 py-2.5 bg-red-500/10 border-b border-red-500/20 flex items-center justify-between">
            <span className="text-sm font-semibold text-red-300">
              {totalForaHorario.toLocaleString("pt-BR")} ligação(ões) fora do
              horário permitido
            </span>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                  Organização
                </th>
                <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                  Campanha
                </th>
                <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                  Total
                </th>
                <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                  Fora do Horário
                </th>
                <th className="text-right px-4 py-2 font-medium text-muted-foreground">
                  %
                </th>
              </tr>
            </thead>
            <tbody>
              {campanhas.map(c => (
                <tr
                  key={`${c.organizacao}-${c.campanha}`}
                  className="border-t border-border/50"
                >
                  <td className="px-4 py-2 text-muted-foreground">
                    {c.organizacao}
                  </td>
                  <td className="px-4 py-2 font-medium text-foreground">
                    {c.campanha}
                  </td>
                  <td className="px-4 py-2 text-right tabular-nums">
                    {c.total.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-4 py-2 text-right tabular-nums text-red-400 font-semibold">
                    {c.foraHorario.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-4 py-2 text-right tabular-nums">
                    {c.pctForaHorario.toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function QualidadeTecnicaTab() {
  const { data, isLoading } = trpc.dashboard.getQualidadeTecnica.useQuery({});

  if (isLoading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    );
  }

  const porDia = data?.porDia ?? [];
  const porRota = data?.porRota ?? [];

  if (porDia.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-8 text-center">
        Nenhum dado disponível.
      </p>
    );
  }

  return (
    <div className="space-y-6">
      <RuidoLegenda />

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Comparativo por dia
        </h3>
        <div className="rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">
                  Data
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Discagens
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Caixa Postal
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Caiu/Desligou
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Mudo
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Outros
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  % Ruído Total
                </th>
              </tr>
            </thead>
            <tbody>
              {porDia.map((d: any) => (
                <tr key={d.referenceDate} className="border-t border-border/50">
                  <td className="px-3 py-2 font-medium text-foreground">
                    {d.referenceDate}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {d.discagens.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {d.caixaPostal.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {d.caiuDesligou.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {d.mudo.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {d.outroRuido.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    <span
                      className={
                        d.pctRuido > 15
                          ? "text-red-400 font-semibold"
                          : d.pctRuido > 8
                            ? "text-yellow-400"
                            : "text-emerald-400"
                      }
                    >
                      {d.pctRuido.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Por rota — {data?.referenciaRota} (dia mais recente)
        </h3>
        <div className="rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">
                  Rota
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Discagens
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  Ruído Total
                </th>
                <th className="text-right px-3 py-2 font-medium text-muted-foreground">
                  % Ruído
                </th>
              </tr>
            </thead>
            <tbody>
              {porRota.map((r: any) => (
                <tr key={r.rota} className="border-t border-border/50">
                  <td className="px-3 py-2 font-medium text-foreground">
                    {r.rota}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {r.discagens.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {r.totalRuido.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    <span
                      className={
                        r.pctRuido > 15
                          ? "text-red-400 font-semibold"
                          : r.pctRuido > 8
                            ? "text-yellow-400"
                            : "text-emerald-400"
                      }
                    >
                      {r.pctRuido.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Legenda do "Ruído Técnico" ─────────────────────────────────────────────
// Explicação expansível pra quem não acompanha o dia a dia de discagem
// entender rápido o que cada categoria significa.
function RuidoLegenda() {
  const [aberto, setAberto] = useState(false);

  const categorias = [
    {
      icon: Voicemail,
      nome: "Caixa Postal",
      cor: "text-orange-400 bg-orange-500/10",
      explicacao:
        'A ligação caiu direto na caixa postal do número — ninguém atendeu de verdade. Aparece no dump como status tipo "Caixa Postal" / "Voice Mail".',
    },
    {
      icon: PhoneOff,
      nome: "Caiu/Desligou",
      cor: "text-red-400 bg-red-500/10",
      explicacao:
        "A ligação foi completada mas caiu ou foi derrubada no meio, antes de qualquer conversa acontecer — sinal de instabilidade na rota ou na operadora.",
    },
    {
      icon: VolumeX,
      nome: "Mudo/Muda",
      cor: "text-purple-400 bg-purple-500/10",
      explicacao:
        "A ligação conectou, mas sem áudio (silêncio) ou com áudio cortado/chiado a ponto de inviabilizar a conversa.",
    },
    {
      icon: HelpCircle,
      nome: "Outros",
      cor: "text-gray-400 bg-gray-500/10",
      explicacao:
        "Erro de sistema, número inválido, falha da operadora, fax — qualquer outra falha técnica antes de chegar num ser humano.",
    },
  ];

  return (
    <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 overflow-hidden">
      <button
        onClick={() => setAberto(o => !o)}
        className="w-full flex items-center justify-between gap-2 p-3 text-left"
      >
        <div className="flex items-center gap-2 text-xs text-amber-300">
          <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
          <span>
            <b>O que é "Ruído"?</b> Problema técnico de rota — diferente de "não
            atendeu". Clique para ver a legenda completa.
          </span>
        </div>
        {aberto ? (
          <ChevronDown className="w-4 h-4 text-amber-300 shrink-0" />
        ) : (
          <ChevronRight className="w-4 h-4 text-amber-300 shrink-0" />
        )}
      </button>

      {aberto && (
        <div className="px-3 pb-4 space-y-3">
          <p className="text-xs text-muted-foreground">
            <b>Não Atendeu</b> = o cliente decidiu não atender (comportamento da
            pessoa). <b>Ruído</b> = a ligação nem chegou direito até o cliente
            (problema técnico da rota/operadora, sem relação com agente ou
            cliente).
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {categorias.map(c => (
              <div
                key={c.nome}
                className={`rounded-lg p-3 flex gap-2.5 ${c.cor}`}
              >
                <c.icon className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold">{c.nome}</p>
                  <p className="text-[11px] opacity-80 mt-0.5 leading-snug">
                    {c.explicacao}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground italic">
            % Ruído Total = (Caixa Postal + Caiu/Desligou + Mudo + Outros) ÷
            Discagens. Serve pra decisão de infraestrutura/rota — não é métrica
            de desempenho do agente.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Assistência — cheat-sheet de discagem pra controllers/analistas ────────
// Referência rápida com o que já está validado no sistema. Vamos evoluir com
// mais conteúdo aos poucos.
function AssistenciaTab() {
  const [aberto, setAberto] = useState<string | null>("funil");

  const Secao = ({
    id,
    icon: Icon,
    titulo,
    children,
  }: {
    id: string;
    icon: any;
    titulo: string;
    children: React.ReactNode;
  }) => {
    const isOpen = aberto === id;
    return (
      <div className="rounded-xl border border-border overflow-hidden bg-card">
        <button
          onClick={() => setAberto(isOpen ? null : id)}
          className="w-full flex items-center justify-between gap-2 p-4 text-left hover:bg-muted/20"
        >
          <div className="flex items-center gap-2.5">
            <Icon className="w-4 h-4 text-primary shrink-0" />
            <span className="text-sm font-semibold text-foreground">
              {titulo}
            </span>
          </div>
          {isOpen ? (
            <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
          ) : (
            <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
          )}
        </button>
        {isOpen && <div className="px-4 pb-4 space-y-3">{children}</div>}
      </div>
    );
  };

  const Termo = ({ nome, def }: { nome: string; def: string }) => (
    <div className="flex gap-2 text-xs">
      <span className="font-semibold text-foreground shrink-0 w-24">
        {nome}
      </span>
      <span className="text-muted-foreground">{def}</span>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg text-xs text-blue-300">
        <BookOpen className="w-3.5 h-3.5 mt-0.5 shrink-0" />
        <span>
          Referência rápida sobre discagem — pra tirar dúvida rápido sem
          precisar perguntar. Isso vai crescer com o tempo.
        </span>
      </div>

      <Secao id="funil" icon={Target} titulo="O funil de discagem">
        <p className="text-xs text-muted-foreground mb-2">
          Toda ligação passa por essas etapas, em ordem — cada uma é subconjunto
          da anterior:
        </p>
        <div className="space-y-2">
          <Termo
            nome="Discagem"
            def="Toda tentativa de ligação feita pelo discador. É a base — 100% do volume."
          />
          <Termo
            nome="Atendida"
            def='Alguém (ou algo, tipo secretária eletrônica) atendeu — não conta "não atende", caixa postal, etc.'
          />
          <Termo
            nome="CPC"
            def="Contato com a Pessoa Certa — quem atendeu foi o próprio cliente, não um terceiro."
          />
          <Termo
            nome="CPCA"
            def="Houve negociação de fato, mesmo sem sucesso (ex: cliente disse que não vai pagar). Subconjunto de CPC."
          />
          <Termo
            nome="Promessa"
            def="A negociação virou compromisso de pagamento. Subconjunto de CPCA."
          />
        </div>
      </Secao>

      <Secao
        id="ruido"
        icon={ShieldAlert}
        titulo='"CPCA sem Conversão" — o que é'
      >
        <p className="text-xs text-muted-foreground mb-2">
          É quando teve CPCA (negociou de verdade) mas não virou promessa.
          Motivos mais comuns:
        </p>
        <ul className="text-xs text-muted-foreground space-y-1 list-disc pl-4">
          <li>Não Pagará — Discorda da Fatura / dos Valores</li>
          <li>Não Pagará — Problema Financeiro</li>
          <li>Não Pagará — Solicitou Cancelamento</li>
          <li>Sem Previsão para Pagamento</li>
          <li>Negociação — Fora do Prazo</li>
        </ul>
        <p className="text-xs text-muted-foreground mt-2">
          Ver a lista completa e o % de representatividade de cada motivo: aba
          "Todas as Campanhas", clique na seta ao lado de qualquer campanha.
        </p>
      </Secao>

      <Secao id="qualidade" icon={Phone} titulo="Ruído técnico (rota ruim)">
        <p className="text-xs text-muted-foreground">
          Caixa Postal, Caiu/Desligou e Mudo/Muda não são culpa do agente nem do
          cliente — é a ligação não chegando direito por causa da
          rota/operadora. Se uma rota tem <b>% Ruído acima de ~20%</b>, isso já
          é forte indício de problema técnico que vale investigar ou trocar de
          operadora — não adianta cobrar mais produtividade do agente nesse
          caso.
        </p>
        <p className="text-xs text-muted-foreground mt-2">
          Ver o detalhamento: aba "Qualidade Técnica" (compara por dia e por
          rota).
        </p>
      </Secao>

      <Secao id="spin" icon={Lightbulb} titulo="SPIN e Mailing">
        <Termo
          nome="Mailing"
          def="Quantidade de CPFs/contatos carregados no discador pra aquela campanha naquele dia. Hoje é digitado manualmente na aba 'Todas as Campanhas' (o dump não traz esse número)."
        />
        <Termo
          nome="SPIN"
          def="Discagens ÷ Mailing — quantas vezes, em média, cada contato foi discado no dia. SPIN muito alto pode indicar mailing pequeno sendo martelado demais."
        />
      </Secao>

      <Secao id="dicas" icon={GraduationCap} titulo="Dicas rápidas">
        <ul className="text-xs text-muted-foreground space-y-2 list-disc pl-4">
          <li>
            Campanha com <b>%Atendidas baixo mas %CPC alto</b>: poucas ligações
            completam, mas quando completam são o cliente certo — geralmente é
            problema de volume/mailing, não de qualidade.
          </li>
          <li>
            Campanha com <b>%CPC alto mas %CPCA baixo</b>: fala com o cliente
            certo mas não consegue avançar a negociação — vale olhar
            script/treinamento do agente.
          </li>
          <li>
            <b>Way_Ura / Way_Receptivo</b> não seguem esse funil — são campanhas
            de robô/fila automática, sem negociação humana. Métrica ainda a
            definir (ver aba Qualidade Técnica no meio tempo).
          </li>
          <li>
            Uma organização (ex: ANIMA) agrupa todas as campanhas com esse nome
            — Anima_EAD, Anima_Manual, Anima_Presencial, etc. Ver aba "Por
            Organização".
          </li>
        </ul>
      </Secao>
    </div>
  );
}
