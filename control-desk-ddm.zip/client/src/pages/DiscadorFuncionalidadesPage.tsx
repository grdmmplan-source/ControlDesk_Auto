import { useState } from "react";
import {
  Radio,
  ChevronDown,
  ChevronRight,
  Gauge,
  Layers,
  ShieldCheck,
  ExternalLink,
  AlertTriangle,
} from "lucide-react";

// Referência sobre discadores (OLOS, CallFlex e conceitos gerais do
// mercado). Conteúdo compilado a partir de pesquisa pública — pensado como
// leitura de consulta pra quem trabalha com controle de discagem no dia a
// dia. Não substitui a documentação oficial de cada fornecedor.

function Secao({
  icon: Icon,
  titulo,
  defaultOpen = false,
  children,
}: {
  icon: any;
  titulo: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-xl border border-border overflow-hidden bg-card">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-2 p-4 text-left hover:bg-muted/20"
      >
        <div className="flex items-center gap-2.5">
          <Icon className="w-4 h-4 text-primary shrink-0" />
          <span className="text-sm font-semibold text-foreground">
            {titulo}
          </span>
        </div>
        {open ? (
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
        )}
      </button>
      {open && <div className="px-4 pb-4 space-y-3">{children}</div>}
    </div>
  );
}

function Item({ nome, def }: { nome: string; def: string }) {
  return (
    <div className="flex gap-2 text-xs">
      <span className="font-semibold text-foreground shrink-0 w-32">
        {nome}
      </span>
      <span className="text-muted-foreground">{def}</span>
    </div>
  );
}

export default function DiscadorFuncionalidadesPage() {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Radio className="w-5 h-5 text-orange-400" />
          Discador e suas Funcionalidades
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Leitura de referência sobre discadores automáticos, agressividade de
          discagem e as duas plataformas usadas aqui (OLOS e CallFlex).
        </p>
      </div>

      <Secao icon={Layers} titulo="Modos de discagem" defaultOpen>
        <p className="text-xs text-muted-foreground mb-2">
          Todo discador automático opera em algum desses modos — a escolha muda
          o equilíbrio entre produtividade do agente e experiência do cliente:
        </p>
        <Item
          nome="Preditivo"
          def="O discador calcula, com base no histórico (tempo médio de atendimento, taxa de conclusão), quando disparar a próxima chamada pra ela cair pronta na tela do agente assim que ele terminar a anterior. É o modo de maior produtividade, mas o que mais gera ligação sem agente disponível se mal calibrado."
        />
        <Item
          nome="Power"
          def="Disca vários números por agente disponível ao mesmo tempo e entrega ao agente só a primeira que atender. Produtivo, mas ainda depende de acertar a proporção de discagens por agente."
        />
        <Item
          nome="Preview"
          def="Mostra os dados do contato pro agente antes de discar — o agente decide quando ligar. Mais lento, mas ideal pra abordagem que exige preparo (roteiro específico, negociação de valor alto)."
        />
        <Item
          nome="Progressivo"
          def="Só disca quando já existe agente livre confirmado — sem excesso de chamadas simultâneas. Mais conservador que o preditivo."
        />
        <Item
          nome="Manual / Click-to-call"
          def="O próprio agente aciona a ligação a partir de uma agenda ou de um clique no CRM. Sem automação de volume — usado quando a operação precisa de controle total sobre quando ligar."
        />
        <Item
          nome="Agentless / URA Reversa"
          def="O discador liga sozinho e, ao detectar voz humana, toca uma URA automática — só passa pra um agente humano se a interação inicial pedir. Usado em campanhas de baixo valor por contato ou avisos em massa."
        />
      </Secao>

      <Secao icon={Gauge} titulo="Agressividade de discagem">
        <p className="text-xs text-muted-foreground">
          "Agressividade" é o quanto o discador aperta o volume de chamadas em
          relação à capacidade real de atendimento. Ajustada por 3 variáveis
          principais:
        </p>
        <Item
          nome="Tentativas"
          def="Quantas vezes o discador liga pra um mesmo número antes de desistir dele naquele ciclo/dia."
        />
        <Item
          nome="Tempo chamando"
          def="Quanto tempo o discador espera o número tocar antes de considerar 'não atendeu' e passar pro próximo."
        />
        <Item
          nome="Tempo de espera"
          def="Quanto tempo, no máximo, um cliente que atendeu fica “na fila” até um agente ficar livre — se estourar, a ligação é derrubada (isso é o que gera parte do 'Ruído Técnico' que a gente já mede na Performance por Campanha)."
        />
        <p className="text-xs text-muted-foreground mt-2">
          Dois termômetros pra saber se a agressividade está calibrada:{" "}
          <b>TME</b> (Tempo Médio de Espera do cliente na fila — se estiver
          alto, a operação está sobrecarregada) e <b>taxa de abandono</b>{" "}
          (quantos clientes desligaram esperando — se estiver alta, precisa
          reduzir a agressividade).
        </p>
      </Secao>

      <Secao icon={Radio} titulo="OLOS">
        <p className="text-xs text-muted-foreground">
          Discador brasileiro, premiado várias vezes como melhor discador
          preditivo do país (Prêmio Consumidor Moderno). Principais
          funcionalidades documentadas publicamente:
        </p>
        <ul className="text-xs text-muted-foreground space-y-1 list-disc pl-4">
          <li>
            Discagem ativa (preditiva) e receptiva (DAC) na mesma plataforma
          </li>
          <li>Discagem Preview e Power como modos alternativos ao preditivo</li>
          <li>Exportação de mailing e qualificação de chamada</li>
          <li>Registro de chamadas finalizadas e transferência de chamadas</li>
          <li>
            Streaming/gravação de ligações e avaliação de qualidade do operador
          </li>
          <li>Gestão de desempenho e recursos de otimização de staff</li>
        </ul>
      </Secao>

      <Secao icon={Radio} titulo="CallFlex">
        <p className="text-xs text-muted-foreground">
          Discador com um diferencial específico: um "robô" que filtra ligações
          ruins <b>antes</b> de entregar ao agente.
        </p>
        <ul className="text-xs text-muted-foreground space-y-1 list-disc pl-4">
          <li>
            Discador adaptativo (CallFlex Manager) — ajusta o volume de discagem
            por PA disponível de forma dinâmica, conforme a efetividade do
            mailing em tempo real
          </li>
          <li>
            Filtro automático antes do agente: descarta mensagem de operadora,
            caixa postal, fax, áudio ruim, ocupado e chamadas sem atendimento —
            só chega no agente a ligação com chance real de conversa
          </li>
          <li>
            CallFlex SoftPhone (aplicativo instalado na máquina do agente) +
            CallFlex MID (integração do softphone com outros sistemas/CRM)
          </li>
        </ul>
        <p className="text-xs text-muted-foreground mt-2">
          Esse filtro automático é exatamente a ideia por trás do nosso "Ruído
          Técnico" — só que aqui a gente está medindo o que sobrou
          <i> depois</i> do filtro do discador, pra saber se ele está filtrando
          bem.
        </p>
      </Secao>

      <Secao
        icon={ShieldCheck}
        titulo="Regulação ANATEL (limite legal de agressividade)"
      >
        <div className="flex items-start gap-2 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-300 mb-2">
          <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          <span>
            Isso não é só boa prática — é regra da ANATEL com risco real de
            bloqueio de linha.
          </span>
        </div>
        <Item
          nome="Chamada curta"
          def="Ligação de telemarketing ativo que dura até 6 segundos, encerrada na origem ou no destino — inclui as que caem direto na caixa postal."
        />
        <Item
          nome="Limite"
          def="Empresas que fazem mais de 100 mil ligações em um dia não podem ter mais de 85% dessas ligações classificadas como 'chamada curta'."
        />
        <Item
          nome="Punição"
          def="Se os dois critérios baterem no mesmo dia, a própria operadora de telefonia bloqueia as linhas da empresa por 15 dias, mais multa."
        />
        <Item
          nome="Prefixo 0303"
          def="Obrigatório em toda ligação de telemarketing ativo, pra identificar a chamada como tal."
        />
        <p className="text-xs text-muted-foreground mt-2">
          Note a semelhança com o que a gente já mede: <b>Caixa Postal</b> e{" "}
          <b>Caiu/Desligou</b> na aba Qualidade Técnica são, na prática, o mesmo
          tipo de ocorrência que a ANATEL chama de "chamada curta". Uma
          rota/campanha com % de Ruído muito alto não é só um problema de
          produtividade — pode estar empurrando a operação perto do limite
          regulatório.
        </p>
      </Secao>

      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <ExternalLink className="w-3.5 h-3.5" /> Fontes
        </h3>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>olos.com.br — site oficial OLOS</li>
          <li>integra.callflex.com.br — documentação técnica CallFlex</li>
          <li>
            clientesa.com.br — cobertura do lançamento do CallFlex Manager
          </li>
          <li>
            agenciabrasil.ebc.com.br, tecnoblog.net — regras da ANATEL sobre
            telemarketing
          </li>
          <li>
            3cplusnow.com, callix.com.br, cobmais.com.br — conceitos gerais de
            discagem e agressividade
          </li>
        </ul>
        <p className="text-[11px] text-muted-foreground/70 mt-2 italic">
          Compilado via pesquisa web em setembro/2026 — pra especificações
          exatas de configuração, sempre confirmar com o suporte OLOS/CallFlex,
          já que funcionalidades mudam com o tempo.
        </p>
      </div>
    </div>
  );
}
