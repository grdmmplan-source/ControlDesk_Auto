import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useDashboard } from "@/contexts/DashboardContext";
import SummaryCards from "@/components/SummaryCards";
import GlobalFilters from "@/components/GlobalFilters";
import AlertBell from "@/components/AlertBell";
import ExecutiveReportModal from "@/components/ExecutiveReportModal";
import UploadPage from "./UploadPage";
import AgentDayPage from "./AgentDayPage";
import ReasonAgentPage from "./ReasonAgentPage";
import CampaignAgentPage from "./CampaignAgentPage";
import DispositionAgentPage from "./DispositionAgentPage";
import DimensionamentoPage from "./DimensionamentoPage";
import CanaisRotasPage from "./CanaisRotas";
import LoginLogoutPage from "./LoginLogoutPage";
import FaltasPage from "./FaltasPage";
import DiscadorFuncionalidadesPage from "./DiscadorFuncionalidadesPage";
import BookOperacionalPage from "./BookOperacionalPage";
import SuggestionsPage from "./SuggestionsPage";
import MopOperacionalPage from "./MopOperacionalPage";
import UsersManagementPage from "./UsersManagementPage";
import {
  Upload,
  Activity,
  PauseCircle,
  BarChart3,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Trophy,
  Users,
  Network,
  LogIn,
  UserX,
  MonitorPlay,
  Radio,
  BookMarked,
  Lightbulb,
  Map,
  UserCog,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  {
    id: "upload",
    label: "Sincronização",
    icon: Upload,
    badge: null,
    color: "text-orange-400",
  },
  {
    id: "agentday",
    label: "Performance em Tempo Real",
    icon: Activity,
    badge: "AgentDay",
    color: "text-orange-400",
  },
  {
    id: "loginlogout",
    label: "Login & Logout",
    icon: LogIn,
    badge: null,
    color: "text-emerald-400",
  },
  {
    id: "faltas",
    label: "Faltas por Carteira",
    icon: UserX,
    badge: null,
    color: "text-red-400",
  },
  {
    id: "reasonagent",
    label: "TEMPOS",
    icon: PauseCircle,
    badge: "ReasonAgent",
    color: "text-blue-400",
  },
  {
    id: "campaignagent",
    label: "Performance por Campanha",
    icon: BarChart3,
    badge: "Discagem",
    color: "text-emerald-400",
  },
  {
    id: "dispositionagent",
    label: "Tabulações",
    icon: AlertTriangle,
    badge: "DispositionAgent",
    color: "text-red-400",
  },
  {
    id: "dimensionamento",
    label: "Dimensionamento",
    icon: Users,
    badge: null,
    color: "text-purple-400",
  },
  {
    id: "canaisrotas",
    label: "Canais & Rotas",
    icon: Network,
    badge: null,
    color: "text-cyan-400",
  },
  {
    id: "discador",
    label: "Discador e Funcionalidades",
    icon: Radio,
    badge: null,
    color: "text-orange-300",
  },
  {
    id: "bookoperacional",
    label: "Book Operacional",
    icon: BookMarked,
    badge: null,
    color: "text-yellow-400",
  },
  {
    id: "suggestions",
    label: "Sugestões",
    icon: Lightbulb,
    badge: null,
    color: "text-yellow-300",
  },
  {
    id: "mop",
    label: "MOP Operacional",
    icon: Map,
    badge: null,
    color: "text-cyan-300",
  },
  {
    id: "users",
    label: "Usuários",
    icon: UserCog,
    badge: null,
    color: "text-slate-400",
  },
];

// Papel "admin" (Control/Analista de Planejamento) vê tudo, sem mudança.
// Papel "user" (Supervisor/Coordenador de Operação) só vê essas telas —
// o resto (Sincronização, Dimensionamento, Canais & Rotas, Discador,
// Wallboard) fica restrito a quem mexe com a parte técnica/estratégica.
const SUPERVISOR_ALLOWED_IDS = new Set([
  "agentday",
  "loginlogout",
  "faltas",
  "reasonagent",
  "campaignagent",
  "dispositionagent",
  "bookoperacional",
  "mop",
  "suggestions",
]);

export default function Home() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const visibleNavItems = isAdmin
    ? NAV_ITEMS
    : NAV_ITEMS.filter(i => SUPERVISOR_ALLOWED_IDS.has(i.id));

  const { activeSection, setActiveSection } = useDashboard();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [executiveOpen, setExecutiveOpen] = useState(false);

  // Supervisor entrando pela primeira vez (ou com sessão antiga apontando
  // pra uma tela restrita) — manda pra primeira tela que ele pode ver.
  useEffect(() => {
    if (!isAdmin && !visibleNavItems.some(n => n.id === activeSection)) {
      setActiveSection(visibleNavItems[0]?.id ?? "agentday");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin, activeSection]);

  const currentNav =
    visibleNavItems.find(n => n.id === activeSection) || visibleNavItems[0];

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <aside
        className={cn(
          "flex flex-col border-r border-border bg-sidebar transition-all duration-300 shrink-0",
          sidebarCollapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo DDM */}
        <div
          className={cn(
            "flex items-center gap-3 px-4 py-4 border-b border-sidebar-border",
            sidebarCollapsed && "justify-center px-2"
          )}
        >
          <img
            src="/assets/logo-ddm.png"
            alt="DDM"
            className="w-9 h-9 rounded-lg object-cover shrink-0"
          />
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <p className="text-sm font-bold text-sidebar-foreground leading-tight">
                DDM Control Desk
              </p>
              <p className="text-[11px] text-muted-foreground">
                Call Center Analytics
              </p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 space-y-1 px-2 overflow-y-auto">
          {visibleNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                title={sidebarCollapsed ? item.label : undefined}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150 group",
                  isActive
                    ? "bg-primary/15 border border-primary/30 text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent/60 border border-transparent"
                )}
              >
                <Icon
                  className={cn(
                    "w-4 h-4 shrink-0 transition-colors",
                    isActive
                      ? item.color
                      : "text-muted-foreground group-hover:text-sidebar-foreground"
                  )}
                />
                {!sidebarCollapsed && (
                  <span
                    className={cn(
                      "text-sm font-medium leading-tight flex-1 min-w-0",
                      isActive ? "text-foreground" : "text-sidebar-foreground"
                    )}
                  >
                    {item.label}
                  </span>
                )}
                {!sidebarCollapsed && item.badge && (
                  <span
                    className={cn(
                      "text-[10px] px-1.5 py-0.5 rounded font-mono shrink-0",
                      isActive
                        ? "bg-primary/20 text-primary"
                        : "bg-muted text-muted-foreground"
                    )}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Botão Wallboard — abre em aba nova, pra deixar numa TV. Só admin. */}
        {isAdmin && (
          <div className={cn("px-2", sidebarCollapsed && "px-1")}>
            <button
              onClick={() => window.open("/wallboard", "_blank")}
              title={sidebarCollapsed ? "Wallboard (TV)" : undefined}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150 group",
                "text-sidebar-foreground hover:bg-sidebar-accent/60 border border-transparent",
                sidebarCollapsed && "justify-center px-0"
              )}
            >
              <MonitorPlay className="w-4 h-4 shrink-0 text-muted-foreground group-hover:text-sidebar-foreground" />
              {!sidebarCollapsed && (
                <span className="text-sm font-medium leading-tight flex-1 min-w-0 text-sidebar-foreground">
                  Wallboard (TV)
                </span>
              )}
            </button>
          </div>
        )}

        {/* Botão Relatório Executivo */}
        <div className={cn("px-2 pb-2", sidebarCollapsed && "px-1")}>
          <button
            onClick={() => setExecutiveOpen(true)}
            title={sidebarCollapsed ? "Relatório Executivo" : undefined}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150 group",
              "bg-primary/10 hover:bg-primary/20 border border-primary/25 hover:border-primary/50",
              sidebarCollapsed && "justify-center px-0"
            )}
          >
            <Trophy className="w-4 h-4 shrink-0 text-primary" />
            {!sidebarCollapsed && (
              <span className="text-sm font-semibold text-primary leading-tight">
                Relatório Executivo
              </span>
            )}
          </button>
        </div>

        {/* Collapse toggle */}
        <div className="p-2 border-t border-sidebar-border">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarCollapsed(c => !c)}
            className={cn(
              "w-full text-muted-foreground hover:text-foreground",
              sidebarCollapsed ? "px-0 justify-center" : "justify-end"
            )}
          >
            {sidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between gap-4 px-6 py-3.5 border-b border-border bg-background/80 backdrop-blur shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <currentNav.icon
              className={cn("w-5 h-5 shrink-0", currentNav.color)}
            />
            <div className="min-w-0">
              <h1 className="text-base font-bold text-foreground leading-tight truncate">
                {currentNav.label}
              </h1>
              {currentNav.badge && (
                <p className="text-xs text-muted-foreground font-mono">
                  {currentNav.badge}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <AlertBell />
            {activeSection !== "upload" && (
              <Button
                onClick={() => setExecutiveOpen(true)}
                variant="outline"
                size="sm"
                className="gap-1.5 border-primary/30 text-primary hover:bg-primary/10 hover:text-primary hover:border-primary/50 text-xs"
              >
                <Trophy className="w-3.5 h-3.5" />
                Relatório Executivo
              </Button>
            )}
            {activeSection !== "upload" && <GlobalFilters />}
          </div>
        </header>

        {/* Summary cards */}
        {activeSection !== "upload" && (
          <div className="px-6 pt-4 shrink-0">
            <SummaryCards />
          </div>
        )}

        {/* Page content */}
        <main className="flex-1 overflow-y-auto px-6 py-4">
          {activeSection === "upload" && <UploadPage />}
          {activeSection === "agentday" && <AgentDayPage />}
          {activeSection === "loginlogout" && <LoginLogoutPage />}
          {activeSection === "faltas" && <FaltasPage />}
          {activeSection === "reasonagent" && <ReasonAgentPage />}
          {activeSection === "campaignagent" && <CampaignAgentPage />}
          {activeSection === "dispositionagent" && <DispositionAgentPage />}
          {activeSection === "dimensionamento" && <DimensionamentoPage />}
          {activeSection === "canaisrotas" && <CanaisRotasPage />}
          {activeSection === "discador" && <DiscadorFuncionalidadesPage />}
          {activeSection === "bookoperacional" && <BookOperacionalPage />}
          {activeSection === "suggestions" && <SuggestionsPage />}
          {activeSection === "mop" && <MopOperacionalPage />}
          {activeSection === "users" && isAdmin && <UsersManagementPage />}
        </main>
      </div>

      {/* Modal do Relatório Executivo */}
      <ExecutiveReportModal
        open={executiveOpen}
        onClose={() => setExecutiveOpen(false)}
      />
    </div>
  );
}
