import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Map as MapIcon, Plus, Trash2, Search, Users } from "lucide-react";
import { toast } from "sonner";

// MOP Operacional — mapa de operação: supervisores/controllers
// alocam/desalocam operadores (do Dimensionamento) em campanhas.
// Um operador pode estar em mais de uma campanha ao mesmo tempo.
export default function MopOperacionalPage() {
  const utils = trpc.useUtils();
  const { data: alocacoes, isLoading } = trpc.mop.getAlocacoes.useQuery();
  const { data: operadores } = trpc.mop.getOperadoresDisponiveis.useQuery();
  const { data: campanhasCadastradas } =
    trpc.canaisRotas.getCampanhas.useQuery();

  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [operadorSelecionado, setOperadorSelecionado] = useState("");
  const [campanhaSelecionada, setCampanhaSelecionada] = useState("");

  const create = trpc.mop.create.useMutation({
    onSuccess: () => {
      utils.mop.getAlocacoes.invalidate();
      toast.success("Operador alocado.");
      setDialogOpen(false);
      setOperadorSelecionado("");
      setCampanhaSelecionada("");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const remove = trpc.mop.delete.useMutation({
    onSuccess: () => {
      utils.mop.getAlocacoes.invalidate();
      toast.success("Alocação removida.");
    },
    onError: (e: any) => toast.error(e.message),
  });

  function handleCreate() {
    if (!operadorSelecionado || !campanhaSelecionada) {
      toast.error("Escolhe o operador e a campanha.");
      return;
    }
    const op = (operadores ?? []).find(o => o.nome === operadorSelecionado);
    create.mutate({
      operadorNome: operadorSelecionado,
      operadorLogin: op?.login ?? null,
      campanha: campanhaSelecionada,
    });
  }

  type Alocacao = NonNullable<typeof alocacoes>[number];

  // Agrupa alocações por campanha
  const porCampanha = useMemo(() => {
    const map = new Map<string, Alocacao[]>();
    for (const a of alocacoes ?? []) {
      if (!map.has(a.campanha)) map.set(a.campanha, []);
      map.get(a.campanha)!.push(a);
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [alocacoes]);

  const filtradas = useMemo(() => {
    if (!search) return porCampanha;
    const q = search.toLowerCase();
    return porCampanha
      .map(([campanha, rows]): [string, Alocacao[]] => [
        campanha,
        rows.filter(
          r =>
            campanha.toLowerCase().includes(q) ||
            r.operadorNome.toLowerCase().includes(q)
        ),
      ])
      .filter(([, rows]) => rows.length > 0);
  }, [porCampanha, search]);

  const operadoresJaAlocadosNaCampanha = (campanha: string) =>
    new Set(
      (alocacoes ?? [])
        .filter(a => a.campanha === campanha)
        .map(a => a.operadorNome)
    );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
            <MapIcon className="w-5 h-5 text-cyan-400" />
            MOP Operacional
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Mapa de operação — aloca e desaloca operadores em campanhas.
            Operadores vêm do Dimensionamento (só ativos).
          </p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-2">
          <Plus className="w-4 h-4" /> Nova Alocação
        </Button>
      </div>

      <div className="relative max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar campanha ou operador..."
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground py-10 text-center">
          Carregando...
        </p>
      ) : filtradas.length === 0 ? (
        <p className="text-sm text-muted-foreground py-10 text-center">
          Nenhuma alocação ainda — clique em "Nova Alocação" pra começar.
        </p>
      ) : (
        <div className="space-y-3">
          {filtradas.map(([campanha, rows]) => (
            <div
              key={campanha}
              className="bg-card border border-border rounded-xl overflow-hidden"
            >
              <div className="flex items-center justify-between px-4 py-2.5 bg-muted/30 border-b border-border">
                <span className="text-sm font-semibold text-foreground">
                  {campanha}
                </span>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Users className="w-3 h-3" /> {rows.length} operador(es)
                </span>
              </div>
              <div className="divide-y divide-border/50">
                {rows.map(r => (
                  <div
                    key={r.id}
                    className="flex items-center justify-between px-4 py-2"
                  >
                    <div>
                      <span className="text-sm text-foreground">
                        {r.operadorNome}
                      </span>
                      {r.operadorLogin && (
                        <span className="text-xs text-muted-foreground ml-2">
                          ({r.operadorLogin})
                        </span>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-muted-foreground hover:text-red-400"
                      onClick={() => remove.mutate({ id: r.id })}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nova Alocação</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">
                Campanha
              </label>
              <Select
                value={campanhaSelecionada}
                onValueChange={setCampanhaSelecionada}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecionar campanha" />
                </SelectTrigger>
                <SelectContent>
                  {(campanhasCadastradas ?? []).map((c: any) => (
                    <SelectItem key={c.id} value={c.campanha}>
                      {c.campanha}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">
                Operador
              </label>
              <Select
                value={operadorSelecionado}
                onValueChange={setOperadorSelecionado}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecionar operador" />
                </SelectTrigger>
                <SelectContent className="max-h-64">
                  {(operadores ?? [])
                    .filter(
                      o =>
                        !campanhaSelecionada ||
                        !operadoresJaAlocadosNaCampanha(
                          campanhaSelecionada
                        ).has(o.nome)
                    )
                    .map(o => (
                      <SelectItem key={o.nome} value={o.nome || ""}>
                        {o.nome} {o.celula ? `— ${o.celula}` : ""}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreate} disabled={create.isPending}>
              Alocar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
