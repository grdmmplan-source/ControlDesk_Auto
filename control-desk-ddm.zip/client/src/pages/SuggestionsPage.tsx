import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  MessageSquarePlus,
  Lightbulb,
  Clock,
  CheckCircle2,
  Loader2,
  Bug,
} from "lucide-react";
import { toast } from "sonner";

const BUG_CATEGORIA = "🐛 Bug/Erro";

const CATEGORIAS_SUGESTAO = [
  "Geral",
  "Book Operacional",
  "Performance por Campanha",
  "TEMPOS",
  "Dimensionamento",
  "Outro",
];

const STATUS_LABEL: Record<string, { label: string; className: string }> = {
  aberta: { label: "Aberta", className: "bg-blue-500/15 text-blue-400" },
  em_analise: {
    label: "Em análise",
    className: "bg-amber-500/15 text-amber-400",
  },
  concluida: {
    label: "Concluída",
    className: "bg-emerald-500/15 text-emerald-400",
  },
};

export default function SuggestionsPage() {
  const utils = trpc.useUtils();
  const { data: lista, isLoading } = trpc.suggestions.list.useQuery();

  const sugestoes = useMemo(
    () => (lista ?? []).filter(s => s.categoria !== BUG_CATEGORIA),
    [lista]
  );
  const bugs = useMemo(
    () => (lista ?? []).filter(s => s.categoria === BUG_CATEGORIA),
    [lista]
  );

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-yellow-400" />
          Sugestões
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Ideia, crítica ou bug — deixa aqui pra todo mundo ver.
        </p>
      </div>

      <Tabs defaultValue="sugestoes">
        <TabsList className="bg-card border border-border">
          <TabsTrigger value="sugestoes" className="gap-1.5">
            <Lightbulb className="w-3.5 h-3.5" /> Sugestões
            {sugestoes.length > 0 && (
              <span className="text-[10px] bg-muted px-1.5 rounded-full">
                {sugestoes.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="bugs" className="gap-1.5">
            <Bug className="w-3.5 h-3.5" /> Bugs/Erros
            {bugs.length > 0 && (
              <span className="text-[10px] bg-red-500/20 text-red-400 px-1.5 rounded-full">
                {bugs.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sugestoes" className="mt-4">
          <SuggestionsList
            tipo="sugestao"
            items={sugestoes}
            isLoading={isLoading}
            onSubmitted={() => utils.suggestions.list.invalidate()}
          />
        </TabsContent>

        <TabsContent value="bugs" className="mt-4">
          <SuggestionsList
            tipo="bug"
            items={bugs}
            isLoading={isLoading}
            onSubmitted={() => utils.suggestions.list.invalidate()}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function SuggestionsList({
  tipo,
  items,
  isLoading,
  onSubmitted,
}: {
  tipo: "sugestao" | "bug";
  items: any[];
  isLoading: boolean;
  onSubmitted: () => void;
}) {
  const utils = trpc.useUtils();
  const [texto, setTexto] = useState("");
  const [categoria, setCategoria] = useState("Geral");

  const create = trpc.suggestions.create.useMutation({
    onSuccess: () => {
      setTexto("");
      onSubmitted();
      toast.success(
        tipo === "bug"
          ? "Bug reportado — obrigado!"
          : "Sugestão enviada — obrigado!"
      );
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const updateStatus = trpc.suggestions.updateStatus.useMutation({
    onSuccess: () => utils.suggestions.list.invalidate(),
  });

  function handleSubmit() {
    if (texto.trim().length < 3) {
      toast.error("Escreve um pouco mais, por favor.");
      return;
    }
    create.mutate({
      texto: texto.trim(),
      categoria: tipo === "bug" ? BUG_CATEGORIA : categoria,
    });
  }

  return (
    <div className="space-y-4">
      {/* Formulário */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-3">
        <Textarea
          value={texto}
          onChange={e => setTexto(e.target.value)}
          placeholder={
            tipo === "bug"
              ? "Descreve o erro: em qual tela, o que você fez, o que aconteceu..."
              : "Escreve sua sugestão..."
          }
          className="min-h-24 bg-background"
        />
        <div className="flex items-center justify-between gap-3">
          {tipo === "sugestao" ? (
            <Select value={categoria} onValueChange={setCategoria}>
              <SelectTrigger className="w-56">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIAS_SUGESTAO.map(c => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <span className="text-xs text-muted-foreground flex items-center gap-1.5">
              <Bug className="w-3.5 h-3.5" /> Será marcado como Bug/Erro
            </span>
          )}
          <Button
            onClick={handleSubmit}
            disabled={create.isPending}
            className="gap-2"
          >
            {create.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <MessageSquarePlus className="w-4 h-4" />
            )}
            Enviar
          </Button>
        </div>
      </div>

      {/* Lista */}
      <div className="space-y-3">
        {isLoading ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            Carregando...
          </p>
        ) : items.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            {tipo === "bug"
              ? "Nenhum bug reportado — bom sinal."
              : "Nenhuma sugestão ainda — seja o primeiro."}
          </p>
        ) : (
          items.map(s => {
            const st = STATUS_LABEL[s.status] || STATUS_LABEL.aberta;
            return (
              <div
                key={s.id}
                className="bg-card border border-border rounded-xl p-4"
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground">
                      {s.userName || s.userOpenId}
                    </span>
                    {tipo === "sugestao" && (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-muted text-muted-foreground">
                        {s.categoria}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-medium ${st.className}`}
                    >
                      {st.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(s.createdAt).toLocaleDateString("pt-BR")}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-foreground whitespace-pre-wrap">
                  {s.texto}
                </p>
                {s.status !== "concluida" && (
                  <div className="flex gap-2 mt-3">
                    {s.status === "aberta" && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        onClick={() =>
                          updateStatus.mutate({
                            id: s.id,
                            status: "em_analise",
                          })
                        }
                      >
                        Marcar em análise
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs gap-1"
                      onClick={() =>
                        updateStatus.mutate({ id: s.id, status: "concluida" })
                      }
                    >
                      <CheckCircle2 className="w-3 h-3" /> Marcar concluída
                    </Button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
