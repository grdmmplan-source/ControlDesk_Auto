import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  RefreshCw,
  PlugZap,
  Loader2,
  AlertCircle,
  Phone,
  Coffee,
  Users,
  ClipboardCheck,
  Mail,
  Database,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";

// Desde que a sincronização automática com o banco espelho da OLOS ficou
// pronta pras 5 automações (Discagem, Pausas, Performance em Tempo Real,
// Tabulações, Mailing), o upload manual de arquivo foi retirado — os
// dados chegam sozinhos. Essa tela virou só o painel de status/controle
// da sincronização; os botões "sincronizar agora" de cada tipo também
// aparecem direto nas telas de cada automação (Performance por Campanha,
// TEMPOS, Performance em Tempo Real, Tabulações).
export default function UploadPage() {
  return (
    <div className="space-y-8 animate-fade-in-up max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Sincronização Automática
        </h1>
        <p className="text-muted-foreground mt-1 text-sm max-w-2xl">
          Os dados chegam direto do banco espelho da OLOS — não precisa mais
          importar arquivo manualmente. Os botões de sincronizar aqui também
          aparecem direto em cada tela (Performance por Campanha, TEMPOS,
          Performance em Tempo Real, Tabulações).
        </p>
      </div>

      <OlosSyncPanel />
    </div>
  );
}

// ─── Painel de sincronização automática com o banco espelho da OLOS ────────
// Componente próprio (não IIFE dentro do pai) — hooks isolados, sem risco de
// violar as Rules of Hooks (ver histórico de bugs #310 já corrigidos).
function OlosSyncPanel() {
  const utils = trpc.useUtils();
  const { data: status, isLoading } = trpc.olosSync.getStatus.useQuery(
    undefined,
    { refetchInterval: 30000 }
  );
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  const testConnection = trpc.olosSync.testConnection.useMutation({
    onSuccess: r => setTestResult(r),
    onError: (e: any) => setTestResult({ ok: false, message: e.message }),
  });

  const syncAgora = trpc.olosSync.syncDiscagemAgora.useMutation({
    onSuccess: r => {
      utils.olosSync.getStatus.invalidate();
      if (r.success) {
        toast.success(
          `Discagem sincronizada: ${r.totalLinhas.toLocaleString("pt-BR")} linhas (${r.referenceDate})`
        );
      } else {
        toast.error(r.message || "Erro ao sincronizar.");
      }
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const syncPausas = trpc.olosSync.syncPausasAgora.useMutation({
    onSuccess: r => {
      utils.olosSync.getStatus.invalidate();
      if (r.success) {
        toast.success(
          `Pausas sincronizadas: ${r.totalAgentes.toLocaleString("pt-BR")} agentes (${r.referenceDate})`
        );
      } else {
        toast.error(r.message || "Erro ao sincronizar.");
      }
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const syncAgentDay = trpc.olosSync.syncAgentDayAgora.useMutation({
    onSuccess: r => {
      utils.olosSync.getStatus.invalidate();
      if (r.success) {
        toast.success(
          `Performance em Tempo Real sincronizada: ${r.totalAgentes.toLocaleString("pt-BR")} agentes (${r.referenceDate})`
        );
      } else {
        toast.error(r.message || "Erro ao sincronizar.");
      }
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const syncTabulacoes = trpc.olosSync.syncTabulacoesAgora.useMutation({
    onSuccess: r => {
      utils.olosSync.getStatus.invalidate();
      if (r.success) {
        toast.success(
          `Tabulações sincronizadas: ${r.totalLinhas.toLocaleString("pt-BR")} linhas (${r.referenceDate})`
        );
      } else {
        toast.error(r.message || "Erro ao sincronizar.");
      }
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const syncMailing = trpc.olosSync.syncMailingAgora.useMutation({
    onSuccess: r => {
      if (r.success) {
        toast.success(
          `Mailing sincronizado: ${r.totalCampanhas} campanha(s) atualizadas`
        );
      } else {
        toast.error(r.message || "Erro ao sincronizar.");
      }
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  if (isLoading) return null;

  const configured = !!status?.configured;
  const lastSyncOk = status?.lastSync?.success ?? null;

  const modulos = [
    {
      icon: Phone,
      nome: "Discagem",
      desc: "Performance por Campanha",
      accent: "violet",
      mutation: syncAgora,
      onClick: () => syncAgora.mutate({}),
    },
    {
      icon: Coffee,
      nome: "Pausas",
      desc: "TEMPOS",
      accent: "amber",
      mutation: syncPausas,
      onClick: () => syncPausas.mutate({}),
    },
    {
      icon: Users,
      nome: "Performance",
      desc: "Tempo Real",
      accent: "blue",
      mutation: syncAgentDay,
      onClick: () => syncAgentDay.mutate({}),
    },
    {
      icon: ClipboardCheck,
      nome: "Tabulações",
      desc: "Excedidas",
      accent: "red",
      mutation: syncTabulacoes,
      onClick: () => syncTabulacoes.mutate({}),
    },
    {
      icon: Mail,
      nome: "Mailing",
      desc: "Por campanha · mais lento",
      accent: "purple",
      mutation: syncMailing,
      onClick: () => syncMailing.mutate(),
    },
  ] as const;

  const accentClasses: Record<string, string> = {
    violet: "text-violet-400 bg-violet-500/10 border-violet-500/20",
    amber: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    blue: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    red: "text-red-400 bg-red-500/10 border-red-500/20",
    purple: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  };

  return (
    <div className="space-y-6">
      {/* ── Pipeline: OLOS -> automações -> seu sistema ── */}
      <div className="rounded-2xl border border-border bg-card p-6 overflow-hidden relative">
        <div className="flex items-center justify-between gap-6 flex-wrap">
          {/* Origem */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div
                className={`w-11 h-11 rounded-xl border flex items-center justify-center ${
                  configured
                    ? "border-emerald-500/30 bg-emerald-500/10"
                    : "border-border bg-muted/30"
                }`}
              >
                <Database
                  className={`w-5 h-5 ${configured ? "text-emerald-400" : "text-muted-foreground"}`}
                />
              </div>
              {configured && (
                <span className="absolute -top-0.5 -right-0.5 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
                </span>
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">
                Banco espelho OLOS
              </p>
              <p className="text-xs text-muted-foreground">
                {configured ? "Conectado" : "Não configurado"}
              </p>
            </div>
          </div>

          {/* Linha animada de fluxo */}
          <div className="flex-1 min-w-[60px] relative h-px hidden sm:block">
            <div className="absolute inset-0 bg-border" />
            {configured && (
              <div className="absolute inset-0 overflow-hidden">
                <div className="h-full w-8 bg-gradient-to-r from-transparent via-emerald-400 to-transparent animate-flow-right" />
              </div>
            )}
          </div>

          <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0 sm:hidden" />

          {/* Destino */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl border border-primary/30 bg-primary/10 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">
                Control Desk
              </p>
              <p className="text-xs text-muted-foreground">
                {status?.lastSync
                  ? `Última sinc.: ${new Date(status.lastSync.at).toLocaleTimeString("pt-BR")}`
                  : "Aguardando primeira sincronização"}
              </p>
            </div>
          </div>

          <Button
            size="sm"
            variant="outline"
            onClick={() => testConnection.mutate()}
            disabled={testConnection.isPending}
            className="gap-1.5 h-8 text-xs ml-auto"
          >
            {testConnection.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <PlugZap className="w-3.5 h-3.5" />
            )}
            Testar conexão
          </Button>
        </div>

        {testResult && (
          <p
            className={`text-xs mt-3 ${testResult.ok ? "text-emerald-400" : "text-red-400"}`}
          >
            {testResult.message}
          </p>
        )}

        {status?.lastSync && !lastSyncOk && (
          <div className="flex items-start gap-2 mt-3 p-2.5 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-300">
            <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
            <span>Última tentativa falhou: {status.lastSync.message}</span>
          </div>
        )}
      </div>

      {!configured ? (
        <div className="flex items-start gap-2 p-4 bg-muted/30 border border-border rounded-xl text-sm text-muted-foreground">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>
            Não configurada ainda. Pra ativar, configure
            OLOS_DB_HOST/PORT/USER/PASSWORD/NAME no .env do servidor.
          </span>
        </div>
      ) : (
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Automações
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {modulos.map(m => (
              <div
                key={m.nome}
                className="rounded-xl border border-border bg-card p-4 flex flex-col gap-3 hover:border-muted-foreground/30 transition-colors"
              >
                <div
                  className={`w-9 h-9 rounded-lg border flex items-center justify-center ${accentClasses[m.accent]}`}
                >
                  <m.icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    {m.nome}
                  </p>
                  <p className="text-xs text-muted-foreground">{m.desc}</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={m.onClick}
                  disabled={m.mutation.isPending}
                  className="gap-1.5 h-8 text-xs mt-auto"
                >
                  {m.mutation.isPending ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="w-3.5 h-3.5" />
                  )}
                  Sincronizar
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
