import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Users, Plus, Trash2, Shield, UserCog, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Gestão de usuários — só quem é admin (Control/Analista de Planejamento)
// vê essa tela. Cria contas de Supervisor/Coordenador com acesso restrito
// (ver SUPERVISOR_ALLOWED_IDS em Home.tsx) e define a carteira/campanha
// pela qual esse supervisor é responsável.
export default function UsersManagementPage() {
  const utils = trpc.useUtils();
  const { data: users, isLoading } = trpc.userManagement.list.useQuery();
  const [showForm, setShowForm] = useState(false);
  const [editingOpenId, setEditingOpenId] = useState<string | null>(null);

  const [form, setForm] = useState({
    openId: "",
    name: "",
    password: "",
    role: "user" as "user" | "admin",
    carteiraResponsavel: "",
  });

  function resetForm() {
    setForm({
      openId: "",
      name: "",
      password: "",
      role: "user",
      carteiraResponsavel: "",
    });
    setEditingOpenId(null);
    setShowForm(false);
  }

  const createMutation = trpc.userManagement.create.useMutation({
    onSuccess: () => {
      utils.userManagement.list.invalidate();
      toast.success("Usuário criado.");
      resetForm();
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const updateMutation = trpc.userManagement.update.useMutation({
    onSuccess: () => {
      utils.userManagement.list.invalidate();
      toast.success("Usuário atualizado.");
      resetForm();
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  const deleteMutation = trpc.userManagement.delete.useMutation({
    onSuccess: () => {
      utils.userManagement.list.invalidate();
      toast.success("Usuário removido.");
    },
    onError: (e: any) => toast.error("Erro: " + e.message),
  });

  function startEdit(u: any) {
    setForm({
      openId: u.openId,
      name: u.name || "",
      password: "",
      role: u.role,
      carteiraResponsavel: u.carteiraResponsavel || "",
    });
    setEditingOpenId(u.openId);
    setShowForm(true);
  }

  function handleSubmit() {
    if (editingOpenId) {
      updateMutation.mutate({
        openId: editingOpenId,
        name: form.name || undefined,
        password: form.password || undefined,
        role: form.role,
        carteiraResponsavel: form.carteiraResponsavel || null,
      });
    } else {
      if (!form.openId || !form.name || !form.password) {
        toast.error("Login, nome e senha são obrigatórios.");
        return;
      }
      createMutation.mutate({
        openId: form.openId,
        name: form.name,
        password: form.password,
        role: form.role,
        carteiraResponsavel: form.carteiraResponsavel || undefined,
      });
    }
  }

  const saving = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="space-y-6 animate-fade-in-up max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Usuários</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Control/Analista de Planejamento vê tudo. Supervisor/Coordenador vê
            só as telas operacionais do dia a dia, e pode ter uma
            célula/campanha de responsabilidade associada.
          </p>
        </div>
        {!showForm && (
          <Button onClick={() => setShowForm(true)} className="gap-2">
            <Plus className="w-4 h-4" /> Novo usuário
          </Button>
        )}
      </div>

      {showForm && (
        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground">
              {editingOpenId ? `Editar: ${editingOpenId}` : "Novo usuário"}
            </h3>
            <button
              onClick={resetForm}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">
                Login (usuário)
              </label>
              <Input
                value={form.openId}
                disabled={!!editingOpenId}
                onChange={e => setForm(f => ({ ...f, openId: e.target.value }))}
                placeholder="ex: joana.supervisora"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">
                Nome
              </label>
              <Input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Nome completo"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">
                {editingOpenId
                  ? "Nova senha (deixe em branco pra manter)"
                  : "Senha"}
              </label>
              <Input
                type="password"
                value={form.password}
                onChange={e =>
                  setForm(f => ({ ...f, password: e.target.value }))
                }
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">
                Papel
              </label>
              <select
                value={form.role}
                onChange={e =>
                  setForm(f => ({ ...f, role: e.target.value as any }))
                }
                className="w-full h-9 bg-background border border-border rounded-md px-2 text-sm text-foreground"
              >
                <option value="user">Supervisor/Coordenador</option>
                <option value="admin">Control/Analista de Planejamento</option>
              </select>
            </div>
            {form.role === "user" && (
              <div className="col-span-2">
                <label className="text-xs text-muted-foreground mb-1 block">
                  Célula/campanha responsável (opcional)
                </label>
                <Input
                  value={form.carteiraResponsavel}
                  onChange={e =>
                    setForm(f => ({
                      ...f,
                      carteiraResponsavel: e.target.value,
                    }))
                  }
                  placeholder="ex: Vero, Cruzeiro, Anima..."
                />
              </div>
            )}
          </div>

          <Button onClick={handleSubmit} disabled={saving} className="gap-2">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            {editingOpenId ? "Salvar alterações" : "Criar usuário"}
          </Button>
        </div>
      )}

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {isLoading ? (
          <p className="text-sm text-muted-foreground p-6 text-center">
            Carregando...
          </p>
        ) : (users ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground p-6 text-center">
            Nenhum usuário ainda.
          </p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                  Nome
                </th>
                <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                  Login
                </th>
                <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                  Papel
                </th>
                <th className="text-left px-4 py-2 font-medium text-muted-foreground">
                  Célula responsável
                </th>
                <th className="px-4 py-2" />
              </tr>
            </thead>
            <tbody>
              {(users ?? []).map((u: any) => (
                <tr key={u.id} className="border-t border-border/50">
                  <td className="px-4 py-2.5 font-medium text-foreground">
                    {u.name || "—"}
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground">
                    {u.openId}
                  </td>
                  <td className="px-4 py-2.5">
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs px-2 py-0.5 rounded font-medium ${
                        u.role === "admin"
                          ? "bg-primary/15 text-primary"
                          : "bg-blue-500/15 text-blue-400"
                      }`}
                    >
                      {u.role === "admin" ? (
                        <Shield className="w-3 h-3" />
                      ) : (
                        <UserCog className="w-3 h-3" />
                      )}
                      {u.role === "admin"
                        ? "Control/Planejamento"
                        : "Supervisor"}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground">
                    {u.carteiraResponsavel || "—"}
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <button
                      onClick={() => startEdit(u)}
                      className="text-xs text-primary hover:underline mr-3"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Remover o usuário ${u.openId}?`)) {
                          deleteMutation.mutate({ id: u.id });
                        }
                      }}
                      className="text-muted-foreground hover:text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
