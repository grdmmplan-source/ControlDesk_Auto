import { useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  Users,
  Phone,
  PhoneCall,
  Coffee,
  AlertTriangle,
  Target,
  Clock,
  Settings2,
  X,
  Search,
  BarChart3,
  Trophy,
} from "lucide-react";

// Wallboard — tela grande pra TV, só KPIs, sem interação no dia a dia.
// Atualiza sozinho (polling) e mostra "atualizado há Xs" pra deixar claro
// que tá vivo. Intervalo, campanhas selecionadas e aba ativa ficam salvos
// no navegador (localStorage) — sobrevive se a TV reiniciar.
const REFRESH_OPTIONS = [
  { label: "10 min", ms: 10 * 60_000 },
  { label: "15 min", ms: 15 * 60_000 },
];
const LS_REFRESH_KEY = "wallboard:refreshMs";
const LS_CAMPANHAS_KEY = "wallboard:campanhasSelecionadas";
const LS_TAB_KEY = "wallboard:tab";

function useNow() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return now;
}

function Kpi({
  icon: Icon,
  label,
  value,
  sub,
  color,
}: {
  icon: any;
  label: string;
  value: string;
  sub?: string;
  color: string;
}) {
  return (
    <div className={`rounded-2xl border p-6 flex flex-col gap-3 ${color}`}>
      <div className="flex items-center gap-2 text-sm font-medium opacity-70">
        <Icon className="w-5 h-5" />
        {label}
      </div>
      <div className="text-5xl font-bold tabular-nums">{value}</div>
      {sub && <div className="text-sm opacity-60">{sub}</div>}
    </div>
  );
}

export default function WallboardPage() {
  const now = useNow();
  const [lastFetch, setLastFetch] = useState<Date | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [buscaCampanha, setBuscaCampanha] = useState("");

  const [tab, setTab] = useState<"campanhas" | "agentes">(() => {
    const saved = localStorage.getItem(LS_TAB_KEY);
    return saved === "agentes" ? "agentes" : "campanhas";
  });
  useEffect(() => {
    localStorage.setItem(LS_TAB_KEY, tab);
  }, [tab]);

  const [refreshMs, setRefreshMs] = useState(() => {
    const saved = localStorage.getItem(LS_REFRESH_KEY);
    return saved ? Number(saved) : REFRESH_OPTIONS[0].ms;
  });
  useEffect(() => {
    localStorage.setItem(LS_REFRESH_KEY, String(refreshMs));
  }, [refreshMs]);

  const [campanhasSelecionadas, setCampanhasSelecionadas] = useState<string[]>(
    () => {
      try {
        const saved = localStorage.getItem(LS_CAMPANHAS_KEY);
        return saved ? JSON.parse(saved) : [];
      } catch {
        return [];
      }
    }
  );
  useEffect(() => {
    localStorage.setItem(
      LS_CAMPANHAS_KEY,
      JSON.stringify(campanhasSelecionadas)
    );
  }, [campanhasSelecionadas]);

  const { data: summary } = trpc.dashboard.getSummary.useQuery(
    {},
    { refetchInterval: refreshMs }
  );
  const { data: discagem } = trpc.dashboard.getDiscagemPorCampanha.useQuery(
    undefined,
    { refetchInterval: refreshMs }
  );
  const { data: agentDayData } = trpc.dashboard.getAgentDay.useQuery(
    {},
    { refetchInterval: refreshMs, enabled: tab === "agentes" }
  );

  useEffect(() => {
    setLastFetch(new Date());
  }, [summary, discagem, agentDayData]);

  const todasCampanhas = discagem?.campanhas ?? [];
  // Vazio = mostra todas (comportamento padrão, sem filtro ativo)
  const campanhas = useMemo(() => {
    if (campanhasSelecionadas.length === 0) return todasCampanhas;
    const set = new Set(campanhasSelecionadas);
    return todasCampanhas.filter(c => set.has(c.campanha));
  }, [todasCampanhas, campanhasSelecionadas]);

  const campanhasFiltradasBusca = useMemo(() => {
    if (!buscaCampanha.trim()) return todasCampanhas;
    const q = buscaCampanha.trim().toLowerCase();
    return todasCampanhas.filter(
      c =>
        c.campanha.toLowerCase().includes(q) ||
        c.organizacao.toLowerCase().includes(q)
    );
  }, [todasCampanhas, buscaCampanha]);

  const rankingAgentes = useMemo(() => {
    const rows = (agentDayData ?? []).filter(
      (r: any) => r.login && r.login.trim() !== ""
    );
    return [...rows]
      .sort(
        (a: any, b: any) =>
          (b.chamadasAtendidas ?? 0) - (a.chamadasAtendidas ?? 0)
      )
      .slice(0, 15);
  }, [agentDayData]);

  const totals = campanhas.reduce(
    (acc, c) => ({
      discagens: acc.discagens + c.discagens,
      atendidas: acc.atendidas + c.atendidas,
      cpc: acc.cpc + c.cpc,
      cpca: acc.cpca + c.cpca,
      promessa: acc.promessa + c.promessa,
    }),
    { discagens: 0, atendidas: 0, cpc: 0, cpca: 0, promessa: 0 }
  );
  const pctAtendidas =
    totals.discagens > 0 ? (totals.atendidas / totals.discagens) * 100 : 0;

  const secsAgo = lastFetch
    ? Math.max(0, Math.round((now.getTime() - lastFetch.getTime()) / 1000))
    : null;

  function toggleCampanha(nome: string) {
    setCampanhasSelecionadas(prev =>
      prev.includes(nome) ? prev.filter(c => c !== nome) : [...prev, nome]
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-10">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h1 className="text-3xl font-bold">DDM Control Desk</h1>
          <p className="text-white/50 text-sm mt-1">
            {discagem?.referenceDate
              ? `Referência: ${discagem.referenceDate}`
              : "Sem dados de discagem ainda"}
            {campanhasSelecionadas.length > 0 &&
              ` · ${campanhasSelecionadas.length} campanha(s) selecionada(s)`}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setShowSettings(true)}
            className="text-white/20 hover:text-white/50 transition-colors p-2"
            title="Configurações"
          >
            <Settings2 className="w-5 h-5" />
          </button>
          <div className="text-right">
            <div className="text-4xl font-mono tabular-nums">
              {now.toLocaleTimeString("pt-BR")}
            </div>
            <div className="text-xs text-white/40 mt-1 flex items-center gap-1.5 justify-end">
              <Clock className="w-3 h-3" />
              {secsAgo === null ? "carregando..." : `atualizado há ${secsAgo}s`}
            </div>
          </div>
        </div>
      </div>

      {showSettings && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-8">
          <div className="bg-[#111] border border-white/10 rounded-2xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">
                Configurações do Wallboard
              </h3>
              <button
                onClick={() => setShowSettings(false)}
                className="text-white/40 hover:text-white/80"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-6">
              <p className="text-sm text-white/50 mb-2">Atualizar a cada</p>
              <div className="flex gap-2">
                {REFRESH_OPTIONS.map(opt => (
                  <button
                    key={opt.ms}
                    onClick={() => setRefreshMs(opt.ms)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      refreshMs === opt.ms
                        ? "bg-primary text-primary-foreground"
                        : "bg-white/5 text-white/60 hover:bg-white/10"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-white/50">
                  Campanhas/carteiras (vazio = todas)
                </p>
                {campanhasSelecionadas.length > 0 && (
                  <button
                    onClick={() => setCampanhasSelecionadas([])}
                    className="text-xs text-primary hover:underline"
                  >
                    Limpar seleção
                  </button>
                )}
              </div>
              <div className="relative mb-2">
                <Search className="w-3.5 h-3.5 text-white/30 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  value={buscaCampanha}
                  onChange={e => setBuscaCampanha(e.target.value)}
                  placeholder="Buscar campanha ou organização..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white/80 placeholder:text-white/30 focus:outline-none focus:border-primary/50"
                />
              </div>
              <div className="space-y-1 max-h-64 overflow-y-auto">
                {campanhasFiltradasBusca.map(c => (
                  <label
                    key={c.campanha}
                    className="flex items-center gap-2 text-sm py-1 px-2 rounded hover:bg-white/5 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={campanhasSelecionadas.includes(c.campanha)}
                      onChange={() => toggleCampanha(c.campanha)}
                      className="accent-primary"
                    />
                    <span className="text-white/80">{c.campanha}</span>
                    <span className="text-white/30 text-xs ml-auto">
                      {c.organizacao}
                    </span>
                  </label>
                ))}
                {campanhasFiltradasBusca.length === 0 && (
                  <p className="text-white/30 text-xs italic">
                    {todasCampanhas.length === 0
                      ? "Nenhuma campanha disponível ainda."
                      : "Nenhuma campanha bate com a busca."}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navegação de abas */}
      <div className="flex items-center gap-2 mb-6">
        <button
          onClick={() => setTab("campanhas")}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            tab === "campanhas"
              ? "bg-white/10 text-white"
              : "text-white/40 hover:text-white/70"
          }`}
        >
          <BarChart3 className="w-4 h-4" /> Campanhas
        </button>
        <button
          onClick={() => setTab("agentes")}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            tab === "agentes"
              ? "bg-white/10 text-white"
              : "text-white/40 hover:text-white/70"
          }`}
        >
          <Trophy className="w-4 h-4" /> Ranking de Agentes
        </button>
      </div>

      {tab === "campanhas" && (
        <>
          <div className="grid grid-cols-4 gap-6 mb-6">
            <Kpi
              icon={Users}
              label="Agentes Logados"
              value={String(summary?.agentesLogados ?? "—")}
              color="bg-blue-500/10 border-blue-500/20 text-blue-300"
            />
            <Kpi
              icon={Phone}
              label="Discagens Hoje"
              value={totals.discagens.toLocaleString("pt-BR")}
              sub={`${campanhas.length} campanhas ativas`}
              color="bg-violet-500/10 border-violet-500/20 text-violet-300"
            />
            <Kpi
              icon={PhoneCall}
              label="% Atendidas"
              value={`${pctAtendidas.toFixed(1)}%`}
              sub={`${totals.atendidas.toLocaleString("pt-BR")} atendidas`}
              color="bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
            />
            <Kpi
              icon={Coffee}
              label="Pausas (total)"
              value={String(summary?.totalPausas ?? "—")}
              color="bg-amber-500/10 border-amber-500/20 text-amber-300"
            />
          </div>

          <div className="grid grid-cols-4 gap-6 mb-6">
            <Kpi
              icon={Target}
              label="CPC"
              value={totals.cpc.toLocaleString("pt-BR")}
              sub={
                totals.atendidas > 0
                  ? `${((totals.cpc / totals.atendidas) * 100).toFixed(1)}% das atendidas`
                  : undefined
              }
              color="bg-cyan-500/10 border-cyan-500/20 text-cyan-300"
            />
            <Kpi
              icon={Target}
              label="CPCA"
              value={totals.cpca.toLocaleString("pt-BR")}
              sub={
                totals.cpc > 0
                  ? `${((totals.cpca / totals.cpc) * 100).toFixed(1)}% dos CPC`
                  : undefined
              }
              color="bg-teal-500/10 border-teal-500/20 text-teal-300"
            />
            <Kpi
              icon={Target}
              label="Promessa"
              value={totals.promessa.toLocaleString("pt-BR")}
              sub={
                totals.cpca > 0
                  ? `${((totals.promessa / totals.cpca) * 100).toFixed(1)}% dos CPCA`
                  : undefined
              }
              color="bg-green-500/10 border-green-500/20 text-green-300"
            />
            <Kpi
              icon={AlertTriangle}
              label="Tabulações Excedidas"
              value={String(summary?.totalTabulacoesExcedidas ?? "—")}
              color="bg-red-500/10 border-red-500/20 text-red-300"
            />
          </div>

          {/* Top campanhas por discagem */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-6">
            <h2 className="text-sm font-semibold text-white/60 mb-4">
              Top campanhas por discagem
            </h2>
            <div className="grid grid-cols-2 gap-x-10 gap-y-2">
              {campanhas.slice(0, 10).map(c => (
                <div
                  key={c.organizacao + c.campanha}
                  className="flex items-center justify-between py-1.5 border-b border-white/5"
                >
                  <span className="text-white/80 truncate">{c.campanha}</span>
                  <span className="tabular-nums text-white/50 text-sm">
                    {c.discagens.toLocaleString("pt-BR")} ·{" "}
                    {c.pctAtendidas.toFixed(1)}% atend.
                  </span>
                </div>
              ))}
              {campanhas.length === 0 && (
                <p className="text-white/30 text-sm italic">
                  Nenhum dump de discagem importado ainda.
                </p>
              )}
            </div>
          </div>
        </>
      )}

      {tab === "agentes" && (
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-6">
          <div className="flex items-center gap-2 mb-5">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-semibold text-white">
              Ranking de Agentes — Chamadas Atendidas Hoje
            </h2>
          </div>
          {rankingAgentes.length === 0 ? (
            <p className="text-white/30 text-sm italic">
              Nenhum dado de agentes ainda hoje.
            </p>
          ) : (
            <div className="grid grid-cols-3 gap-x-8 gap-y-1">
              {rankingAgentes.map((r: any, i: number) => (
                <div
                  key={r.login || i}
                  className="flex items-center gap-3 py-2 border-b border-white/5"
                >
                  <span
                    className={`w-6 text-center font-bold tabular-nums ${
                      i === 0
                        ? "text-amber-400"
                        : i === 1
                          ? "text-white/60"
                          : i === 2
                            ? "text-orange-400/70"
                            : "text-white/30"
                    }`}
                  >
                    {i + 1}
                  </span>
                  <span className="text-white/80 truncate flex-1">
                    {r.agente}
                  </span>
                  <span className="tabular-nums font-semibold text-emerald-300">
                    {r.chamadasAtendidas ?? 0}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
