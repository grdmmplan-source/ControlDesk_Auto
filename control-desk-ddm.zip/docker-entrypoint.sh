#!/bin/sh
set -e

echo "Aguardando o banco de dados ficar disponível..."
until node -e "
const net = require('net');
const url = new URL(process.env.DATABASE_URL);
const socket = net.createConnection(Number(url.port) || 3306, url.hostname);
socket.on('connect', () => { socket.end(); process.exit(0); });
socket.on('error', () => process.exit(1));
" 2>/dev/null
do
  echo "Banco ainda não respondeu, tentando de novo em 2s..."
  sleep 2
done

echo "Banco disponível. Aplicando migrations..."
npx drizzle-kit migrate

echo "Iniciando servidor..."
exec node dist/index.js
