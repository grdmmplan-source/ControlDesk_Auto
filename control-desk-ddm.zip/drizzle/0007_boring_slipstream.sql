CREATE TABLE `campanha_mailing` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campanha` varchar(255) NOT NULL,
	`mailing` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `campanha_mailing_id` PRIMARY KEY(`id`),
	CONSTRAINT `campanha_mailing_campanha_unique` UNIQUE(`campanha`)
);
--> statement-breakpoint
CREATE TABLE `discagem_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`referenceDate` varchar(32) NOT NULL,
	`organizacao` varchar(128) NOT NULL,
	`campanha` varchar(255) NOT NULL,
	`rota` varchar(128),
	`hora` varchar(2),
	`status` varchar(255) NOT NULL,
	`quantidade` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `discagem_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `upload_sessions` MODIFY COLUMN `reportType` enum('AgentDay','ReasonAgent','CampaignAgent','DispositionAgent','Discagem') NOT NULL;