CREATE TABLE `book_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`sheetType` varchar(32) NOT NULL,
	`referenceDate` varchar(32) NOT NULL,
	`agente` varchar(255),
	`login` varchar(128),
	`campanha` varchar(255),
	`motivo` varchar(255),
	`data` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `book_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `book_upload_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sheetType` varchar(32) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`referenceDate` varchar(32),
	`totalRows` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `book_upload_sessions_id` PRIMARY KEY(`id`)
);
