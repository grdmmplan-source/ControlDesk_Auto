CREATE TABLE `suggestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`userName` varchar(255),
	`categoria` varchar(64) DEFAULT 'Geral',
	`texto` text NOT NULL,
	`status` enum('aberta','em_analise','concluida') NOT NULL DEFAULT 'aberta',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `suggestions_id` PRIMARY KEY(`id`)
);
