CREATE TABLE `mop_alocacoes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`operadorNome` varchar(255) NOT NULL,
	`operadorLogin` varchar(128),
	`campanha` varchar(255) NOT NULL,
	`alocadoPor` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mop_alocacoes_id` PRIMARY KEY(`id`)
);
