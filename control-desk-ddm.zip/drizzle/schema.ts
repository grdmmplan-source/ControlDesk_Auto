import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  float,
  bigint,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Só usado quando role="user" (supervisor/coordenador) — qual
  // célula/campanha esse supervisor é responsável, pra filtrar as telas
  // automaticamente nele. Admin/control não usa isso (vê tudo).
  carteiraResponsavel: varchar("carteiraResponsavel", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Sessões de upload — cada arquivo importado gera uma sessão
export const uploadSessions = mysqlTable("upload_sessions", {
  id: int("id").autoincrement().primaryKey(),
  reportType: mysqlEnum("reportType", [
    "AgentDay",
    "ReasonAgent",
    "CampaignAgent",
    "DispositionAgent",
    "Discagem",
  ]).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }),
  referenceDate: varchar("referenceDate", { length: 32 }), // data de referência extraída do arquivo
  totalRows: int("totalRows").default(0),
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UploadSession = typeof uploadSessions.$inferSelect;

// Faixa 1 — Performance em Tempo Real (AgentDay)
export const agentDayRecords = mysqlTable("agent_day_records", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  referenceDate: varchar("referenceDate", { length: 32 }),
  agente: varchar("agente", { length: 255 }),
  login: varchar("login", { length: 128 }),
  agentesLogados: int("agentesLogados").default(0),
  chamadasAtendidas: int("chamadasAtendidas").default(0),
  chamadasManuais: int("chamadasManuais").default(0),
  contatoEfetivo: int("contatoEfetivo").default(0),
  logins: int("logins").default(0),
  idAgente: varchar("idAgente", { length: 64 }),
  tabulacoesTotal: int("tabulacoesTotal").default(0),
  totalChamadas: int("totalChamadas").default(0),
  totalContatos: int("totalContatos").default(0),
  primeiroLogin: varchar("primeiroLogin", { length: 32 }),
  tempoOcioso: varchar("tempoOcioso", { length: 32 }),
  tempoPausa: varchar("tempoPausa", { length: 32 }),
  ultimoLogout: varchar("ultimoLogout", { length: 32 }),
  pausas: int("pausas").default(0),
  tabulacoesSucesso: int("tabulacoesSucesso").default(0),
  tabulacoesSucessoNegocio: int("tabulacoesSucessoNegocio").default(0),
  tempoTabulacao: varchar("tempoTabulacao", { length: 32 }),
  tempoLogado: varchar("tempoLogado", { length: 32 }),
  pausasImprodutivas: varchar("pausasImprodutivas", { length: 32 }),
  uf: varchar("uf", { length: 8 }),
  produto: varchar("produto", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AgentDayRecord = typeof agentDayRecords.$inferSelect;

// Faixa 2 — Controle de Pausas (ReasonAgent)
export const reasonAgentRecords = mysqlTable("reason_agent_records", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  agente: varchar("agente", { length: 255 }),
  login: varchar("login", { length: 128 }),
  motivoDePausa: varchar("motivoDePausa", { length: 255 }),
  tempoTotalDePausa: varchar("tempoTotalDePausa", { length: 32 }),
  idAgente: varchar("idAgente", { length: 64 }),
  pausasTotalizadoPorCampanha: int("pausasTotalizadoPorCampanha").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReasonAgentRecord = typeof reasonAgentRecords.$inferSelect;

// Faixa 3 — Performance por Célula/Campanha (CampaignAgent)
export const campaignAgentRecords = mysqlTable("campaign_agent_records", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  agente: varchar("agente", { length: 255 }),
  login: varchar("login", { length: 128 }),
  campanha: varchar("campanha", { length: 255 }),
  logins: int("logins").default(0),
  nomeSupervisor: varchar("nomeSupervisor", { length: 255 }),
  totalChamadas: int("totalChamadas").default(0),
  totalContatos: int("totalContatos").default(0),
  tabulacoesSucessoNegocio: int("tabulacoesSucessoNegocio").default(0),
  tabulacoesSucesso: int("tabulacoesSucesso").default(0),
  uf: varchar("uf", { length: 8 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CampaignAgentRecord = typeof campaignAgentRecords.$inferSelect;

// Faixa 4 — Tabulações Excedidas (DispositionAgent)
export const dispositionAgentRecords = mysqlTable("disposition_agent_records", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  agente: varchar("agente", { length: 255 }),
  login: varchar("login", { length: 128 }),
  tabulacao: varchar("tabulacao", { length: 255 }),
  nomeSupervisor: varchar("nomeSupervisor", { length: 255 }),
  tempoTabulacao: varchar("tempoTabulacao", { length: 32 }),
  totalChamadas: int("totalChamadas").default(0),
  uf: varchar("uf", { length: 8 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DispositionAgentRecord =
  typeof dispositionAgentRecords.$inferSelect;

// Limites de pausa configuráveis (substitui valores hardcoded no código).
// Uma linha por motivo com override do limite padrão (em segundos).
// Motivos sem linha aqui usam o valor padrão definido em server/routers.ts.
export const pauseLimits = mysqlTable("pause_limits", {
  id: int("id").autoincrement().primaryKey(),
  motivo: varchar("motivo", { length: 255 }).notNull().unique(),
  limiteSegundos: int("limiteSegundos").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PauseLimit = typeof pauseLimits.$inferSelect;
export type InsertPauseLimit = typeof pauseLimits.$inferInsert;

// Quadro de Dimensionamento — operadores cadastrados
export const dimensionamento = mysqlTable("dimensionamento", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 255 }).notNull(),
  login: varchar("login", { length: 128 }),
  loginOlos: int("loginOlos"),
  email: varchar("email", { length: 320 }),
  supervisor: varchar("supervisor", { length: 128 }),
  admissao: varchar("admissao", { length: 32 }),
  nascimento: varchar("nascimento", { length: 32 }),
  cpf: varchar("cpf", { length: 32 }),
  funcao: varchar("funcao", { length: 255 }),
  cargo: varchar("cargo", { length: 128 }),
  departamento: varchar("departamento", { length: 128 }),
  uf: varchar("uf", { length: 8 }),
  status: varchar("status", { length: 32 }).default("ATIVO"),
  discador: varchar("discador", { length: 64 }),
  celula: varchar("celula", { length: 128 }),
  skill: varchar("skill", { length: 255 }),
  turno: varchar("turno", { length: 32 }),
  escalaHora: varchar("escalaHora", { length: 16 }),
  escala: varchar("escala", { length: 32 }),
  entrada: varchar("entrada", { length: 16 }),
  saida: varchar("saida", { length: 16 }),
  entradaS: varchar("entradaS", { length: 16 }),
  saidaS: varchar("saidaS", { length: 16 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Dimensionamento = typeof dimensionamento.$inferSelect;
export type InsertDimensionamento = typeof dimensionamento.$inferInsert;

// ─── Canais & Rotas ────────────────────────────────────────────────────────────

// Campanhas com seus canais alocados e rota cadastrada
export const canaisRotasCampanhas = mysqlTable("canais_rotas_campanhas", {
  id: int("id").autoincrement().primaryKey(),
  campanha: varchar("campanha", { length: 255 }).notNull(),
  ativo: varchar("ativo", { length: 16 }).default("Sim"), // Sim / Não / -
  solicitado: int("solicitado").default(0),
  alocado: int("alocado").default(0),
  saldo: int("saldo").default(0), // solicitado - alocado
  rotaCadastrada: varchar("rotaCadastrada", { length: 128 }),
  observacao: text("observacao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CanaisRotasCampanha = typeof canaisRotasCampanhas.$inferSelect;
export type InsertCanaisRotasCampanha =
  typeof canaisRotasCampanhas.$inferInsert;

// Rotas disponíveis com qualidade, custo e quantidade de canais
export const canaisRotasRotas = mysqlTable("canais_rotas_rotas", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 128 }).notNull(),
  quantidadeCanais: int("quantidadeCanais").default(0),
  qualidade: varchar("qualidade", { length: 32 }), // ALTA / MÉDIA / BAIXA
  custo: varchar("custo", { length: 64 }), // ELEVADO / MUITO ELEVADO / BAIXO / MUITO BAIXO
  limite: varchar("limite", { length: 32 }),
  observacao: text("observacao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CanaisRotasRota = typeof canaisRotasRotas.$inferSelect;
export type InsertCanaisRotasRota = typeof canaisRotasRotas.$inferInsert;

// Diário de bordo — histórico de movimentações de rotas
export const canaisRotasDiario = mysqlTable("canais_rotas_diario", {
  id: int("id").autoincrement().primaryKey(),
  data: varchar("data", { length: 32 }), // ISO string
  rota: varchar("rota", { length: 128 }),
  movimentacao: text("movimentacao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CanaisRotasDiario = typeof canaisRotasDiario.$inferSelect;
export type InsertCanaisRotasDiario = typeof canaisRotasDiario.$inferInsert;

// Canais IA — células com canais de IA e fluxos
export const canaisRotasIA = mysqlTable("canais_rotas_ia", {
  id: int("id").autoincrement().primaryKey(),
  celula: varchar("celula", { length: 255 }).notNull(),
  qtdCanais: int("qtdCanais").default(0),
  canaisName: text("canaisName"),
  qtdFluxo: int("qtdFluxo").default(0),
  fluxosName: text("fluxosName"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CanaisRotasIA = typeof canaisRotasIA.$inferSelect;
export type InsertCanaisRotasIA = typeof canaisRotasIA.$inferInsert;

// ─── Discagem (dump TabAuto) ────────────────────────────────────────────────
// Cada linha é uma combinação agregada (organizacao+campanha+rota+hora+status)
// com a contagem de ocorrências naquele dia — não guardamos o dump bruto
// linha a linha (376 mil linhas/dia), só o agregado (~1.200 linhas/dia).
export const discagemRecords = mysqlTable("discagem_records", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  referenceDate: varchar("referenceDate", { length: 32 }).notNull(),
  organizacao: varchar("organizacao", { length: 128 }).notNull(),
  campanha: varchar("campanha", { length: 255 }).notNull(),
  rota: varchar("rota", { length: 128 }),
  hora: varchar("hora", { length: 2 }), // "00".."23"
  status: varchar("status", { length: 255 }).notNull(),
  quantidade: int("quantidade").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DiscagemRecord = typeof discagemRecords.$inferSelect;
export type InsertDiscagemRecord = typeof discagemRecords.$inferInsert;

// Mailing manual por campanha — o dump não traz o total de mailing carregado
// no discador, só as discagens de fato. Input manual, usado pra calcular SPIN.
export const campanhaMailing = mysqlTable("campanha_mailing", {
  id: int("id").autoincrement().primaryKey(),
  campanha: varchar("campanha", { length: 255 }).notNull().unique(),
  mailing: int("mailing").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CampanhaMailing = typeof campanhaMailing.$inferSelect;
export type InsertCampanhaMailing = typeof campanhaMailing.$inferInsert;

// ─── Book Operacional ───────────────────────────────────────────────────────
// Deliberadamente ISOLADO de agent_day_records/reason_agent_records/etc.
// Mesmo quando o relatório colado é do mesmo formato OLOS (ex: B4 = Pausas,
// igual ao que já usamos em TEMPOS), o usuário pediu explicitamente pra não
// ter nenhuma relação entre "Book" e "TEMPOS" — tabelas e sessões próprias.
export const bookUploadSessions = mysqlTable("book_upload_sessions", {
  id: int("id").autoincrement().primaryKey(),
  sheetType: varchar("sheetType", { length: 32 }).notNull(), // B1,B2,B3,B4,BCampHC,BCamp,B-abs,Outro
  fileName: varchar("fileName", { length: 255 }).notNull(),
  referenceDate: varchar("referenceDate", { length: 32 }),
  totalRows: int("totalRows").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BookUploadSession = typeof bookUploadSessions.$inferSelect;

// Genérico de propósito: guarda a linha inteira como veio do relatório (todas
// as colunas, sem perder nada), mais alguns campos extraídos pra filtro/busca.
export const bookRecords = mysqlTable("book_records", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  sheetType: varchar("sheetType", { length: 32 }).notNull(),
  referenceDate: varchar("referenceDate", { length: 32 }).notNull(),
  agente: varchar("agente", { length: 255 }),
  login: varchar("login", { length: 128 }),
  campanha: varchar("campanha", { length: 255 }),
  motivo: varchar("motivo", { length: 255 }),
  data: json("data").notNull(), // { "COLUNA ORIGINAL": valor, ... } — tudo que veio no relatório
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BookRecord = typeof bookRecords.$inferSelect;
export type InsertBookRecord = typeof bookRecords.$inferInsert;

// ─── Sugestões ───────────────────────────────────────────────────────────────
// Quadro geral de sugestões — qualquer usuário logado pode postar e ver.
// Preparado pra múltiplos logins (hoje só existe christyan, mas o campo
// userOpenId já identifica o autor quando outras contas forem criadas).
export const suggestions = mysqlTable("suggestions", {
  id: int("id").autoincrement().primaryKey(),
  userOpenId: varchar("userOpenId", { length: 64 }).notNull(),
  userName: varchar("userName", { length: 255 }),
  categoria: varchar("categoria", { length: 64 }).default("Geral"),
  texto: text("texto").notNull(),
  status: mysqlEnum("status", ["aberta", "em_analise", "concluida"])
    .default("aberta")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Suggestion = typeof suggestions.$inferSelect;
export type InsertSuggestion = typeof suggestions.$inferInsert;

// ─── MOP Operacional ─────────────────────────────────────────────────────────
// Mapa de Operação: supervisores/controllers alocam/desalocam operadores
// (do Dimensionamento) em campanhas. Um operador pode estar em mais de uma
// campanha ao mesmo tempo — cada linha é uma alocação independente.
export const mopAlocacoes = mysqlTable("mop_alocacoes", {
  id: int("id").autoincrement().primaryKey(),
  operadorNome: varchar("operadorNome", { length: 255 }).notNull(),
  operadorLogin: varchar("operadorLogin", { length: 128 }),
  campanha: varchar("campanha", { length: 255 }).notNull(),
  alocadoPor: varchar("alocadoPor", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MopAlocacao = typeof mopAlocacoes.$inferSelect;
export type InsertMopAlocacao = typeof mopAlocacoes.$inferInsert;

// ─── Configurações genéricas (chave/valor) ──────────────────────────────────
// Reaproveitável pra qualquer limiar/config que precise ser ajustável em
// runtime sem mexer no código (ex: limiares da Baixa Produção).
export const appSettings = mysqlTable("app_settings", {
  key: varchar("key", { length: 128 }).notNull().primaryKey(),
  value: varchar("value", { length: 255 }).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AppSetting = typeof appSettings.$inferSelect;
