import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { ForbiddenError } from "@shared/_core/errors";
import bcrypt from "bcryptjs";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { ENV } from "./env";

// ─── Autenticação local (usuário + senha) ──────────────────────────────────
// Substitui o antigo server/_core/sdk.ts, que dependia do portal OAuth do
// Manus (chamadas HTTP pra ENV.oAuthServerUrl). Aqui a sessão é só um JWT
// assinado localmente (JWT_SECRET) e o usuário/senha vive na tabela `users`
// (openId = username, passwordHash = bcrypt). Sem chamada externa nenhuma.

export type SessionPayload = { openId: string };

function getSessionSecret() {
  const secret = ENV.cookieSecret;
  if (!secret) {
    console.warn(
      "[Auth] JWT_SECRET não configurado — defina no .env antes de usar em produção."
    );
  }
  return new TextEncoder().encode(secret || "dev-insecure-secret-change-me");
}

function parseCookies(cookieHeader: string | undefined) {
  if (!cookieHeader) return new Map<string, string>();
  return new Map(Object.entries(parseCookieHeader(cookieHeader)));
}

export async function signSession(
  payload: SessionPayload,
  options: { expiresInMs?: number } = {}
): Promise<string> {
  const issuedAt = Date.now();
  const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
  const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);

  return new SignJWT({ openId: payload.openId })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(getSessionSecret());
}

export async function verifySession(
  cookieValue: string | undefined | null
): Promise<{ openId: string } | null> {
  if (!cookieValue) return null;
  try {
    const { payload } = await jwtVerify(cookieValue, getSessionSecret(), {
      algorithms: ["HS256"],
    });
    const { openId } = payload as Record<string, unknown>;
    if (typeof openId !== "string" || !openId) return null;
    return { openId };
  } catch (error) {
    console.warn("[Auth] Session verification failed", String(error));
    return null;
  }
}

/** Verifica login e senha contra a tabela users. Retorna o usuário ou null. */
export async function login(
  username: string,
  password: string
): Promise<User | null> {
  const openId = username.trim().toLowerCase();
  const user = await db.getUserByOpenId(openId);
  if (!user || !user.passwordHash) return null;
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return null;
  await db.upsertUser({ openId: user.openId, lastSignedIn: new Date() });
  return user;
}

/** Lê a sessão do cookie (ou header Authorization: Bearer) e retorna o usuário do banco. */
export async function authenticateRequest(req: Request): Promise<User> {
  const cookies = parseCookies(req.headers.cookie);
  let sessionToken = cookies.get(COOKIE_NAME);

  if (!sessionToken) {
    const authHeader = req.headers.authorization;
    if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
      sessionToken = authHeader.slice(7);
    }
  }

  const session = await verifySession(sessionToken);
  if (!session) {
    throw ForbiddenError("Invalid session cookie");
  }

  const user = await db.getUserByOpenId(session.openId);
  if (!user) {
    throw ForbiddenError("User not found");
  }

  return user;
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}
