export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  // Banco espelho da OLOS (leitura) — opcional. Sem essas variáveis, a
  // sincronização automática fica desligada e o app funciona 100% igual
  // a hoje (import manual). Nunca commitar valores aqui — só via .env.
  olosDbHost: process.env.OLOS_DB_HOST ?? "",
  olosDbPort: Number(process.env.OLOS_DB_PORT ?? "3306"),
  olosDbUser: process.env.OLOS_DB_USER ?? "",
  olosDbPassword: process.env.OLOS_DB_PASSWORD ?? "",
  olosDbName: process.env.OLOS_DB_NAME ?? "",
  // Intervalo da sincronização automática, em minutos (padrão: 10).
  olosSyncIntervalMin: Number(process.env.OLOS_SYNC_INTERVAL_MIN ?? "10"),
};

export const OLOS_SYNC_CONFIGURED = !!(
  ENV.olosDbHost &&
  ENV.olosDbUser &&
  ENV.olosDbPassword &&
  ENV.olosDbName
);
