import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerUploadDimensionamento } from "../uploadDimensionamento";
import { registerUploadDiscagem } from "../uploadDiscagem";
import { registerUploadBookXlsb } from "../uploadBookXlsb";
import { startOlosScheduler } from "../olosSync";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { ensureDefaultAdmin } from "../db";
import { hashPassword } from "./auth";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerUploadDimensionamento(app);
  registerUploadDiscagem(app);
  registerUploadBookXlsb(app);
  startOlosScheduler();
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  // Rede de segurança: qualquer erro não tratado em rotas /api/* deve
  // responder JSON, nunca a página de erro HTML padrão do Express (senão o
  // frontend quebra tentando fazer JSON.parse() de HTML).
  app.use(
    "/api",
    (
      err: any,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      console.error("[API] erro não tratado:", err);
      if (!res.headersSent) {
        res
          .status(err?.status || 500)
          .json({ error: err?.message || "Erro interno no servidor." });
      }
    }
  );

  // Cria o usuário admin padrão na primeira execução, se a tabela `users`
  // estiver vazia. Configurável via .env; padrão: christyan / ddm123.
  const defaultUsername = process.env.DEFAULT_ADMIN_USER || "christyan";
  const defaultPassword = process.env.DEFAULT_ADMIN_PASSWORD || "ddm123";
  try {
    await ensureDefaultAdmin(
      defaultUsername,
      await hashPassword(defaultPassword)
    );
  } catch (error) {
    console.error("[Seed] Falha ao criar usuário admin padrão:", error);
  }

  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
