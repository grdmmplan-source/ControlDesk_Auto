import { parse } from "node-html-parser";

// Parser do Book Operacional — deliberadamente separado de server/parsers.ts.
// Mesmo que o relatório colado seja do mesmo formato OLOS usado em outras
// telas, aqui a extração é genérica (guarda TODAS as colunas como vieram,
// sem mapear pra um schema fixo) e grava em tabelas próprias do Book.

export type BookSheetType =
  | "B1"
  | "B2"
  | "B3"
  | "B4"
  | "BCampHC"
  | "BCamp"
  | "B-abs"
  | "Outro";

export const BOOK_SHEET_LABELS: Record<BookSheetType, string> = {
  B1: "B1 — Agente x Dia (Chamadas Manuais)",
  B2: "B2 — Agente x Dia (Logins/Tempos Off)",
  B3: "B3 — Agente x Dia (Tempos: Ocioso/Falado/Logado)",
  B4: "B4 — Agente x Motivo de Pausa",
  BCampHC: "BCampHC — Agente x Campanha",
  BCamp: "BCamp — Campanha x Mailing (Período)",
  "B-abs": "B-abs — Ausências",
  Outro: "Outro (não identificado)",
};

function cleanText(v: string | null | undefined): string {
  return (v || "").trim().replace(/\s+/g, " ");
}

function isTotalRow(primeiraColuna: string): boolean {
  const t = primeiraColuna.trim();
  if (/^(TOTAL|TOTAIS|SUBTOTAL|GRAND TOTAL|TOTAL GERAL)$/i.test(t)) return true;
  if (/^\d+$/.test(t)) return true;
  return false;
}

/** Detecta qual aba do Book esse relatório representa, pelo texto dos cabeçalhos. */
export function detectBookSheetType(headers: string[]): BookSheetType {
  const h = headers.map(x => x.toUpperCase());
  const has = (s: string) => h.some(x => x.includes(s));

  if (has("MOTIVO DE PAUSA")) return "B4";
  if (has("MAILING") && has("CAMPANHA")) return "BCamp";
  if (has("CAMPANHA") && has("AGENTE")) return "BCampHC";
  if (has("CHAMADAS MANUAIS")) return "B1";
  if (has("PRIMEIRO LOGIN") || (has("LOGINS") && has("TEMPO OFFLINE")))
    return "B2";
  if (has("TEMPO OCIOSO") && has("TEMPO FALANDO")) return "B3";
  if (has("GRUPO RV")) return "B-abs";
  return "Outro";
}

function extractReferenceDateGeneric(root: ReturnType<typeof parse>): string {
  const tables = root.querySelectorAll("table");
  for (const table of tables.slice(0, 2)) {
    const rows = table.querySelectorAll("tr");
    for (const row of rows) {
      const cells = row.querySelectorAll("td");
      const texts = cells.map(c => cleanText(c.text));
      const dateIdx = texts.findIndex(
        t =>
          t.toLowerCase().includes("data inicial") || t.toLowerCase() === "data"
      );
      if (dateIdx >= 0 && texts[dateIdx + 1]) {
        const match = texts[dateIdx + 1].match(/(\d{2}\/\d{2}\/\d{4})/);
        if (match) return match[1];
      }
    }
  }
  return new Date().toLocaleDateString("pt-BR");
}

export type ParsedBookRow = {
  agente: string | null;
  login: string | null;
  campanha: string | null;
  motivo: string | null;
  data: Record<string, string>;
};

export type ParsedBookReport = {
  referenceDate: string;
  sheetType: BookSheetType;
  headers: string[];
  rows: ParsedBookRow[];
};

/**
 * Extrai genericamente a maior tabela de dados do HTML (a que tem mais
 * linhas — evita depender de um índice fixo de tabela, já que o Book pode
 * ter um número diferente de tabelas de parâmetro antes dos dados).
 */
export function parseBookReport(html: string): ParsedBookReport {
  const root = parse(html);
  const referenceDate = extractReferenceDateGeneric(root);
  const tables = root.querySelectorAll("table");

  let best: { headers: string[]; dataRows: string[][] } | null = null;
  for (const table of tables) {
    const trs = table.querySelectorAll("tr");
    if (trs.length < 2) continue;
    const headers = trs[0]
      .querySelectorAll("td,th")
      .map(c => cleanText(c.text));
    if (headers.length < 2) continue;
    const dataRows: string[][] = [];
    for (let i = 1; i < trs.length; i++) {
      const cells = trs[i]
        .querySelectorAll("td,th")
        .map(c => cleanText(c.text));
      if (cells.some(c => c)) dataRows.push(cells);
    }
    if (!best || dataRows.length > best.dataRows.length) {
      best = { headers, dataRows };
    }
  }

  if (!best) {
    return { referenceDate, sheetType: "Outro", headers: [], rows: [] };
  }

  const sheetType = detectBookSheetType(best.headers);
  const rows = rowsFromCells(best.headers, best.dataRows);

  return { referenceDate, sheetType, headers: best.headers, rows };
}

function rowsFromCells(
  headers: string[],
  dataRows: string[][],
  skipTotalRowFilter = false
): ParsedBookRow[] {
  const headersUpper = headers.map(h => h.toUpperCase());
  const idxAgente = headersUpper.findIndex(h => h === "AGENTE" || h === "NOME");
  const idxLogin = headersUpper.findIndex(
    h => h.includes("LOGIN") && !h.includes("PRIMEIRO")
  );
  const idxCampanha = headersUpper.findIndex(h => h === "CAMPANHA");
  const idxMotivo = headersUpper.findIndex(
    h => h === "MOTIVO DE PAUSA" || h === "MOTIVO"
  );

  const rows: ParsedBookRow[] = [];
  for (const cells of dataRows) {
    const primeiraColuna = cells[0] || "";
    if (!skipTotalRowFilter && isTotalRow(primeiraColuna)) continue;

    const rowData: Record<string, string> = {};
    headers.forEach((h, i) => {
      if (h) rowData[h] = cells[i] ?? "";
    });

    rows.push({
      agente: idxAgente >= 0 ? cells[idxAgente] || null : null,
      login: idxLogin >= 0 ? cells[idxLogin] || null : null,
      campanha: idxCampanha >= 0 ? cells[idxCampanha] || null : null,
      motivo: idxMotivo >= 0 ? cells[idxMotivo] || null : null,
      data: rowData,
    });
  }
  return rows;
}

// ─── Import em massa (.xlsb) — mesmo arquivo original do Book ──────────────
// Cada aba tem um número diferente de linhas de título antes do cabeçalho
// real (confirmado inspecionando o arquivo real, não é heurística):
//   B1: 2 linhas de título + cabeçalho na linha 3 (índice 2)
//   B2/B3/B4: 1 linha de título + cabeçalho na linha 2 (índice 1)
//   BCampHC/BCamp/B-abs: sem título, cabeçalho já é a linha 1 (índice 0)
export const BOOK_XLSB_SHEETS: Record<
  string,
  { headerRowIndex: number; dateCol: string }
> = {
  B1: { headerRowIndex: 2, dateCol: "DATA" },
  B2: { headerRowIndex: 1, dateCol: "DATA" },
  B3: { headerRowIndex: 1, dateCol: "DATA" },
  B4: { headerRowIndex: 1, dateCol: "DATA" },
  BCampHC: { headerRowIndex: 0, dateCol: "DATA" },
  BCamp: { headerRowIndex: 0, dateCol: "Período" },
  "B-abs": { headerRowIndex: 0, dateCol: "Período" },
};

/** Converte "7/1/26" (M/D/AA, como o Excel exporta) para "01/07/2026". */
export function normalizeUSDateToBR(raw: string): string | null {
  const m = String(raw)
    .trim()
    .match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
  if (!m) return null;
  let [, mm, dd, yy] = m;
  if (yy.length === 2) yy = "20" + yy;
  const ddNum = parseInt(dd, 10);
  const mmNum = parseInt(mm, 10);
  if (ddNum < 1 || ddNum > 31 || mmNum < 1 || mmNum > 12) return null;
  return `${dd.padStart(2, "0")}/${mm.padStart(2, "0")}/${yy}`;
}

export type BulkSheetResult = {
  sheetType: string;
  totalRows: number;
  porData: Record<string, ParsedBookRow[]>;
  semData: number;
};

/**
 * Recebe as linhas cruas (array de arrays) de UMA aba do .xlsb (via
 * XLSX.utils.sheet_to_json com header:1) e devolve as linhas agrupadas por
 * data (DD/MM/AAAA), prontas pra gravar — mesmo formato do import diário.
 */
export function parseBookXlsbSheet(
  sheetName: string,
  rawRows: any[][]
): BulkSheetResult | null {
  const config = BOOK_XLSB_SHEETS[sheetName];
  if (!config) return null;

  const headerRow = (rawRows[config.headerRowIndex] || []).map((v: any) =>
    cleanText(String(v ?? ""))
  );
  if (headerRow.length < 2) return null;

  const dataRows = rawRows.slice(config.headerRowIndex + 1);
  const headerUpper = headerRow.map(h => h.toUpperCase());
  const idxData = headerUpper.findIndex(
    h => h === config.dateCol.toUpperCase()
  );

  const stringRows: string[][] = dataRows
    .filter(
      r => r && r.some((c: any) => c !== undefined && c !== null && c !== "")
    )
    .map(r => headerRow.map((_, i) => cleanText(String(r[i] ?? ""))));

  const parsed = rowsFromCells(headerRow, stringRows, sheetName === "B-abs");

  const porData: Record<string, ParsedBookRow[]> = {};
  let semData = 0;
  // "Período" no B-abs não é uma data (é um código tipo "2602") — como não
  // dá pra saber a data real de cada linha, agrupa tudo num único "hoje" só
  // pra não perder o dado; fica visível em Dados Brutos mesmo assim.
  const bucketPadrao = new Date().toLocaleDateString("pt-BR");

  parsed.forEach((row, i) => {
    const rawDate = idxData >= 0 ? stringRows[i][idxData] : "";
    const dataBR =
      sheetName === "B-abs" ? bucketPadrao : normalizeUSDateToBR(rawDate || "");
    if (!dataBR) {
      semData++;
      return;
    }
    if (!porData[dataBR]) porData[dataBR] = [];
    porData[dataBR].push(row);
  });

  return {
    sheetType: sheetName,
    totalRows: parsed.length,
    porData,
    semData,
  };
}
