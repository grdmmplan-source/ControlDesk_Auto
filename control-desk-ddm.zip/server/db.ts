import {
  eq,
  desc,
  asc,
  and,
  or,
  like,
  inArray,
  isNotNull,
  ne,
} from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  InsertDimensionamento,
  users,
  uploadSessions,
  agentDayRecords,
  reasonAgentRecords,
  campaignAgentRecords,
  dispositionAgentRecords,
  dimensionamento,
  pauseLimits,
  discagemRecords,
  campanhaMailing,
  bookRecords,
  bookUploadSessions,
  suggestions,
  mopAlocacoes,
  appSettings,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = [
      "name",
      "email",
      "loginMethod",
      "passwordHash",
      "carteiraResponsavel",
    ] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0)
      updateSet.lastSignedIn = new Date();
    await db
      .insert(users)
      .values(values)
      .onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(users.name);
}

export async function deleteUser(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(users).where(eq(users.id, id));
}

// Cria o usuário admin padrão na primeira execução (se a tabela estiver
// vazia). Credenciais vêm do .env (DEFAULT_ADMIN_USER/DEFAULT_ADMIN_PASSWORD)
// — nunca fica hardcoded em texto puro no código, só a senha em hash no banco.
export async function ensureDefaultAdmin(
  username: string,
  passwordHash: string
) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length > 0) return;
  const openId = username.trim().toLowerCase();
  await db.insert(users).values({
    openId,
    name: username,
    passwordHash,
    role: "admin",
  });
  console.log(`[Seed] Usuário admin "${openId}" criado.`);
}

// ─── Upload Sessions ───────────────────────────────────────────────────────────

/**
 * Cria nova sessão de upload com comportamento acumulativo por data.
 * Se já existir uma sessão do mesmo tipo + mesma referenceDate, substitui apenas essa.
 * Sessões de outras datas são preservadas (histórico).
 * Retorna o ID da nova sessão.
 */
export async function createUploadSession(data: {
  reportType:
    | "AgentDay"
    | "ReasonAgent"
    | "CampaignAgent"
    | "DispositionAgent"
    | "Discagem";
  fileName: string;
  fileKey?: string;
  referenceDate?: string;
  totalRows?: number;
  uploadedBy?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Buscar sessões do mesmo tipo + mesma data de referência para substituir
  // Se não há referenceDate, substitui todas do tipo (comportamento legado)
  let oldSessions: { id: number }[] = [];
  if (data.referenceDate) {
    oldSessions = await db
      .select({ id: uploadSessions.id })
      .from(uploadSessions)
      .where(
        and(
          eq(uploadSessions.reportType, data.reportType),
          eq(uploadSessions.referenceDate, data.referenceDate)
        )
      );
  } else {
    // Sem data de referência: substitui todas do tipo (compat. legado)
    oldSessions = await db
      .select({ id: uploadSessions.id })
      .from(uploadSessions)
      .where(eq(uploadSessions.reportType, data.reportType));
  }

  if (oldSessions.length > 0) {
    const oldIds = oldSessions.map(s => s.id);
    switch (data.reportType) {
      case "AgentDay":
        await db
          .delete(agentDayRecords)
          .where(inArray(agentDayRecords.sessionId, oldIds));
        break;
      case "ReasonAgent":
        await db
          .delete(reasonAgentRecords)
          .where(inArray(reasonAgentRecords.sessionId, oldIds));
        break;
      case "CampaignAgent":
        await db
          .delete(campaignAgentRecords)
          .where(inArray(campaignAgentRecords.sessionId, oldIds));
        break;
      case "DispositionAgent":
        await db
          .delete(dispositionAgentRecords)
          .where(inArray(dispositionAgentRecords.sessionId, oldIds));
        break;
      case "Discagem":
        await db
          .delete(discagemRecords)
          .where(inArray(discagemRecords.sessionId, oldIds));
        break;
    }
    await db.delete(uploadSessions).where(inArray(uploadSessions.id, oldIds));
  }

  const [result] = await db.insert(uploadSessions).values(data).$returningId();
  return result;
}

export async function getUploadSessions(reportType?: string) {
  const db = await getDb();
  if (!db) return [];
  if (reportType) {
    return await db
      .select()
      .from(uploadSessions)
      .where(eq(uploadSessions.reportType, reportType as any))
      .orderBy(desc(uploadSessions.createdAt));
  }
  return await db
    .select()
    .from(uploadSessions)
    .orderBy(desc(uploadSessions.createdAt));
}

/**
 * Retorna o ID da sessão mais recente de um dado tipo.
 * Usado como fallback quando nenhuma sessão está selecionada.
 */
export async function getLatestSessionId(
  reportType: "AgentDay" | "ReasonAgent" | "CampaignAgent" | "DispositionAgent"
): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select({ id: uploadSessions.id })
    .from(uploadSessions)
    .where(eq(uploadSessions.reportType, reportType))
    .orderBy(desc(uploadSessions.createdAt))
    .limit(1);
  return result.length > 0 ? result[0].id : null;
}

// ─── AgentDay Records ──────────────────────────────────────────────────────────
export async function insertAgentDayRecords(sessionId: number, rows: any[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (rows.length === 0) return;
  const chunks = [];
  for (let i = 0; i < rows.length; i += 100)
    chunks.push(rows.slice(i, i + 100));
  for (const chunk of chunks) {
    await db
      .insert(agentDayRecords)
      .values(chunk.map((r: any) => ({ ...r, sessionId })));
  }
}

export async function getAgentDayRecords(filters: {
  sessionIds?: number[];
  agente?: string;
  uf?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  // Se não há sessionIds, usa a sessão mais recente do tipo AgentDay
  let sessionIds = filters.sessionIds;
  if (!sessionIds || sessionIds.length === 0) {
    const latestId = await getLatestSessionId("AgentDay");
    if (latestId) sessionIds = [latestId];
  }

  const conditions = [];
  if (sessionIds?.length)
    conditions.push(inArray(agentDayRecords.sessionId, sessionIds));
  if (filters.agente)
    conditions.push(like(agentDayRecords.agente, `%${filters.agente}%`));
  if (filters.uf) conditions.push(eq(agentDayRecords.uf, filters.uf));
  // Exclui BOTs: agentes sem login são discadores automáticos, não devem aparecer no dashboard
  conditions.push(
    and(isNotNull(agentDayRecords.login), ne(agentDayRecords.login, ""))
  );

  return await db
    .select()
    .from(agentDayRecords)
    .where(and(...conditions))
    .orderBy(desc(agentDayRecords.chamadasAtendidas));
}

// ─── ReasonAgent Records ───────────────────────────────────────────────────────
export async function insertReasonAgentRecords(sessionId: number, rows: any[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (rows.length === 0) return;
  const chunks = [];
  for (let i = 0; i < rows.length; i += 100)
    chunks.push(rows.slice(i, i + 100));
  for (const chunk of chunks) {
    await db
      .insert(reasonAgentRecords)
      .values(chunk.map((r: any) => ({ ...r, sessionId })));
  }
}

export async function getReasonAgentRecords(filters: {
  sessionIds?: number[];
  agente?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let sessionIds = filters.sessionIds;
  if (!sessionIds || sessionIds.length === 0) {
    const latestId = await getLatestSessionId("ReasonAgent");
    if (latestId) sessionIds = [latestId];
  }

  const conditions = [];
  if (sessionIds?.length)
    conditions.push(inArray(reasonAgentRecords.sessionId, sessionIds));
  if (filters.agente)
    conditions.push(like(reasonAgentRecords.agente, `%${filters.agente}%`));

  if (conditions.length > 0)
    return await db
      .select()
      .from(reasonAgentRecords)
      .where(and(...conditions));
  return await db.select().from(reasonAgentRecords);
}

// ─── CampaignAgent Records ─────────────────────────────────────────────────────
export async function insertCampaignAgentRecords(
  sessionId: number,
  rows: any[]
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (rows.length === 0) return;
  const chunks = [];
  for (let i = 0; i < rows.length; i += 100)
    chunks.push(rows.slice(i, i + 100));
  for (const chunk of chunks) {
    await db
      .insert(campaignAgentRecords)
      .values(chunk.map((r: any) => ({ ...r, sessionId })));
  }
}

export async function getCampaignAgentRecords(filters: {
  sessionIds?: number[];
  campanha?: string;
  supervisor?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let sessionIds = filters.sessionIds;
  if (!sessionIds || sessionIds.length === 0) {
    const latestId = await getLatestSessionId("CampaignAgent");
    if (latestId) sessionIds = [latestId];
  }

  const conditions = [];
  if (sessionIds?.length)
    conditions.push(inArray(campaignAgentRecords.sessionId, sessionIds));
  if (filters.campanha)
    conditions.push(
      like(campaignAgentRecords.campanha, `%${filters.campanha}%`)
    );
  if (filters.supervisor)
    conditions.push(
      like(campaignAgentRecords.nomeSupervisor, `%${filters.supervisor}%`)
    );

  if (conditions.length > 0)
    return await db
      .select()
      .from(campaignAgentRecords)
      .where(and(...conditions));
  return await db.select().from(campaignAgentRecords);
}

// ─── DispositionAgent Records ──────────────────────────────────────────────────
export async function insertDispositionAgentRecords(
  sessionId: number,
  rows: any[]
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (rows.length === 0) return;
  const chunks = [];
  for (let i = 0; i < rows.length; i += 100)
    chunks.push(rows.slice(i, i + 100));
  for (const chunk of chunks) {
    await db
      .insert(dispositionAgentRecords)
      .values(chunk.map((r: any) => ({ ...r, sessionId })));
  }
}

export async function getDispositionAgentRecords(filters: {
  sessionIds?: number[];
  supervisor?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let sessionIds = filters.sessionIds;
  if (!sessionIds || sessionIds.length === 0) {
    const latestId = await getLatestSessionId("DispositionAgent");
    if (latestId) sessionIds = [latestId];
  }

  const conditions = [];
  if (sessionIds?.length)
    conditions.push(inArray(dispositionAgentRecords.sessionId, sessionIds));
  if (filters.supervisor)
    conditions.push(
      like(dispositionAgentRecords.nomeSupervisor, `%${filters.supervisor}%`)
    );

  if (conditions.length > 0)
    return await db
      .select()
      .from(dispositionAgentRecords)
      .where(and(...conditions));
  return await db.select().from(dispositionAgentRecords);
}

// ─── Dimensionamento ──────────────────────────────────────────────────────────

export async function getDimensionamento(filters: {
  celula?: string;
  supervisor?: string;
  turno?: string;
  uf?: string;
  status?: string;
  search?: string;
}) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (filters.celula)
    conditions.push(eq(dimensionamento.celula, filters.celula));
  if (filters.supervisor)
    conditions.push(eq(dimensionamento.supervisor, filters.supervisor));
  if (filters.turno) conditions.push(eq(dimensionamento.turno, filters.turno));
  if (filters.uf) conditions.push(eq(dimensionamento.uf, filters.uf));
  if (filters.status)
    conditions.push(eq(dimensionamento.status, filters.status));
  if (filters.search) {
    conditions.push(
      or(
        like(dimensionamento.nome, `%${filters.search}%`),
        like(dimensionamento.login, `%${filters.search}%`)
      )
    );
  }
  if (conditions.length > 0) {
    return await db
      .select()
      .from(dimensionamento)
      .where(and(...conditions))
      .orderBy(asc(dimensionamento.nome));
  }
  return await db
    .select()
    .from(dimensionamento)
    .orderBy(asc(dimensionamento.nome));
}

export async function insertDimensionamento(data: InsertDimensionamento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [result] = await db.insert(dimensionamento).values(data).$returningId();
  return result;
}

/**
 * Cruza agentes do AgentDay com o Dimensionamento e cadastra
 * automaticamente quem aparece num mas não no outro (por nome ou login).
 * Reaproveitada tanto pelo botão manual (dimensionamento.syncAgentDay)
 * quanto pela sincronização automática com a OLOS (roda sozinha depois de
 * cada sync de Performance em Tempo Real).
 */
export async function syncAgentesComDimensionamento(
  sessionIds?: number[]
): Promise<{
  autoAdded: string[];
  stillMissing: {
    agente: string;
    login: string;
    campanha: string;
    uf: string;
  }[];
}> {
  const [agentRows, dimRows] = await Promise.all([
    getAgentDayRecords({ sessionIds }),
    getDimensionamento({}),
  ]);
  const dimNomes = new Map<string, number>();
  const dimLogins = new Map<string, number>();
  for (const d of dimRows) {
    if (d.nome) dimNomes.set(d.nome.trim().toUpperCase(), d.id);
    if (d.login) dimLogins.set(d.login.trim().toLowerCase(), d.id);
  }
  const agentesMap = new Map<
    string,
    { agente: string; login: string; campanha: string; uf: string }
  >();
  for (const row of agentRows as any[]) {
    const nome = (row.agente || "").trim();
    if (!nome) continue;
    if (!agentesMap.has(nome)) {
      agentesMap.set(nome, {
        agente: nome,
        login: row.login || "",
        campanha: row.produto || "",
        uf: row.uf || "",
      });
    }
  }
  const autoAdded: string[] = [];
  const stillMissing: {
    agente: string;
    login: string;
    campanha: string;
    uf: string;
  }[] = [];
  const db = await getDb();
  for (const a of Array.from(agentesMap.values())) {
    const nomeUp = a.agente.toUpperCase();
    const loginLow = a.login.toLowerCase();
    if (dimNomes.has(nomeUp)) continue;
    if (loginLow && dimLogins.has(loginLow)) continue;
    if (loginLow && db) {
      const found = await db
        .select()
        .from(dimensionamento)
        .where(eq(dimensionamento.login, a.login))
        .limit(1);
      if (found.length > 0) {
        await db
          .update(dimensionamento)
          .set({ nome: a.agente, status: "ATIVO" })
          .where(eq(dimensionamento.id, found[0].id));
        autoAdded.push(a.agente);
        continue;
      }
    }
    try {
      await insertDimensionamento({
        nome: a.agente,
        login: a.login || null,
        celula: a.campanha || null,
        uf: a.uf || null,
        status: "ATIVO",
      });
      autoAdded.push(a.agente);
    } catch {
      stillMissing.push(a);
    }
  }
  return { autoAdded, stillMissing };
}

export async function updateDimensionamento(
  id: number,
  data: Partial<InsertDimensionamento>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(dimensionamento).set(data).where(eq(dimensionamento.id, id));
}

export async function deleteDimensionamento(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(dimensionamento).where(eq(dimensionamento.id, id));
}

export async function getDimensionamentoById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(dimensionamento)
    .where(eq(dimensionamento.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getDimensionamentoStats() {
  const db = await getDb();
  if (!db)
    return {
      total: 0,
      ativos: 0,
      celulas: [],
      supervisores: [],
      turnos: [],
      ufs: [],
    };
  const all = await db.select().from(dimensionamento);
  const ativos = all.filter(r => r.status?.toUpperCase() === "ATIVO");
  const celulas = Array.from(
    new Set(all.map(r => r.celula).filter(Boolean))
  ).sort() as string[];
  const supervisores = Array.from(
    new Set(all.map(r => r.supervisor).filter(Boolean))
  ).sort() as string[];
  const turnos = Array.from(
    new Set(all.map(r => r.turno).filter(Boolean))
  ).sort() as string[];
  const ufs = Array.from(
    new Set(all.map(r => r.uf).filter(Boolean))
  ).sort() as string[];
  return {
    total: all.length,
    ativos: ativos.length,
    celulas,
    supervisores,
    turnos,
    ufs,
  };
}

// ─── Limites de Pausa (NR17 configurável) ──────────────────────────────────────
// Overrides gravados pelo usuário. Motivos sem linha aqui usam o valor
// padrão (DEFAULT_PAUSE_LIMITS em server/routers.ts) — nunca ficam sem limite.

export async function getPauseLimits(): Promise<
  { motivo: string; limiteSegundos: number }[]
> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      motivo: pauseLimits.motivo,
      limiteSegundos: pauseLimits.limiteSegundos,
    })
    .from(pauseLimits)
    .orderBy(asc(pauseLimits.motivo));
}

export async function upsertPauseLimit(motivo: string, limiteSegundos: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const key = motivo.trim().toLowerCase();
  const existing = await db
    .select({ id: pauseLimits.id })
    .from(pauseLimits)
    .where(eq(pauseLimits.motivo, key))
    .limit(1);
  if (existing.length > 0) {
    await db
      .update(pauseLimits)
      .set({ limiteSegundos })
      .where(eq(pauseLimits.id, existing[0].id));
  } else {
    await db.insert(pauseLimits).values({ motivo: key, limiteSegundos });
  }
}

export async function deletePauseLimit(motivo: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .delete(pauseLimits)
    .where(eq(pauseLimits.motivo, motivo.trim().toLowerCase()));
}

// ─── Discagem (dump TabAuto) ────────────────────────────────────────────────

export async function insertDiscagemRecords(
  rows: {
    sessionId: number;
    referenceDate: string;
    organizacao: string;
    campanha: string;
    rota: string | null;
    hora: string | null;
    status: string;
    quantidade: number;
  }[]
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const BATCH = 500;
  for (let i = 0; i < rows.length; i += BATCH) {
    await db.insert(discagemRecords).values(rows.slice(i, i + BATCH));
  }
}

export async function getDiscagemRecords(
  filter: { referenceDate?: string } = {}
) {
  const db = await getDb();
  if (!db) return [];
  if (filter.referenceDate) {
    return db
      .select()
      .from(discagemRecords)
      .where(eq(discagemRecords.referenceDate, filter.referenceDate));
  }
  return db.select().from(discagemRecords);
}

export async function getDiscagemRecordsBySessionIds(sessionIds: number[]) {
  const db = await getDb();
  if (!db || sessionIds.length === 0) return [];
  return db
    .select()
    .from(discagemRecords)
    .where(inArray(discagemRecords.sessionId, sessionIds));
}

export async function getDiscagemReferenceDates() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .selectDistinct({ referenceDate: discagemRecords.referenceDate })
    .from(discagemRecords)
    .orderBy(desc(discagemRecords.referenceDate));
  return rows.map(r => r.referenceDate);
}

export async function getCampanhaMailingMap(): Promise<Record<string, number>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db
    .select({
      campanha: campanhaMailing.campanha,
      mailing: campanhaMailing.mailing,
    })
    .from(campanhaMailing);
  const map: Record<string, number> = {};
  for (const r of rows) map[r.campanha] = r.mailing;
  return map;
}

export async function upsertCampanhaMailing(
  campanhaNome: string,
  mailing: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db
    .select({ id: campanhaMailing.id })
    .from(campanhaMailing)
    .where(eq(campanhaMailing.campanha, campanhaNome))
    .limit(1);
  if (existing.length > 0) {
    await db
      .update(campanhaMailing)
      .set({ mailing })
      .where(eq(campanhaMailing.id, existing[0].id));
  } else {
    await db
      .insert(campanhaMailing)
      .values({ campanha: campanhaNome, mailing });
  }
}

// ─── Book Operacional (isolado de tudo mais) ────────────────────────────────

export async function createBookUploadSession(data: {
  sheetType: string;
  fileName: string;
  referenceDate: string;
  totalRows: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Substitui só a mesma aba + mesma data (histórico de outras datas fica).
  const oldSessions = await db
    .select({ id: bookUploadSessions.id })
    .from(bookUploadSessions)
    .where(
      and(
        eq(bookUploadSessions.sheetType, data.sheetType),
        eq(bookUploadSessions.referenceDate, data.referenceDate)
      )
    );
  if (oldSessions.length > 0) {
    const oldIds = oldSessions.map(s => s.id);
    await db.delete(bookRecords).where(inArray(bookRecords.sessionId, oldIds));
    await db
      .delete(bookUploadSessions)
      .where(inArray(bookUploadSessions.id, oldIds));
  }

  const result = await db.insert(bookUploadSessions).values(data);
  const insertId = (result as any)[0]?.insertId ?? (result as any).insertId;
  return { id: Number(insertId), ...data };
}

export async function insertBookRecords(
  sessionId: number,
  sheetType: string,
  referenceDate: string,
  rows: {
    agente: string | null;
    login: string | null;
    campanha: string | null;
    motivo: string | null;
    data: Record<string, string>;
  }[]
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (rows.length === 0) return;
  const values = rows.map(r => ({ sessionId, sheetType, referenceDate, ...r }));
  const BATCH = 200;
  for (let i = 0; i < values.length; i += BATCH) {
    await db.insert(bookRecords).values(values.slice(i, i + BATCH));
  }
}

/**
 * Import em massa (.xlsb): substitui todas as datas do intervalo de uma vez
 * só. Cria UMA sessão por (sheetType, data) — mesma semântica de
 * "substitui só aquele dia" do import diário, só que em lote.
 */
export async function bulkReplaceBookRecords(
  sheetType: string,
  fileName: string,
  porData: Record<
    string,
    {
      agente: string | null;
      login: string | null;
      campanha: string | null;
      motivo: string | null;
      data: Record<string, string>;
    }[]
  >
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const datas = Object.keys(porData);

  // Remove sessões/linhas antigas de TODAS as datas do lote, de uma vez
  const oldSessions = await db
    .select({ id: bookUploadSessions.id })
    .from(bookUploadSessions)
    .where(
      and(
        eq(bookUploadSessions.sheetType, sheetType),
        inArray(bookUploadSessions.referenceDate, datas)
      )
    );
  if (oldSessions.length > 0) {
    const oldIds = oldSessions.map(s => s.id);
    await db.delete(bookRecords).where(inArray(bookRecords.sessionId, oldIds));
    await db
      .delete(bookUploadSessions)
      .where(inArray(bookUploadSessions.id, oldIds));
  }

  let totalInserted = 0;
  for (const referenceDate of datas) {
    const rows = porData[referenceDate];
    if (rows.length === 0) continue;
    const result = await db.insert(bookUploadSessions).values({
      sheetType,
      fileName,
      referenceDate,
      totalRows: rows.length,
    });
    const insertId = (result as any)[0]?.insertId ?? (result as any).insertId;
    await insertBookRecords(Number(insertId), sheetType, referenceDate, rows);
    totalInserted += rows.length;
  }

  return { datas: datas.length, totalInserted };
}

export async function getBookSheetTypesForDate(referenceDate: string) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .selectDistinct({ sheetType: bookRecords.sheetType })
    .from(bookRecords)
    .where(eq(bookRecords.referenceDate, referenceDate));
  return rows.map(r => r.sheetType);
}

export async function getBookReferenceDates() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .selectDistinct({ referenceDate: bookRecords.referenceDate })
    .from(bookRecords)
    .orderBy(desc(bookRecords.referenceDate));
  return rows.map(r => r.referenceDate);
}

export async function getBookRecords(filter: {
  referenceDate: string;
  sheetType: string;
}) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(bookRecords)
    .where(
      and(
        eq(bookRecords.referenceDate, filter.referenceDate),
        eq(bookRecords.sheetType, filter.sheetType)
      )
    );
}

export async function getAllBookRecordsBySheetType(sheetType: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(bookRecords)
    .where(eq(bookRecords.sheetType, sheetType));
}

// ─── Sugestões ───────────────────────────────────────────────────────────────

export async function listSuggestions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(suggestions).orderBy(desc(suggestions.createdAt));
}

export async function createSuggestion(data: {
  userOpenId: string;
  userName: string | null;
  categoria: string;
  texto: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(suggestions).values(data);
}

export async function updateSuggestionStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(suggestions)
    .set({ status: status as any })
    .where(eq(suggestions.id, id));
}

// ─── MOP Operacional ─────────────────────────────────────────────────────────

export async function listMopAlocacoes() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(mopAlocacoes)
    .orderBy(asc(mopAlocacoes.campanha), asc(mopAlocacoes.operadorNome));
}

export async function createMopAlocacao(data: {
  operadorNome: string;
  operadorLogin: string | null;
  campanha: string;
  alocadoPor: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Evita duplicar a mesma alocação (mesmo operador + mesma campanha)
  const existing = await db
    .select({ id: mopAlocacoes.id })
    .from(mopAlocacoes)
    .where(
      and(
        eq(mopAlocacoes.operadorNome, data.operadorNome),
        eq(mopAlocacoes.campanha, data.campanha)
      )
    )
    .limit(1);
  if (existing.length > 0) return { alreadyExists: true };
  await db.insert(mopAlocacoes).values(data);
  return { alreadyExists: false };
}

export async function deleteMopAlocacao(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(mopAlocacoes).where(eq(mopAlocacoes.id, id));
}

// ─── Configurações genéricas (chave/valor) ──────────────────────────────────

export async function getAppSettings(
  keys: string[]
): Promise<Record<string, string>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db
    .select()
    .from(appSettings)
    .where(inArray(appSettings.key, keys));
  const result: Record<string, string> = {};
  for (const r of rows) result[r.key] = r.value;
  return result;
}

export async function setAppSetting(key: string, value: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .insert(appSettings)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value } });
}
