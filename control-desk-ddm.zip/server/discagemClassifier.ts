// Classificação do funil de discagem: Discagem → Atendida → CPC → CPCA → Promessa
//
// A régua abaixo (dicionário KNOWN) foi extraída diretamente da aba "BASE" de
// um relatório real (Vero, agosto/2026) que já vinha com essas 5 colunas
// calculadas linha a linha. Validado contra o resumo consolidado do mesmo
// relatório: bateu exato em Discagens/CPC/CPCA/Promessa (Atendidas ficou ~2%
// acima, diferença pequena e não perseguida).
//
// Status que não aparecem no KNOWN (de outras carteiras/organizações) caem no
// fallback por padrão de texto — é uma aproximação razoável, mas não validada
// contra números reais como o restante. Ajustável aqui conforme o time revisar.

export type DiscagemFlags = {
  atendida: boolean;
  cpc: boolean;
  cpca: boolean;
  promessa: boolean;
};

export function normalizeStatus(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove acentos
    .trim()
    .toUpperCase()
    .replace(/\s+/g, " ");
}

// [atendida, cpc, cpca, promessa] — extraído da aba BASE (dado real)
const KNOWN: Record<string, [boolean, boolean, boolean, boolean]> = {
  "MENSAGEM DE OPERADORA": [false, false, false, false],
  "NAO ATENDE": [false, false, false, false],
  "NUMERO INVALIDO": [false, false, false, false],
  ANUNCIADORA: [false, false, false, false],
  "FALHA DA OPERADORA": [false, false, false, false],
  SILENCIO: [false, false, false, false],
  HANGUP: [false, false, false, false],
  OCUPADO: [false, false, false, false],
  FAX: [false, false, false, false],
  NODISPOSITION: [false, false, false, false],
  "LIGACAO DESLIGOU_SEM CPC": [true, false, false, false],
  LIGACAO_MUDA: [true, false, false, false],
  "CLIENTE DESCONHECIDO": [true, false, false, false],
  "PROMESSA BOLETO": [true, true, true, true],
  "LIGACAO DESLIGOU_CAIU COM O CLIENTE": [true, true, false, false],
  PREVENTIVO: [true, true, false, false],
  "LIGACAO DESLIGOU_CAIU COM TERCEIROS": [true, false, false, false],
  "PROMESSA PIX": [true, true, true, true],
  "RETORNO AGENDADO COM TERCEIROS": [true, false, false, false],
  "CONSTA PAGAMENTO": [true, true, false, false],
  "NAO PAGARA - DISCORDA DA FATURA": [true, true, true, false],
  "FALECIDO - FALECIDO": [true, true, false, false],
  "NAO PAGARA - DISCORDA DOS VALORES": [true, true, true, false],
  "RETORNO AGENDADO COM CLIENTE": [true, true, false, false],
  "ALEGA PAGAMENTO - COM COMPROVANTE": [true, true, false, false],
  "SEM PREVISAO PARA PAGAMENTO": [true, true, true, false],
  "NAO PAGARA - PROBLEMA FINANCEIRO": [true, true, true, false],
  "ALEGA PAGAMENTO - ATE 48H": [true, true, false, false],
  "NAO PAGARA - SOLICITOU O CANCELAMENTO": [true, true, true, false],
  "CONGESTIONAMENTO INTERNO": [false, false, false, false],
  "TEMPO DE TABULACAO EXCEDIDO": [false, false, false, false],
};

// Fallback por padrão — só usado pra status fora do KNOWN acima.
const NAO_ATENDIDA_PATTERNS = [
  "CAIXA POSTAL",
  "CAIXA_POSTAL",
  "VOICE MAIL",
  "DESCONH -",
  "QDALIG",
  "LIGACAO CAIU",
  "TRANSFERIDA A MODULO",
  "LGPD",
  "ENGANO",
  "NAO_TABULADO",
  "ERRO NO SISTEMA",
  "DISCAGEM CANCELADA",
  "SEM AGENTES",
  "SLA EXCEDIDO",
  "ABANDONO EM FILA",
];

const NAO_CPC_PATTERNS = [
  "TERCEIRO",
  "MUDO",
  "MUDA",
  "RUIM",
  "DESCONHECID",
  "CAIU_DESLIGOU",
  "SEM CPC",
  "NAO CPC",
  "COM PROBLEMA",
  "RECADO",
  "ANTES DA IDENTIFICACAO",
  "APOS ME IDENTIFICAR",
  "PASSAVA AS INFORMACOES",
];

// Status cujo nome já indica "CPCA sem conversão" (contato + negociação, sem promessa)
const CPCA_SEM_CONVERSAO_PATTERNS = [
  "NAO PAGARA",
  "SEM PREVISAO",
  "NEGOCIACAO",
  "NEGOCIARA",
];

const CPCA_PATTERNS = [
  ...CPCA_SEM_CONVERSAO_PATTERNS,
  "PROMESSA",
  "ACORDO",
  "CONSTA PAGAMENTO",
  "PREVENTIVO",
  "RETORNO AGENDADO COM CLIENTE",
  "PAGOU",
  "AFIRMA",
  "ALEGA PAGAMENTO",
  "RECUSA",
  "CONDICOES OFERTADAS",
  "PENSARA",
  "PROPOSTA",
  "SOLICITOU PRORROGACAO",
  "BOLETO REENVIADO",
  "DESCONHECE O DEBITO",
  "VAI_PAGAR",
  "PAGARA NO PORTAL",
  "SE MATRICULOU",
  "TRANCOU MATRICULA",
  "ALUNO_SOLICITA_RETORNO_COM_INTENCAO_PG",
];

export function classifyDiscagem(statusRaw: string): DiscagemFlags {
  const sn = normalizeStatus(statusRaw);

  const known = KNOWN[sn];
  if (known) {
    const [atendida, cpc, cpca, promessa] = known;
    return { atendida, cpc, cpca, promessa };
  }

  const atendida = !NAO_ATENDIDA_PATTERNS.some(p => sn.includes(p));
  const cpc = atendida && !NAO_CPC_PATTERNS.some(p => sn.includes(p));
  const cpca = cpc && CPCA_PATTERNS.some(p => sn.includes(p));
  const promessa =
    cpca &&
    (sn.includes("PROMESSA") ||
      sn.includes("ACORDO") ||
      sn.includes("VAI_PAGAR") ||
      sn.includes("PAGARA"));

  return { atendida, cpc, cpca, promessa };
}

/** true se o status representa "CPCA sem conversão" (negociou, não converteu em promessa) */
export function isCpcaSemConversao(statusRaw: string): boolean {
  const flags = classifyDiscagem(statusRaw);
  return flags.cpca && !flags.promessa;
}

// ─── Qualidade técnica da ligação ───────────────────────────────────────────
// Categorias de "ruído" que indicam problema de rota/qualidade, não simples
// não-atendimento. Usado pra comparar produção entre dias e detectar rota ruim.
export type QualidadeCategoria =
  | "caixaPostal"
  | "caiuDesligou"
  | "mudo"
  | "outroRuido"
  | null;

const CAIXA_POSTAL_PATTERNS = [
  "CAIXA POSTAL",
  "CAIXA_POSTAL",
  "VOICE MAIL",
  "RECADO CAIXA POSTAL",
];
const CAIU_DESLIGOU_PATTERNS = [
  "CAIU_DESLIGOU",
  "LIGACAO CAIU",
  "LIGACAO_CAIU",
  "QDALIG",
  "CLIENTE_CAIU_DESLIGOU",
  "DESLIGOU_CAIU",
  "CONGESTIONAMENTO",
];
const MUDO_PATTERNS = [
  "MUDO",
  "MUDA",
  "LIGMUDA",
  "LIGACAO_RUIM",
  "LIGACAO COM PROBLEMA",
  "SILENCIO",
];
const OUTRO_RUIDO_PATTERNS = [
  "FALHA DA OPERADORA",
  "ERRO NO SISTEMA",
  "NUMERO INVALIDO",
  "FAX",
  "NODISPOSITION",
];

export function classifyQualidade(statusRaw: string): QualidadeCategoria {
  const sn = normalizeStatus(statusRaw);
  if (CAIXA_POSTAL_PATTERNS.some(p => sn.includes(p))) return "caixaPostal";
  if (CAIU_DESLIGOU_PATTERNS.some(p => sn.includes(p))) return "caiuDesligou";
  if (MUDO_PATTERNS.some(p => sn.includes(p))) return "mudo";
  if (OUTRO_RUIDO_PATTERNS.some(p => sn.includes(p))) return "outroRuido";
  return null;
}
