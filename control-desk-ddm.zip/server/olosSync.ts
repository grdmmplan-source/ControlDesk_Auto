/**
 * Sincronização com o banco espelho da OLOS (réplica em tempo real).
 * Substitui o import manual do dump TabAuto por uma consulta direta —
 * mesma tabela final (discagem_records), mesmo pipeline de "substitui só
 * aquele dia" já usado no import manual. Se as variáveis de ambiente
 * OLOS_DB_* não estiverem configuradas, tudo aqui fica inerte e o app
 * funciona 100% como hoje (import manual continua disponível sempre).
 */
import mysql from "mysql2/promise";
import { ENV, OLOS_SYNC_CONFIGURED } from "./_core/env";
import { classifyDiscagem } from "./discagemClassifier";
import {
  createUploadSession,
  insertDiscagemRecords,
  insertReasonAgentRecords,
  insertAgentDayRecords,
  syncAgentesComDimensionamento,
  insertDispositionAgentRecords,
  upsertCampanhaMailing,
} from "./db";

let _olosPool: mysql.Pool | null = null;

function getOlosPool(): mysql.Pool | null {
  if (!OLOS_SYNC_CONFIGURED) return null;
  if (!_olosPool) {
    _olosPool = mysql.createPool({
      host: ENV.olosDbHost,
      port: ENV.olosDbPort,
      user: ENV.olosDbUser,
      password: ENV.olosDbPassword,
      database: ENV.olosDbName,
      waitForConnections: true,
      connectionLimit: 3,
      // Sem isso, um problema de rede (firewall, host errado, etc) trava
      // pra sempre em vez de dar erro — o botão fica girando sem nunca
      // terminar, nem com sucesso nem com erro.
      connectTimeout: 10_000,
      // É um banco de LEITURA — nenhuma query daqui faz INSERT/UPDATE/DELETE
      // nele, só SELECT. A gravação acontece sempre no nosso próprio banco.
    });
  }
  return _olosPool;
}

// Cada sincronização é uma consulta pesada (agregação/junção em cima de
// tabelas que crescem com o tempo, no banco de vocês, não no nosso). Sem
// limite, uma consulta genuinamente lenta trava o botão pra sempre — com
// isso, ela falha com erro claro depois de 2 minutos em vez de ficar
// girando silenciosamente sem nunca resolver a promise.
const OLOS_QUERY_TIMEOUT_MS = 120_000;

async function queryOlos<T = any>(
  pool: mysql.Pool,
  sql: string,
  params?: any[],
  timeoutMs: number = OLOS_QUERY_TIMEOUT_MS
): Promise<T> {
  const [rows] = await pool.query({ sql, timeout: timeoutMs }, params);
  return rows as T;
}

export async function testOlosConnection(): Promise<{
  ok: boolean;
  message: string;
}> {
  if (!OLOS_SYNC_CONFIGURED) {
    return {
      ok: false,
      message:
        "Variáveis OLOS_DB_HOST/PORT/USER/PASSWORD/NAME não configuradas no .env.",
    };
  }
  try {
    const pool = getOlosPool()!;
    const rows = await queryOlos<any[]>(pool, "SELECT VERSION() AS v");
    const version = rows?.[0]?.v || "";

    // A sincronização de Pausas/TEMPOS usa ROW_NUMBER() OVER (...), que
    // precisa de MySQL 8+ ou MariaDB 10.2+. Avisa aqui em vez de deixar
    // quebrar silenciosamente lá na hora de sincronizar.
    const isMariaDB = /mariadb/i.test(version);
    const match = version.match(/^(\d+)\.(\d+)/);
    const major = match ? parseInt(match[1], 10) : 0;
    const minor = match ? parseInt(match[2], 10) : 0;
    const supportsWindowFn = isMariaDB
      ? major > 10 || (major === 10 && minor >= 2)
      : major >= 8;

    if (!supportsWindowFn) {
      return {
        ok: true,
        message: `Conexão OK, mas atenção: versão ${version} não suporta ROW_NUMBER() — a sincronização de Discagem funciona, mas a de Pausas/TEMPOS vai falhar. Precisa de MySQL 8+ ou MariaDB 10.2+.`,
      };
    }

    return { ok: true, message: `Conexão OK (${version}).` };
  } catch (error: any) {
    return { ok: false, message: error?.message || "Erro ao conectar." };
  }
}

function todayBR(): string {
  const d = new Date();
  return d.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" });
}

function brDateToSqlDate(brDate: string): string {
  // "24/09/2026" -> "2026-09-24"
  const [dd, mm, yyyy] = brDate.split("/");
  return `${yyyy}-${mm}-${dd}`;
}

/**
 * Puxa a discagem do dia (padrão: hoje) direto da bilhetagem, já agregada
 * por organização/campanha/rota/hora/status — mesmo formato que o import
 * manual do dump TabAuto grava em discagem_records.
 */
export async function syncDiscagemFromOlos(referenceDateBR?: string): Promise<{
  success: boolean;
  referenceDate: string;
  totalLinhas: number;
  message?: string;
}> {
  const pool = getOlosPool();
  if (!pool) {
    return {
      success: false,
      referenceDate: referenceDateBR || todayBR(),
      totalLinhas: 0,
      message: "Sincronização com a OLOS não está configurada.",
    };
  }

  const referenceDate = referenceDateBR || todayBR();
  const sqlDate = brDateToSqlDate(referenceDate);

  // IMPORTANTE: nunca envolver a coluna de data em função (ex: DATE(x)) no
  // WHERE — isso impede o MySQL de usar o índice e força varredura da
  // tabela inteira. Usa intervalo [00:00, 00:00 do dia seguinte) direto.
  const rows = await queryOlos(
    pool,
    `
    SELECT
      o.nome AS organizacao,
      c.descricao AS campanha,
      r.nome AS rota,
      LPAD(HOUR(b.data_inicio), 2, '0') AS hora,
      COALESCE(
        CASE WHEN t.descricao NOT LIKE '%\\_Template' THEN t.descricao END,
        tb.descricao,
        'Sem status'
      ) AS status,
      COUNT(*) AS quantidade
    FROM bilhetagem b
    LEFT JOIN organizacoes o ON o.id = b.organizacao_id
    LEFT JOIN campanhas c ON c.id = b.campanha_id
    LEFT JOIN rotas r ON r.id = b.rota_id
    LEFT JOIN tabulacoes_bilhetagem tb ON tb.id = b.tabulacao_bilhetagem_id
    -- pega só a tentativa mais recente por chamada, pra não duplicar
    -- contagem quando existir mais de uma tentativa pro mesmo identificador.
    -- Filtrado pela MESMA janela de data — sem isso, escaneia a tabela
    -- inteira (todo o histórico) a cada sincronização.
    LEFT JOIN (
      SELECT identificador_telecom, MAX(id) AS max_id
      FROM tentativas_contato
      WHERE identificador_telecom IS NOT NULL
        AND data_inicio >= ? AND data_inicio < DATE_ADD(?, INTERVAL 1 DAY)
      GROUP BY identificador_telecom
    ) tc_latest ON tc_latest.identificador_telecom = b.identificador_telecom
    LEFT JOIN tentativas_contato tc ON tc.id = tc_latest.max_id
    LEFT JOIN tabulacoes t ON t.id = tc.tabulacao_id
    WHERE b.data_inicio >= ? AND b.data_inicio < DATE_ADD(?, INTERVAL 1 DAY)
    GROUP BY o.nome, c.descricao, r.nome, hora, status
    `,
    [sqlDate, sqlDate, sqlDate, sqlDate]
  );

  const linhas = rows as Array<{
    organizacao: string | null;
    campanha: string | null;
    rota: string | null;
    hora: string | null;
    status: string;
    quantidade: number;
  }>;

  if (linhas.length === 0) {
    return {
      success: true,
      referenceDate,
      totalLinhas: 0,
      message: "Nenhuma discagem encontrada nesse dia (ainda).",
    };
  }

  const session = await createUploadSession({
    reportType: "Discagem",
    fileName: `sync-olos-${sqlDate}`,
    referenceDate,
    totalRows: linhas.length,
  });

  await insertDiscagemRecords(
    linhas.map(l => ({
      sessionId: session.id,
      referenceDate,
      organizacao: l.organizacao || "Sem organização",
      campanha: l.campanha || "Sem campanha",
      rota: l.rota,
      hora: l.hora,
      status: l.status,
      quantidade: l.quantidade,
    }))
  );

  return { success: true, referenceDate, totalLinhas: linhas.length };
}

function secondsToHMS(s: number): string {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

/**
 * Puxa as pausas do dia direto de estados_agente, já somadas por
 * agente/motivo — mesmo formato que TEMPOS (reason_agent_records) espera.
 *
 * Cuidado importante (descoberto com dado real): quando um agente está
 * logado em mais de uma campanha ao mesmo tempo, o mesmo intervalo de
 * pausa aparece MULTIPLICADO — uma linha por campanha em que ele está
 * logado. Sem desduplicar, o tempo de pausa sai multiplicado por N. Aqui
 * cada intervalo (agente + início + fim) conta só uma vez, via
 * ROW_NUMBER() OVER (PARTITION BY agente_id, estado_iniciado_em,
 * estado_finalizado_em).
 */
export async function syncPausasFromOlos(referenceDateBR?: string): Promise<{
  success: boolean;
  referenceDate: string;
  totalAgentes: number;
  message?: string;
}> {
  const pool = getOlosPool();
  if (!pool) {
    return {
      success: false,
      referenceDate: referenceDateBR || todayBR(),
      totalAgentes: 0,
      message: "Sincronização com a OLOS não está configurada.",
    };
  }

  const referenceDate = referenceDateBR || todayBR();
  const sqlDate = brDateToSqlDate(referenceDate);

  const rows = await queryOlos(
    pool,
    `
    WITH deduped AS (
      SELECT
        ea.agente_id,
        ea.motivo_id,
        TIMESTAMPDIFF(SECOND, ea.estado_iniciado_em, ea.estado_finalizado_em) AS dur,
        ROW_NUMBER() OVER (
          PARTITION BY ea.agente_id, ea.estado_iniciado_em, ea.estado_finalizado_em
          ORDER BY ea.id
        ) AS rn
      FROM estados_agente ea
      INNER JOIN status_agentes sa ON sa.id = ea.status_agente_id
      WHERE sa.descricao = 'Pause'
        AND ea.estado_finalizado_em IS NOT NULL
        AND ea.estado_iniciado_em >= ?
        AND ea.estado_iniciado_em < DATE_ADD(?, INTERVAL 1 DAY)
    )
    SELECT
      d.agente_id,
      u.nome_usuario AS agente,
      u.login AS login,
      COALESCE(m.descricao, 'Sem motivo') AS motivo,
      SUM(d.dur) AS tempo_segundos,
      COUNT(*) AS qtd_pausas
    FROM deduped d
    LEFT JOIN motivos m ON m.id = d.motivo_id
    LEFT JOIN usuarios u ON u.agente_id = d.agente_id
    WHERE d.rn = 1
    GROUP BY d.agente_id, u.nome_usuario, u.login, motivo
    `,
    [sqlDate, sqlDate]
  );

  const linhas = rows as Array<{
    agente_id: number;
    agente: string | null;
    login: string | null;
    motivo: string;
    tempo_segundos: number;
    qtd_pausas: number;
  }>;

  if (linhas.length === 0) {
    return {
      success: true,
      referenceDate,
      totalAgentes: 0,
      message: "Nenhuma pausa encontrada nesse dia (ainda).",
    };
  }

  const session = await createUploadSession({
    reportType: "ReasonAgent",
    fileName: `sync-olos-pausas-${sqlDate}`,
    referenceDate,
    totalRows: linhas.length,
  });

  await insertReasonAgentRecords(
    session.id,
    linhas.map(l => ({
      agente: l.agente || `Agente ${l.agente_id}`,
      login: l.login,
      motivoDePausa: l.motivo,
      tempoTotalDePausa: secondsToHMS(l.tempo_segundos),
      idAgente: String(l.agente_id),
      pausasTotalizadoPorCampanha: l.qtd_pausas,
    }))
  );

  const agentesUnicos = new Set(linhas.map(l => l.agente_id)).size;
  return { success: true, referenceDate, totalAgentes: agentesUnicos };
}

function hmsFromDate(d: Date): string {
  return d.toTimeString().slice(0, 8); // "HH:MM:SS"
}

/**
 * Puxa o Performance em Tempo Real (AgentDay) do dia, combinando duas
 * fontes: estados_agente pros campos de TEMPO (logado, ocioso, pausa,
 * tabulação, primeiro login, último logout — mesma deduplicação por
 * multi-campanha do sync de Pausas) e bilhetagem+tentativas_contato pros
 * campos de CHAMADA (atendidas, contatos efetivos, sucesso de negócio —
 * mesma lógica já usada no sync de Discagem).
 *
 * Campos que a tela tem mas não dá pra derivar dessas tabelas ficam com
 * valor padrão (0 ou vazio) — não é chutado, é deixado em branco mesmo:
 * chamadasManuais, agentesLogados, pausasImprodutivas, uf, produto.
 */
export async function syncAgentDayFromOlos(referenceDateBR?: string): Promise<{
  success: boolean;
  referenceDate: string;
  totalAgentes: number;
  message?: string;
}> {
  const pool = getOlosPool();
  if (!pool) {
    return {
      success: false,
      referenceDate: referenceDateBR || todayBR(),
      totalAgentes: 0,
      message: "Sincronização com a OLOS não está configurada.",
    };
  }

  const referenceDate = referenceDateBR || todayBR();
  const sqlDate = brDateToSqlDate(referenceDate);

  // ── Fonte 1: tempos (estados_agente, deduplicado por multi-campanha) ────
  const temposRows = await queryOlos(
    pool,
    `
    WITH deduped AS (
      SELECT
        ea.agente_id,
        COALESCE(sa.descricao, 'Desconhecido') AS status,
        ea.estado_iniciado_em,
        ea.estado_finalizado_em,
        TIMESTAMPDIFF(SECOND, ea.estado_iniciado_em, ea.estado_finalizado_em) AS dur,
        ROW_NUMBER() OVER (
          PARTITION BY ea.agente_id, ea.estado_iniciado_em, ea.estado_finalizado_em
          ORDER BY (COALESCE(sa.descricao, '') LIKE '%OtherCampaign') ASC, ea.id
        ) AS rn
      FROM estados_agente ea
      LEFT JOIN status_agentes sa ON sa.id = ea.status_agente_id
      WHERE ea.estado_finalizado_em IS NOT NULL
        AND ea.estado_iniciado_em >= ?
        AND ea.estado_iniciado_em < DATE_ADD(?, INTERVAL 1 DAY)
    )
    SELECT
      d.agente_id,
      u.nome_usuario AS agente,
      u.login AS login,
      MIN(d.estado_iniciado_em) AS primeiro_login,
      MAX(d.estado_finalizado_em) AS ultimo_logout,
      SUM(d.dur) AS tempo_logado_seg,
      SUM(CASE WHEN d.status = 'Idle' THEN d.dur ELSE 0 END) AS tempo_ocioso_seg,
      SUM(CASE WHEN d.status = 'Pause' THEN d.dur ELSE 0 END) AS tempo_pausa_seg,
      SUM(CASE WHEN d.status = 'Pause' THEN 1 ELSE 0 END) AS pausas,
      SUM(CASE WHEN d.status = 'Wrap' THEN d.dur ELSE 0 END) AS tempo_tabulacao_seg
    FROM deduped d
    LEFT JOIN usuarios u ON u.agente_id = d.agente_id
    WHERE d.rn = 1
    GROUP BY d.agente_id, u.nome_usuario, u.login
    `,
    [sqlDate, sqlDate]
  );

  // ── Fonte 2: chamadas (bilhetagem + tentativas_contato) ─────────────────
  // IMPORTANTE: aqui NÃO pré-agrega em SQL com critérios soltos — isso já
  // causou um bug real (CPC > Chamadas Atendidas, matematicamente
  // impossível). Causa raiz: tabulacoes_bilhetagem usa vocabulário técnico
  // em INGLÊS (padrão telecom: "Normal received", "No answer"...), mas o
  // classifyDiscagem() foi calibrado pro vocabulário de NEGÓCIO em
  // português dos relatórios OLOS — jogado direto nos códigos técnicos em
  // inglês, ele classifica quase tudo (até "No answer"!) como atendida.
  //
  // Fix: dois sinais SEPARADOS, combinados com AND (não um substituindo o
  // outro):
  //   1) "atendida" vem de um dicionário técnico dedicado (os 28 códigos
  //      fixos que tabulacoes_bilhetagem usa — confirmados no schema real).
  //   2) CPC/CPCA/Promessa vêm do classifyDiscagem() aplicado SÓ no texto
  //      de negócio (quando existe), mas sempre exigindo atendida=true
  //      primeiro. Isso garante cpc ⊆ atendida por construção, não importa
  //      o que qualquer classificador isolado diria.
  //
  // ATENÇÃO: o dicionário técnico abaixo é minha melhor suposição a partir
  // de convenção de telecom (Normal received/Human answer = atendeu;
  // Answering machine/Message box = atendeu mas não é CPC — é máquina, não
  // pessoa; todo o resto = não atendeu). Se os números não baterem com o
  // que vocês esperam, é o primeiro lugar a ajustar.
  const chamadasRawRows = await queryOlos(
    pool,
    `
    SELECT
      b.agente_id,
      tb.descricao AS status_tecnico,
      CASE WHEN t.descricao NOT LIKE '%\\_Template' THEN t.descricao END AS status_negocio
    FROM bilhetagem b
    LEFT JOIN tabulacoes_bilhetagem tb ON tb.id = b.tabulacao_bilhetagem_id
    LEFT JOIN (
      SELECT identificador_telecom, MAX(id) AS max_id
      FROM tentativas_contato
      WHERE identificador_telecom IS NOT NULL
        AND data_inicio >= ? AND data_inicio < DATE_ADD(?, INTERVAL 1 DAY)
      GROUP BY identificador_telecom
    ) tc_latest ON tc_latest.identificador_telecom = b.identificador_telecom
    LEFT JOIN tentativas_contato tc ON tc.id = tc_latest.max_id
    LEFT JOIN tabulacoes t ON t.id = tc.tabulacao_id
    WHERE b.agente_id IS NOT NULL
      AND b.data_inicio >= ? AND b.data_inicio < DATE_ADD(?, INTERVAL 1 DAY)
    `,
    [sqlDate, sqlDate, sqlDate, sqlDate]
  );

  // Dicionário técnico — só os valores marcados true "atendem" (alguém ou
  // algo pegou o telefone). Answering machine/Message box atendem mas não
  // contam como CPC (não é a pessoa, é máquina) — tratado abaixo.
  const TECNICO_ATENDE = new Set([
    "NORMAL RECEIVED",
    "HUMAN ANSWER",
    "ANSWERING MACHINE",
    "MESSAGE BOX",
  ]);
  const TECNICO_E_HUMANO = new Set(["NORMAL RECEIVED", "HUMAN ANSWER"]);

  type ChamadaBruta = {
    agente_id: number;
    status_tecnico: string | null;
    status_negocio: string | null;
  };
  const chamadasPorAgenteAcc = new Map<
    number,
    {
      total_chamadas: number;
      chamadas_atendidas: number;
      total_contatos: number;
      tabulacoes_sucesso: number;
      tabulacoes_sucesso_negocio: number;
    }
  >();
  for (const r of chamadasRawRows as ChamadaBruta[]) {
    const acc = chamadasPorAgenteAcc.get(r.agente_id) || {
      total_chamadas: 0,
      chamadas_atendidas: 0,
      total_contatos: 0,
      tabulacoes_sucesso: 0,
      tabulacoes_sucesso_negocio: 0,
    };

    const tecnico = (r.status_tecnico || "").trim().toUpperCase();
    const atendidaTecnica = TECNICO_ATENDE.has(tecnico);
    const humanoTecnico = TECNICO_E_HUMANO.has(tecnico);

    const negocioFlags = r.status_negocio
      ? classifyDiscagem(r.status_negocio)
      : null;

    // atendida: qualquer um dos dois sinais confirma (negociação de
    // verdade só existe se a ligação foi atendida — sinal forte mesmo sem
    // o técnico confirmar)
    const atendida = atendidaTecnica || !!negocioFlags?.atendida;
    // cpc: exige atendida E (negócio confirma CPC, OU o técnico já indicou
    // humano de verdade sem ainda ter negociação registrada)
    const cpc = atendida && (negocioFlags?.cpc ?? humanoTecnico);
    const cpca = atendida && (negocioFlags?.cpca ?? false);
    const promessa = atendida && (negocioFlags?.promessa ?? false);

    acc.total_chamadas += 1;
    if (atendida) acc.chamadas_atendidas += 1;
    if (cpc) acc.total_contatos += 1;
    if (cpca) acc.tabulacoes_sucesso += 1;
    if (promessa) acc.tabulacoes_sucesso_negocio += 1;
    chamadasPorAgenteAcc.set(r.agente_id, acc);
  }

  type TempoRow = {
    agente_id: number;
    agente: string | null;
    login: string | null;
    primeiro_login: string | Date | null;
    ultimo_logout: string | Date | null;
    tempo_logado_seg: number;
    tempo_ocioso_seg: number;
    tempo_pausa_seg: number;
    pausas: number;
    tempo_tabulacao_seg: number;
  };

  const tempos = temposRows as TempoRow[];

  if (tempos.length === 0) {
    return {
      success: true,
      referenceDate,
      totalAgentes: 0,
      message: "Nenhum agente com estado registrado nesse dia (ainda).",
    };
  }

  const session = await createUploadSession({
    reportType: "AgentDay",
    fileName: `sync-olos-agentday-${sqlDate}`,
    referenceDate,
    totalRows: tempos.length,
  });

  await insertAgentDayRecords(
    session.id,
    tempos.map(t => {
      const c = chamadasPorAgenteAcc.get(t.agente_id);
      return {
        referenceDate,
        agente: t.agente || `Agente ${t.agente_id}`,
        login: t.login,
        idAgente: String(t.agente_id),
        primeiroLogin: t.primeiro_login
          ? hmsFromDate(new Date(t.primeiro_login))
          : "",
        ultimoLogout: t.ultimo_logout
          ? hmsFromDate(new Date(t.ultimo_logout))
          : "",
        tempoLogado: secondsToHMS(t.tempo_logado_seg || 0),
        tempoOcioso: secondsToHMS(t.tempo_ocioso_seg || 0),
        tempoPausa: secondsToHMS(t.tempo_pausa_seg || 0),
        tempoTabulacao: secondsToHMS(t.tempo_tabulacao_seg || 0),
        pausas: t.pausas || 0,
        logins: 1, // aproximado — o log de estados não marca logout/login explícito
        totalChamadas: c?.total_chamadas || 0,
        chamadasAtendidas: c?.chamadas_atendidas || 0,
        // CPC (contato com a pessoa certa) — sempre ⊆ chamadasAtendidas,
        // garantido pelo classifyDiscagem (cpc só é true se atendida também
        // for true). Antes do fix, CPC vinha de um critério independente e
        // dava pra sair maior que "atendidas" — impossível na prática.
        totalContatos: c?.total_contatos || 0,
        contatoEfetivo: c?.total_contatos || 0,
        tabulacoesTotal: c?.total_contatos || 0,
        tabulacoesSucesso: c?.tabulacoes_sucesso || 0,
        tabulacoesSucessoNegocio: c?.tabulacoes_sucesso_negocio || 0,
      };
    })
  );

  // Cadastra automaticamente no Dimensionamento quem apareceu no AgentDay
  // mas ainda não estava lá (mesmo comportamento que existia no upload
  // manual — só que agora roda sozinho a cada sincronização).
  try {
    const dimSync = await syncAgentesComDimensionamento([session.id]);
    if (dimSync.autoAdded.length > 0) {
      console.log(
        `[olos-sync] Dimensionamento: ${dimSync.autoAdded.length} agente(s) cadastrado(s) automaticamente`
      );
    }
  } catch (error: any) {
    console.error(
      "[olos-sync] erro ao sincronizar com Dimensionamento:",
      error?.message
    );
  }

  return { success: true, referenceDate, totalAgentes: tempos.length };
}

/**
 * Puxa Tabulações Excedidas direto de tentativas_contato — essa tabela já
 * tem data_fim_chamada e data_fim_tabulacao, então o tempo de tabulação
 * (quanto tempo o agente ficou tabulando depois que a ligação encerrou)
 * já vem pronto, sem precisar de estados_agente. Agrupado por
 * agente + tabulação, igual ao relatório manual espera.
 */
export async function syncTabulacoesExcedidasFromOlos(
  referenceDateBR?: string
): Promise<{
  success: boolean;
  referenceDate: string;
  totalLinhas: number;
  message?: string;
}> {
  const pool = getOlosPool();
  if (!pool) {
    return {
      success: false,
      referenceDate: referenceDateBR || todayBR(),
      totalLinhas: 0,
      message: "Sincronização com a OLOS não está configurada.",
    };
  }

  const referenceDate = referenceDateBR || todayBR();
  const sqlDate = brDateToSqlDate(referenceDate);

  const rows = await queryOlos(
    pool,
    `
    SELECT
      tc.agente_id,
      u.nome_usuario AS agente,
      u.login AS login,
      t.descricao AS tabulacao,
      su.nome_usuario AS nome_supervisor,
      COUNT(*) AS total_chamadas,
      SUM(
        GREATEST(TIMESTAMPDIFF(SECOND, tc.data_fim_chamada, tc.data_fim_tabulacao), 0)
      ) AS tempo_tabulacao_seg
    FROM tentativas_contato tc
    LEFT JOIN tabulacoes t ON t.id = tc.tabulacao_id
    LEFT JOIN usuarios u ON u.agente_id = tc.agente_id
    LEFT JOIN agente_supervisor asup ON asup.agente_id = tc.agente_id
    LEFT JOIN usuarios su ON su.agente_id = asup.supervisor_id
    WHERE tc.data_inicio >= ? AND tc.data_inicio < DATE_ADD(?, INTERVAL 1 DAY)
      AND tc.data_fim_tabulacao IS NOT NULL
      AND tc.data_fim_chamada IS NOT NULL
      AND (t.descricao IS NULL OR t.descricao NOT LIKE '%\\_Template')
    GROUP BY tc.agente_id, t.descricao
    `,
    [sqlDate, sqlDate]
  );

  const linhas = rows as Array<{
    agente_id: number;
    agente: string | null;
    login: string | null;
    tabulacao: string | null;
    nome_supervisor: string | null;
    total_chamadas: number;
    tempo_tabulacao_seg: number;
  }>;

  if (linhas.length === 0) {
    return {
      success: true,
      referenceDate,
      totalLinhas: 0,
      message: "Nenhuma tabulação encontrada nesse dia (ainda).",
    };
  }

  const session = await createUploadSession({
    reportType: "DispositionAgent",
    fileName: `sync-olos-tabulacoes-${sqlDate}`,
    referenceDate,
    totalRows: linhas.length,
  });

  await insertDispositionAgentRecords(
    session.id,
    linhas.map(l => ({
      agente: l.agente || `Agente ${l.agente_id}`,
      login: l.login,
      tabulacao: l.tabulacao || "Sem tabulação",
      nomeSupervisor: l.nome_supervisor || "",
      tempoTabulacao: secondsToHMS(l.tempo_tabulacao_seg || 0),
      totalChamadas: l.total_chamadas || 0,
    }))
  );

  return { success: true, referenceDate, totalLinhas: linhas.length };
}

/**
 * Puxa a quantidade de mailing por campanha, direto de tentativas_contato
 * (COUNT DISTINCT mailing_registro_id — pessoa/registro, não telefone,
 * já que uma pessoa pode ter mais de um número). Substitui o campo
 * digitado manualmente na Performance por Campanha.
 *
 * IMPORTANTE — diferente das outras sincronizações: aqui NÃO tem filtro
 * de data, é histórico completo (o número reflete quantos registros
 * distintos já foram discados NESSA campanha desde sempre, que é a
 * aproximação mais fiel de "tamanho real do mailing"). Por isso é mais
 * pesado — comece rodando manual, só considere automatizar (agendador)
 * depois de confirmar que os números batem com o que já era digitado.
 */
/**
 * Puxa a quantidade de mailing por campanha, direto de tentativas_contato
 * (COUNT DISTINCT mailing_registro_id — pessoa/registro, não telefone).
 * Substitui o campo digitado manualmente na Performance por Campanha.
 *
 * MUDANÇA IMPORTANTE (depois do primeiro teste ter ficado lento): antes
 * escaneava o histórico INTEIRO (sem filtro de data), o que ficava cada
 * vez mais lento conforme mais dado se acumula. Agora é escopado por dia
 * — mesmo padrão rápido (intervalo de data, usa o índice) das outras
 * sincronizações. Isso muda o SIGNIFICADO do número: não é mais "tamanho
 * total histórico do mailing", é "quantos registros distintos foram
 * discados NESSE dia". Se a campanha trabalha uma mailing nova a cada dia,
 * isso é exatamente certo. Se é uma mailing única indo até o fim aos
 * poucos, isso vai mostrar só uma FATIA por dia, não o total.
 */
export async function syncMailingFromOlos(referenceDateBR?: string): Promise<{
  success: boolean;
  referenceDate: string;
  totalCampanhas: number;
  message?: string;
}> {
  const pool = getOlosPool();
  if (!pool) {
    return {
      success: false,
      referenceDate: referenceDateBR || todayBR(),
      totalCampanhas: 0,
      message: "Sincronização com a OLOS não está configurada.",
    };
  }

  const referenceDate = referenceDateBR || todayBR();
  const sqlDate = brDateToSqlDate(referenceDate);

  // Timeout maior aqui (5min em vez de 2min) — COUNT(DISTINCT
  // mailing_registro_id) é pesado porque essa coluna não tem índice no
  // banco de vocês (confirmado no schema). Não resolve a causa raiz, só
  // dá mais tempo enquanto isso não é endereçado (ver aviso abaixo).
  const rows = await queryOlos(
    pool,
    `
    SELECT
      c.descricao AS campanha,
      COUNT(DISTINCT tc.mailing_registro_id) AS mailing
    FROM campanhas c
    INNER JOIN tentativas_contato tc ON tc.campanha_id = c.id
    WHERE tc.mailing_registro_id IS NOT NULL
      AND tc.data_inicio >= ?
      AND tc.data_inicio < DATE_ADD(?, INTERVAL 1 DAY)
    GROUP BY c.descricao
    `,
    [sqlDate, sqlDate],
    5 * 60_000
  );

  const linhas = rows as Array<{ campanha: string; mailing: number }>;
  for (const l of linhas) {
    if (l.campanha) await upsertCampanhaMailing(l.campanha, l.mailing);
  }

  return { success: true, referenceDate, totalCampanhas: linhas.length };
}

let _schedulerStarted = false;
let lastSyncResult: {
  at: string;
  success: boolean;
  totalLinhas: number;
  message?: string;
} | null = null;

export function getLastSyncResult() {
  return lastSyncResult;
}

export function startOlosScheduler() {
  if (_schedulerStarted || !OLOS_SYNC_CONFIGURED) return;
  _schedulerStarted = true;

  const intervalMs = Math.max(1, ENV.olosSyncIntervalMin) * 60 * 1000;

  const run = async () => {
    try {
      const result = await syncDiscagemFromOlos();
      const pausas = await syncPausasFromOlos();
      const agentDay = await syncAgentDayFromOlos();
      const tabulacoes = await syncTabulacoesExcedidasFromOlos();
      // Mailing FICA DE FORA do agendador automático — COUNT(DISTINCT
      // mailing_registro_id) é pesado (coluna sem índice no banco de
      // vocês) e não deve rodar sozinho a cada poucos minutos. Só manual,
      // pelo botão, até isso ser otimizado (ver aviso na função).
      lastSyncResult = {
        at: new Date().toISOString(),
        success:
          result.success &&
          pausas.success &&
          agentDay.success &&
          tabulacoes.success,
        totalLinhas: result.totalLinhas,
        message: result.message,
      };
      console.log(
        `[olos-sync] ${result.referenceDate}: ${result.totalLinhas} linhas discagem, ${pausas.totalAgentes} agentes com pausa, ${agentDay.totalAgentes} agentes no AgentDay, ${tabulacoes.totalLinhas} linhas de tabulação`
      );
    } catch (error: any) {
      lastSyncResult = {
        at: new Date().toISOString(),
        success: false,
        totalLinhas: 0,
        message: error?.message || "Erro desconhecido",
      };
      console.error("[olos-sync] erro:", error);
    }
  };

  // Roda uma vez ao subir o servidor, depois no intervalo configurado.
  run();
  setInterval(run, intervalMs);
  console.log(
    `[olos-sync] agendador iniciado — a cada ${ENV.olosSyncIntervalMin} min`
  );
}
