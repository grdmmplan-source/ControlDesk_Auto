import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { canaisRotasRouter } from "./routers/canaisRotas";
import { bookOperacionalRouter } from "./routers/bookOperacional";
import { suggestionsRouter } from "./routers/suggestions";
import { mopRouter } from "./routers/mop";
import { userManagementRouter } from "./routers/userManagement";
import { olosSyncRouter } from "./routers/olosSync";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { login as loginLocal, signSession } from "./_core/auth";
import { z } from "zod";

// Nunca envia passwordHash pro navegador — usado em auth.me e auth.login.
function sanitizeUser<T extends { passwordHash?: string | null }>(
  user: T | null
): Omit<T, "passwordHash"> | null {
  if (!user) return null;
  const { passwordHash, ...rest } = user;
  return rest;
}
import {
  createUploadSession,
  getUploadSessions,
  getAgentDayRecords,
  getReasonAgentRecords,
  getCampaignAgentRecords,
  getDispositionAgentRecords,
  insertAgentDayRecords,
  insertReasonAgentRecords,
  insertCampaignAgentRecords,
  insertDispositionAgentRecords,
  getDimensionamento,
  getAppSettings,
  setAppSetting,
  getDimensionamentoStats,
  insertDimensionamento,
  syncAgentesComDimensionamento,
  updateDimensionamento,
  deleteDimensionamento,
  getPauseLimits,
  upsertPauseLimit,
  deletePauseLimit,
  getDiscagemRecords,
  getDiscagemRecordsBySessionIds,
  getDiscagemReferenceDates,
  getCampanhaMailingMap,
  upsertCampanhaMailing,
  getDb,
} from "./db";
import {
  classifyDiscagem,
  classifyQualidade,
  isCpcaSemConversao,
} from "./discagemClassifier";
import { dimensionamento } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import {
  detectReportType,
  parseAgentDay,
  parseReasonAgent,
  parseCampaignAgent,
  parseDispositionAgent,
} from "./parsers";
import { readFileSync, existsSync } from "fs";
import { join } from "path";

// Constrói mapa de dimensionamento a partir de um array de registros do banco
function buildDimMap(dimRows: any[]): Record<
  string,
  {
    turno: string;
    celula: string;
    skill: string;
    supervisor: string;
    entrada: string;
    saida: string;
    uf: string;
  }
> {
  const map: Record<string, any> = {};
  for (const a of dimRows) {
    if (a.nome) {
      const key = a.nome.trim().toUpperCase();
      map[key] = {
        turno: a.turno || "",
        celula: a.celula || "",
        skill: a.skill || "",
        supervisor: a.supervisor || "",
        entrada: a.entrada || "",
        saida: a.saida || "",
        uf: a.uf || "",
      };
    }
    if (a.login) {
      const loginKey = `LOGIN:${a.login.trim().toLowerCase()}`;
      map[loginKey] = {
        turno: a.turno || "",
        celula: a.celula || "",
        skill: a.skill || "",
        supervisor: a.supervisor || "",
        entrada: a.entrada || "",
        saida: a.saida || "",
        uf: a.uf || "",
      };
    }
  }
  return map;
}

// Helper para converter tempo HH:MM:SS em segundos
function timeToSeconds(t: string | null | undefined): number {
  if (!t) return 0;
  const parts = t.split(":").map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

// Limites padrão de pausa (NR17 + outros). Usados quando o usuário não
// configurou um override específico via tela de Configurações.
// Configurável em runtime: ver dashboard.pauseLimits.* e tabela pause_limits.
const DEFAULT_PAUSE_LIMITS: Record<string, number> = {
  "descanso 1": 10 * 60,
  "descanso 2": 10 * 60,
  "descanso 3": 10 * 60,
  lanche: 20 * 60,
  banheiro: 10 * 60,
  "pausa descanso 1": 10 * 60,
  "pausa descanso 2": 10 * 60,
  "pausa descanso 3": 10 * 60,
  "pausa lanche": 20 * 60,
  "pausa banheiro": 10 * 60,
};

// Mescla os padrões com os overrides gravados no banco (overrides ganham).
async function getEffectivePauseLimits(): Promise<Record<string, number>> {
  const overrides = await getPauseLimits();
  const merged: Record<string, number> = { ...DEFAULT_PAUSE_LIMITS };
  for (const o of overrides) merged[o.motivo] = o.limiteSegundos;
  return merged;
}

export const appRouter = router({
  system: systemRouter,
  canaisRotas: canaisRotasRouter,
  book: bookOperacionalRouter,
  suggestions: suggestionsRouter,
  mop: mopRouter,
  userManagement: userManagementRouter,
  olosSync: olosSyncRouter,
  auth: router({
    me: publicProcedure.query(opts => sanitizeUser(opts.ctx.user)),
    login: publicProcedure
      .input(
        z.object({ username: z.string().min(1), password: z.string().min(1) })
      )
      .mutation(async ({ input, ctx }) => {
        const user = await loginLocal(input.username, input.password);
        if (!user) {
          throw new Error("Usuário ou senha inválidos.");
        }
        const sessionToken = await signSession(
          { openId: user.openId },
          { expiresInMs: ONE_YEAR_MS }
        );
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, {
          ...cookieOptions,
          maxAge: ONE_YEAR_MS,
        });
        return { success: true, user: sanitizeUser(user) };
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Upload ────────────────────────────────────────────────────────────────
  dashboard: router({
    // Processa HTML de relatório e persiste no banco
    processReport: protectedProcedure
      .input(
        z.object({
          htmlContent: z.string(),
          fileName: z.string(),
          reportType: z
            .enum([
              "AgentDay",
              "ReasonAgent",
              "CampaignAgent",
              "DispositionAgent",
            ])
            .optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const { htmlContent, fileName } = input;

        // Detectar tipo se não informado
        const reportType = input.reportType || detectReportType(htmlContent);
        if (!reportType)
          throw new Error(
            "Não foi possível detectar o tipo de relatório. Verifique o arquivo."
          );

        let parsed: { referenceDate: string; rows: any[] };

        switch (reportType) {
          case "AgentDay":
            parsed = parseAgentDay(htmlContent);
            break;
          case "ReasonAgent":
            parsed = parseReasonAgent(htmlContent);
            break;
          case "CampaignAgent":
            parsed = parseCampaignAgent(htmlContent);
            break;
          case "DispositionAgent":
            parsed = parseDispositionAgent(htmlContent);
            break;
          default:
            throw new Error("Tipo de relatório inválido");
        }

        const session = await createUploadSession({
          reportType,
          fileName,
          referenceDate: parsed.referenceDate,
          totalRows: parsed.rows.length,
          uploadedBy: ctx.user?.id,
        });

        const sessionId = session.id;

        switch (reportType) {
          case "AgentDay":
            await insertAgentDayRecords(sessionId, parsed.rows);
            break;
          case "ReasonAgent":
            await insertReasonAgentRecords(sessionId, parsed.rows);
            break;
          case "CampaignAgent":
            await insertCampaignAgentRecords(sessionId, parsed.rows);
            break;
          case "DispositionAgent":
            await insertDispositionAgentRecords(sessionId, parsed.rows);
            break;
        }

        return {
          sessionId,
          reportType,
          fileName,
          referenceDate: parsed.referenceDate,
          totalRows: parsed.rows.length,
        };
      }),

    // Lista histórico de uploads
    getSessions: protectedProcedure
      .input(z.object({ reportType: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await getUploadSessions(input?.reportType);
      }),

    // ─── Faixa 1: AgentDay ─────────────────────────────────────────────────
    getAgentDay: protectedProcedure
      .input(
        z.object({
          sessionIds: z.array(z.number()).optional(),
          agente: z.string().optional(),
          uf: z.string().optional(),
          turno: z.string().optional(),
          celula: z.string().optional(),
          supervisor: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const [rows, dimRows] = await Promise.all([
          getAgentDayRecords({
            sessionIds: input.sessionIds,
            agente: input.agente,
            uf: input.uf,
          }),
          getDimensionamento({}),
        ]);
        const dimMap = buildDimMap(dimRows);

        // Enriquece cada linha com métricas calculadas e dados do dimensionamento
        const enriched = rows.map(row => {
          const tempoLogadoSeg = timeToSeconds(row.tempoLogado);
          const tempoOciosoSeg = timeToSeconds(row.tempoOcioso);
          const tempoPausaSeg = timeToSeconds(row.tempoPausa);
          const chamadas = row.chamadasAtendidas || 0;
          const cpc = row.contatoEfetivo || 0;
          const sucessoNeg = row.tabulacoesSucessoNegocio || 0;

          // Idle = Tempo Ocioso / Chamadas Atendidas (em segundos por chamada)
          const idleSeg =
            chamadas > 0 ? Math.round(tempoOciosoSeg / chamadas) : 0;
          // TMA = (Tempo Logado - Tempo Ocioso - Tempo Pausa) / Chamadas Atendidas
          const tempoFaladoSeg = Math.max(
            0,
            tempoLogadoSeg - tempoOciosoSeg - tempoPausaSeg
          );
          const tmaSeg =
            chamadas > 0 ? Math.round(tempoFaladoSeg / chamadas) : 0;
          // % CPC = CPC / Chamadas * 100
          const cpcPct =
            chamadas > 0 ? Math.round((cpc / chamadas) * 100 * 10) / 10 : 0;
          // % Sucesso Neg = Sucesso Neg / CPC * 100 (ou / chamadas se CPC = 0)
          const sucessoNegPct =
            cpc > 0
              ? Math.round((sucessoNeg / cpc) * 100 * 10) / 10
              : chamadas > 0
                ? Math.round((sucessoNeg / chamadas) * 100 * 10) / 10
                : 0;
          // % Tempo Logado = Tempo Logado / Jornada padrão (8h = 28800s)
          const jornadaPadrao = 8 * 3600;
          const tempoLogadoPct = Math.min(
            100,
            Math.round((tempoLogadoSeg / jornadaPadrao) * 100 * 10) / 10
          );

          // Busca no dimensionamento por nome ou login
          const nomeKey = (row.agente || "").trim().toUpperCase();
          const loginKey = `LOGIN:${(row.login || "").trim().toLowerCase()}`;
          const dim = dimMap[nomeKey] || dimMap[loginKey] || null;

          return {
            ...row,
            // Métricas calculadas
            idleSeg,
            tmaSeg,
            cpcPct,
            sucessoNegPct,
            tempoLogadoPct,
            tempoFaladoSeg,
            // Dados do dimensionamento
            turno: dim?.turno || "",
            celula: dim?.celula || "",
            skill: dim?.skill || "",
            supervisorDim: dim?.supervisor || "",
            entradaPrevista: dim?.entrada || "",
            saidaPrevista: dim?.saida || "",
            // Flag: agente não encontrado no dimensionamento
            noDimensionamento: dim !== null,
          };
        });

        // Aplica filtros de turno/célula/supervisor (do dimensionamento)
        let filtered = enriched;
        if (input.turno)
          filtered = filtered.filter(r => r.turno === input.turno);
        if (input.celula)
          filtered = filtered.filter(r => r.celula === input.celula);
        if (input.supervisor)
          filtered = filtered.filter(r => r.supervisorDim === input.supervisor);

        return filtered;
      }),

    // ─── Faltas & Atrasos (cruza Dimensionamento x AgentDay) ────────────────
    getFaltasAtrasos: protectedProcedure
      .input(
        z.object({
          referenceDate: z.string().optional(),
          celula: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const sessions = await getUploadSessions("AgentDay");
        const dates = Array.from(
          new Set(sessions.map(s => s.referenceDate).filter(Boolean))
        ) as string[];
        const referenceDate = input.referenceDate || dates[0];
        if (!referenceDate)
          return { referenceDate: null, tolerancia: 10, agentes: [] };

        const sessionIds = sessions
          .filter(s => s.referenceDate === referenceDate)
          .map(s => s.id);
        const [agentDayRows, dimRows] = await Promise.all([
          getAgentDayRecords({ sessionIds }),
          getDimensionamento({}),
        ]);

        const byNome: Record<string, (typeof agentDayRows)[number]> = {};
        const byLogin: Record<string, (typeof agentDayRows)[number]> = {};
        for (const r of agentDayRows) {
          if (r.agente) byNome[r.agente.trim().toUpperCase()] = r;
          if (r.login) byLogin[r.login.trim().toLowerCase()] = r;
        }

        const TOLERANCIA_MIN = 10;
        function toMinutes(hhmm: string | null | undefined): number | null {
          if (!hhmm) return null;
          const m = hhmm.match(/^(\d{1,2}):(\d{2})/);
          if (!m) return null;
          return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
        }

        let ativos = dimRows.filter(
          a => (a.status || "").toUpperCase() === "ATIVO"
        );
        if (input.celula)
          ativos = ativos.filter(a => a.celula === input.celula);

        const agentes = ativos.map(a => {
          const nomeKey = (a.nome || "").trim().toUpperCase();
          const loginKey = (a.login || "").trim().toLowerCase();
          const match =
            byNome[nomeKey] || (loginKey ? byLogin[loginKey] : undefined);

          const entradaPrevistaMin = toMinutes(a.entrada);
          let status: "falta" | "atraso" | "ok" | "sem_horario" = "ok";
          let atrasoMin = 0;
          let primeiroLogin: string | null = null;

          if (!match) {
            status = "falta";
          } else {
            primeiroLogin = match.primeiroLogin || null;
            const loginMin = toMinutes(primeiroLogin);
            if (entradaPrevistaMin === null || loginMin === null) {
              status = "sem_horario";
            } else {
              const diff = loginMin - entradaPrevistaMin;
              if (diff > TOLERANCIA_MIN) {
                status = "atraso";
                atrasoMin = diff;
              } else {
                status = "ok";
              }
            }
          }

          return {
            nome: a.nome,
            login: a.login,
            celula: a.celula,
            turno: a.turno,
            supervisor: a.supervisor,
            entradaPrevista: a.entrada,
            primeiroLogin,
            status,
            atrasoMin,
          };
        });

        const ordem: Record<string, number> = {
          falta: 0,
          atraso: 1,
          sem_horario: 2,
          ok: 3,
        };
        agentes.sort(
          (x, y) =>
            ordem[x.status] - ordem[y.status] || y.atrasoMin - x.atrasoMin
        );

        return { referenceDate, tolerancia: TOLERANCIA_MIN, agentes };
      }),

    // ─── Faixa 2: TEMPOS (ReasonAgent) ─────────────────────────────────────────
    // Retorna as datas disponíveis para um tipo de relatório (histórico)
    getAvailableDates: protectedProcedure
      .input(
        z.object({
          reportType: z.enum([
            "AgentDay",
            "ReasonAgent",
            "CampaignAgent",
            "DispositionAgent",
          ]),
        })
      )
      .query(async ({ input }) => {
        const sessions = await getUploadSessions(input.reportType);
        // Retorna datas únicas ordenadas do mais recente para o mais antigo
        const dates = Array.from(
          new Set(sessions.map(s => s.referenceDate).filter(Boolean))
        ).sort((a, b) => (b || "").localeCompare(a || ""));
        return dates as string[];
      }),

    getReasonAgent: protectedProcedure
      .input(
        z.object({
          sessionIds: z.array(z.number()).optional(),
          agente: z.string().optional(),
          referenceDate: z.string().optional(), // filtro de data para histórico
        })
      )
      .query(async ({ input }) => {
        // Se referenceDate fornecida, busca sessionIds da data específica
        let sessionIds = input.sessionIds;
        if (input.referenceDate && !sessionIds) {
          const sessions = await getUploadSessions("ReasonAgent");
          const sessionsForDate = sessions.filter(
            s => s.referenceDate === input.referenceDate
          );
          sessionIds = sessionsForDate.map(s => s.id);
        }
        const rows = await getReasonAgentRecords({
          sessionIds,
          agente: input.agente,
        });

        // Carrega dimensionamento do banco para cruzar turno
        const dimRowsNR17 = await getDimensionamento({});
        const dimMapNR17 = buildDimMap(dimRowsNR17);
        function getTurnoAgente(agente: string): string {
          const nomeKey = agente.trim().toUpperCase();
          const loginKey = `LOGIN:${agente.trim().toLowerCase()}`;
          return (
            dimMapNR17[nomeKey]?.turno || dimMapNR17[loginKey]?.turno || ""
          );
        }

        // Limites NR17 (obrigatórios) e outros — padrão + overrides configuráveis
        // pelo usuário (tela de Configurações → dashboard.pauseLimits.*).
        const PAUSE_LIMITS = await getEffectivePauseLimits();

        function getLimiteSeg(motivo: string): number | null {
          const m = motivo.toLowerCase().trim();
          for (const [key, val] of Object.entries(PAUSE_LIMITS)) {
            if (m.includes(key)) return val;
          }
          return null;
        }

        // Classificação por categoria de pausa
        type PauseCategory = "nr17" | "banheiro" | "feedback" | "outros";
        function getCategoria(motivo: string): PauseCategory {
          const m = motivo.toLowerCase().trim();
          if (
            m.includes("descanso") ||
            m.includes("lanche") ||
            m.includes("pausa descanso") ||
            m.includes("pausa lanche")
          )
            return "nr17";
          if (m.includes("banheiro")) return "banheiro";
          if (
            m.includes("feedback") ||
            m.includes("treinamento") ||
            m.includes("training")
          )
            return "feedback";
          return "outros";
        }

        function isImprodutiva(motivo: string): boolean {
          const m = motivo.toLowerCase().trim();
          if (m.includes("feedback") || m.includes("treinamento")) return false;
          if (
            m.includes("erro de sistema") ||
            m.includes("erro sistema") ||
            m === "erro"
          )
            return false;
          if (m.includes("atendimento chat") || m === "chat") return false;
          return true;
        }

        // Estruturas de agrupamento
        const byAgenteMotivo: Record<
          string,
          {
            agente: string;
            motivo: string;
            categoria: PauseCategory;
            totalSegundos: number;
            totalPausas: number;
            limiteSegundos: number | null;
            excedeuLimite: boolean;
            excedidoSegundos: number;
          }
        > = {};
        const byMotivo: Record<
          string,
          {
            motivo: string;
            totalPausas: number;
            totalSegundos: number;
            agentes: Set<string>;
            improdutiva: boolean;
            categoria: PauseCategory;
          }
        > = {};
        const byAgenteImprod: Record<
          string,
          {
            agente: string;
            totalSegundos: number;
            totalPausas: number;
            pausasExcedidas: number;
          }
        > = {};
        const byAgente: Record<
          string,
          { agente: string; totalSegundos: number; totalPausas: number }
        > = {};

        function getSupervisorAgente(agente: string): string {
          const nomeKey = agente.trim().toUpperCase();
          const loginKey = `LOGIN:${agente.trim().toLowerCase()}`;
          return (
            dimMapNR17[nomeKey]?.supervisor ||
            dimMapNR17[loginKey]?.supervisor ||
            "Sem supervisor"
          );
        }

        // NR17: por agente + motivo NR17 (para ver quem estourou cada pausa obrigatória)
        const byAgenteNR17: Record<
          string,
          {
            agente: string;
            motivo: string;
            totalSegundos: number;
            totalPausas: number;
            limiteSegundos: number;
            excedeuLimite: boolean;
            excedidoSegundos: number;
            turno: string;
            supervisor: string;
          }
        > = {};

        // NR17 por SUPERVISOR — pra achar em qual time o problema se
        // concentra, não só qual agente individual.
        const bySupervisorNR17: Record<
          string,
          {
            supervisor: string;
            totalSegundos: number;
            totalPausas: number;
            excedidoSegundos: number;
            agentesComExcessoSet: Set<string>;
            agentesSet: Set<string>;
          }
        > = {};

        // Banheiro: por agente (tempo total + ocorrências)
        const byAgenteBanheiro: Record<
          string,
          { agente: string; totalSegundos: number; totalPausas: number }
        > = {};

        // Feedback/Treinamento: por agente
        const byAgenteFeedback: Record<
          string,
          {
            agente: string;
            motivo: string;
            totalSegundos: number;
            totalPausas: number;
          }
        > = {};

        // Outros: por agente + motivo (tudo que não é NR17, banheiro, feedback)
        const byAgenteOutros: Record<
          string,
          {
            agente: string;
            motivo: string;
            totalSegundos: number;
            totalPausas: number;
          }
        > = {};

        for (const row of rows) {
          const motivo = row.motivoDePausa || "Sem motivo";
          const segundos = timeToSeconds(row.tempoTotalDePausa);
          const pausas = row.pausasTotalizadoPorCampanha || 0;
          const improd = isImprodutiva(motivo);
          const limite = getLimiteSeg(motivo);
          // Regra: 11 min em pausa de 10 min já é estourado (excede o limite sem tolerância)
          const excedeu = limite !== null && segundos > limite;
          const excedidoSeg =
            excedeu && limite !== null ? Math.max(0, segundos - limite) : 0;
          const categoria = getCategoria(motivo);
          const agente = row.agente || "Desconhecido";

          // Por motivo (visão geral)
          if (!byMotivo[motivo])
            byMotivo[motivo] = {
              motivo,
              totalPausas: 0,
              totalSegundos: 0,
              agentes: new Set(),
              improdutiva: improd,
              categoria,
            };
          byMotivo[motivo].totalPausas += pausas;
          byMotivo[motivo].totalSegundos += segundos;
          if (row.agente) byMotivo[motivo].agentes.add(row.agente);

          // Por agente (geral)
          if (!byAgente[agente])
            byAgente[agente] = { agente, totalSegundos: 0, totalPausas: 0 };
          byAgente[agente].totalSegundos += segundos;
          byAgente[agente].totalPausas += pausas;

          // Por agente (improdutivas)
          if (improd) {
            if (!byAgenteImprod[agente])
              byAgenteImprod[agente] = {
                agente,
                totalSegundos: 0,
                totalPausas: 0,
                pausasExcedidas: 0,
              };
            byAgenteImprod[agente].totalSegundos += segundos;
            byAgenteImprod[agente].totalPausas += pausas;
            if (excedeu) byAgenteImprod[agente].pausasExcedidas += 1;
          }

          // Por agente + motivo (abusadores)
          const key = `${agente}||${motivo}`;
          if (!byAgenteMotivo[key]) {
            byAgenteMotivo[key] = {
              agente,
              motivo,
              categoria,
              totalSegundos: 0,
              totalPausas: 0,
              limiteSegundos: limite,
              excedeuLimite: false,
              excedidoSegundos: 0,
            };
          }
          byAgenteMotivo[key].totalSegundos += segundos;
          byAgenteMotivo[key].totalPausas += pausas;
          if (excedeu) {
            byAgenteMotivo[key].excedeuLimite = true;
            byAgenteMotivo[key].excedidoSegundos += excedidoSeg;
          }

          // NR17
          if (categoria === "nr17" && limite !== null) {
            const nr17Key = `${agente}||${motivo}`;
            if (!byAgenteNR17[nr17Key])
              byAgenteNR17[nr17Key] = {
                agente,
                motivo,
                totalSegundos: 0,
                totalPausas: 0,
                limiteSegundos: limite,
                excedeuLimite: false,
                excedidoSegundos: 0,
                turno: getTurnoAgente(agente),
                supervisor: getSupervisorAgente(agente),
              };
            byAgenteNR17[nr17Key].totalSegundos += segundos;
            byAgenteNR17[nr17Key].totalPausas += pausas;
            if (excedeu) {
              byAgenteNR17[nr17Key].excedeuLimite = true;
              byAgenteNR17[nr17Key].excedidoSegundos += excedidoSeg;
            }

            // Agrega o mesmo dado por supervisor
            const supervisor = getSupervisorAgente(agente);
            if (!bySupervisorNR17[supervisor])
              bySupervisorNR17[supervisor] = {
                supervisor,
                totalSegundos: 0,
                totalPausas: 0,
                excedidoSegundos: 0,
                agentesComExcessoSet: new Set(),
                agentesSet: new Set(),
              };
            bySupervisorNR17[supervisor].totalSegundos += segundos;
            bySupervisorNR17[supervisor].totalPausas += pausas;
            bySupervisorNR17[supervisor].agentesSet.add(agente);
            if (excedeu) {
              bySupervisorNR17[supervisor].excedidoSegundos += excedidoSeg;
              bySupervisorNR17[supervisor].agentesComExcessoSet.add(agente);
            }
          }

          // Banheiro
          if (categoria === "banheiro") {
            if (!byAgenteBanheiro[agente])
              byAgenteBanheiro[agente] = {
                agente,
                totalSegundos: 0,
                totalPausas: 0,
              };
            byAgenteBanheiro[agente].totalSegundos += segundos;
            byAgenteBanheiro[agente].totalPausas += pausas;
          }

          // Feedback/Treinamento
          if (categoria === "feedback") {
            const fbKey = `${agente}||${motivo}`;
            if (!byAgenteFeedback[fbKey])
              byAgenteFeedback[fbKey] = {
                agente,
                motivo,
                totalSegundos: 0,
                totalPausas: 0,
              };
            byAgenteFeedback[fbKey].totalSegundos += segundos;
            byAgenteFeedback[fbKey].totalPausas += pausas;
          }

          // Outros
          if (categoria === "outros") {
            const outKey = `${agente}||${motivo}`;
            if (!byAgenteOutros[outKey])
              byAgenteOutros[outKey] = {
                agente,
                motivo,
                totalSegundos: 0,
                totalPausas: 0,
              };
            byAgenteOutros[outKey].totalSegundos += segundos;
            byAgenteOutros[outKey].totalPausas += pausas;
          }
        }

        const motivoChart = Object.values(byMotivo)
          .map(m => ({ ...m, agentes: m.agentes.size }))
          .sort((a, b) => b.totalSegundos - a.totalSegundos);

        const motivoImprodChart = Object.values(byMotivo)
          .filter(m => m.improdutiva)
          .map(m => ({ ...m, agentes: m.agentes.size }))
          .sort((a, b) => b.totalSegundos - a.totalSegundos);

        const agenteRanking = Object.values(byAgenteImprod)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 20);

        const agenteRankingGeral = Object.values(byAgente)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 20);

        const abusadoresPausa = Object.values(byAgenteMotivo)
          .filter(r => r.excedeuLimite)
          .sort((a, b) => b.excedidoSegundos - a.excedidoSegundos)
          .slice(0, 30);

        // NR17: quem estourou pausas obrigatórias
        const nr17Abusadores = Object.values(byAgenteNR17)
          .filter(r => r.excedeuLimite)
          .sort((a, b) => b.excedidoSegundos - a.excedidoSegundos);

        // NR17: todos (incluindo quem não estourou, para visão completa)
        const nr17Todos = Object.values(byAgenteNR17).sort(
          (a, b) => b.totalSegundos - a.totalSegundos
        );

        // Banheiro: ranking por tempo total
        const banheiroRanking = Object.values(byAgenteBanheiro)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 20);

        // Feedback/Treinamento: ranking
        const feedbackRanking = Object.values(byAgenteFeedback)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 20);

        // Outros: ranking por agente + motivo
        const outrosRanking = Object.values(byAgenteOutros)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 30);

        // Motivos únicos da categoria "outros" para filtro
        const outrosMotivos = Array.from(
          new Set(Object.values(byAgenteOutros).map(r => r.motivo))
        ).sort();

        // % pausa total por agente: totalPausas / tempoLogado (precisa cruzar com AgentDay)
        // Retornamos o total de segundos por agente para o frontend calcular
        const pausaTotalPorAgente = Object.values(byAgente)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 30);

        const pausaLimites = Object.entries(PAUSE_LIMITS).map(
          ([motivo, seg]) => ({
            motivo,
            limiteMin: Math.round(seg / 60),
          })
        );

        // NR17 por supervisor — pior primeiro (mais tempo excedido)
        const supervisorNR17Ranking = Object.values(bySupervisorNR17)
          .map(s => ({
            supervisor: s.supervisor,
            totalSegundos: s.totalSegundos,
            totalPausas: s.totalPausas,
            excedidoSegundos: s.excedidoSegundos,
            agentesComExcesso: s.agentesComExcessoSet.size,
            totalAgentes: s.agentesSet.size,
            nomesComExcesso: Array.from(s.agentesComExcessoSet).sort(),
          }))
          .sort((a, b) => b.excedidoSegundos - a.excedidoSegundos);

        return {
          rows,
          motivoChart,
          motivoImprodChart,
          agenteRanking,
          agenteRankingGeral,
          abusadoresPausa,
          pausaLimites,
          nr17Abusadores,
          nr17Todos,
          supervisorNR17Ranking,
          banheiroRanking,
          feedbackRanking,
          outrosRanking,
          outrosMotivos,
          pausaTotalPorAgente,
        };
      }),

    // ─── Faixa 3: CampaignAgent ────────────────────────────────────────────
    getCampaignAgent: protectedProcedure
      .input(
        z.object({
          sessionIds: z.array(z.number()).optional(),
          campanha: z.string().optional(),
          supervisor: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const rows = await getCampaignAgentRecords({
          sessionIds: input.sessionIds,
          campanha: input.campanha,
          supervisor: input.supervisor,
        });

        // Agrupa por campanha
        const byCampanha: Record<
          string,
          {
            campanha: string;
            supervisores: Set<string>;
            totalChamadas: number;
            totalContatos: number;
            tabulacoesSucesso: number;
            tabulacoesSucessoNegocio: number;
            agentes: number;
          }
        > = {};

        for (const row of rows) {
          const camp = row.campanha || "Sem campanha";
          if (!byCampanha[camp]) {
            byCampanha[camp] = {
              campanha: camp,
              supervisores: new Set(),
              totalChamadas: 0,
              totalContatos: 0,
              tabulacoesSucesso: 0,
              tabulacoesSucessoNegocio: 0,
              agentes: 0,
            };
          }
          byCampanha[camp].totalChamadas += row.totalChamadas || 0;
          byCampanha[camp].totalContatos += row.totalContatos || 0;
          byCampanha[camp].tabulacoesSucesso += row.tabulacoesSucesso || 0;
          byCampanha[camp].tabulacoesSucessoNegocio +=
            row.tabulacoesSucessoNegocio || 0;
          byCampanha[camp].agentes += 1;
          if (row.nomeSupervisor)
            byCampanha[camp].supervisores.add(row.nomeSupervisor);
        }

        const campanhaChart = Object.values(byCampanha)
          .map(c => ({
            ...c,
            supervisores: Array.from(c.supervisores)
              .filter(s => s && !/^\d+$/.test(s.trim()))
              .join(", "),
          }))
          .sort((a, b) => b.totalChamadas - a.totalChamadas);

        // Visão por agente/célula: agrega chamadas e contatos por agente+campanha
        const byAgenteCampanha: Record<
          string,
          {
            agente: string;
            campanha: string;
            nomeSupervisor: string;
            totalChamadas: number;
            totalContatos: number;
            tabulacoesSucesso: number;
            tabulacoesSucessoNegocio: number;
          }
        > = {};
        for (const row of rows) {
          const key = `${row.agente}||${row.campanha}`;
          if (!byAgenteCampanha[key]) {
            byAgenteCampanha[key] = {
              agente: row.agente || "",
              campanha: row.campanha || "",
              nomeSupervisor: row.nomeSupervisor || "",
              totalChamadas: 0,
              totalContatos: 0,
              tabulacoesSucesso: 0,
              tabulacoesSucessoNegocio: 0,
            };
          }
          byAgenteCampanha[key].totalChamadas += row.totalChamadas || 0;
          byAgenteCampanha[key].totalContatos += row.totalContatos || 0;
          byAgenteCampanha[key].tabulacoesSucesso += row.tabulacoesSucesso || 0;
          byAgenteCampanha[key].tabulacoesSucessoNegocio +=
            row.tabulacoesSucessoNegocio || 0;
        }
        const agenteCampanhaList = Object.values(byAgenteCampanha).sort(
          (a, b) => b.totalChamadas - a.totalChamadas
        );

        return { rows, campanhaChart, agenteCampanhaList };
      }),

    // ─── Faixa 4: DispositionAgent ─────────────────────────────────────────
    getDispositionAgent: protectedProcedure
      .input(
        z.object({
          sessionIds: z.array(z.number()).optional(),
          supervisor: z.string().optional(),
          tabulacao: z.string().optional(),
          minTempoSeg: z.number().optional(), // filtro: tempo mínimo em segundos
          minChamadas: z.number().optional(), // filtro: mínimo de chamadas
        })
      )
      .query(async ({ input }) => {
        let rows = await getDispositionAgentRecords({
          sessionIds: input.sessionIds,
          supervisor: input.supervisor,
        });

        // Lista de opções do filtro — vem de ANTES de aplicar o próprio
        // filtro de tabulação, senão o dropdown encolheria pra só a opção
        // já selecionada.
        const tabulacoesDisponiveis = Array.from(
          new Set(rows.map(r => r.tabulacao || "Sem tabulação"))
        ).sort();

        // Filtro de tabulação aplicado ANTES de agregar — afeta as 3 abas
        // (Ranking Unificado, Por Agente, Por Supervisor) de forma
        // consistente, não só uma delas.
        if (input.tabulacao) {
          rows = rows.filter(
            r => (r.tabulacao || "Sem tabulação") === input.tabulacao
          );
        }

        // Métrica principal: ocorrências (cada linha = 1 tabulação excedida)
        const byAgente: Record<
          string,
          {
            agente: string;
            supervisor: string;
            ocorrencias: number;
            totalSegundos: number;
            totalChamadas: number;
          }
        > = {};
        const bySupervisor: Record<
          string,
          {
            supervisor: string;
            ocorrencias: number;
            totalSegundos: number;
            totalChamadas: number;
            agentesSet: Set<string>;
          }
        > = {};
        // Por agente+tabulação para ranking unificado (excedidas + tempo segurado)
        const byAgenteTab: Record<
          string,
          {
            agente: string;
            supervisor: string;
            tabulacao: string;
            ocorrencias: number;
            totalSegundos: number;
            totalChamadas: number;
          }
        > = {};

        for (const row of rows) {
          const agente = row.agente || "Desconhecido";
          const supervisor = row.nomeSupervisor || "Sem supervisor";
          const segundos = timeToSeconds(row.tempoTabulacao);
          const tabulacao = row.tabulacao || "Sem tabulação";

          if (!byAgente[agente])
            byAgente[agente] = {
              agente,
              supervisor,
              ocorrencias: 0,
              totalSegundos: 0,
              totalChamadas: 0,
            };
          byAgente[agente].ocorrencias += 1;
          byAgente[agente].totalSegundos += segundos;
          byAgente[agente].totalChamadas += row.totalChamadas || 0;

          if (!bySupervisor[supervisor])
            bySupervisor[supervisor] = {
              supervisor,
              ocorrencias: 0,
              totalSegundos: 0,
              totalChamadas: 0,
              agentesSet: new Set(),
            };
          bySupervisor[supervisor].ocorrencias += 1;
          bySupervisor[supervisor].totalSegundos += segundos;
          bySupervisor[supervisor].totalChamadas += row.totalChamadas || 0;
          bySupervisor[supervisor].agentesSet.add(agente);

          // Por agente + tabulação
          const keyAT = `${agente}||${tabulacao}`;
          if (!byAgenteTab[keyAT])
            byAgenteTab[keyAT] = {
              agente,
              supervisor,
              tabulacao,
              ocorrencias: 0,
              totalSegundos: 0,
              totalChamadas: 0,
            };
          byAgenteTab[keyAT].ocorrencias += 1;
          byAgenteTab[keyAT].totalSegundos += segundos;
          byAgenteTab[keyAT].totalChamadas += row.totalChamadas || 0;
        }

        const secToHMS = (s: number) => {
          const h = Math.floor(s / 3600);
          const m = Math.floor((s % 3600) / 60);
          const sec = s % 60;
          return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
        };

        let agenteRanking = Object.values(byAgente)
          .map(a => ({ ...a, tempoFormatado: secToHMS(a.totalSegundos) }))
          .sort((a, b) => b.ocorrencias - a.ocorrencias);

        // Aplica filtros opcionais
        if (input.minTempoSeg)
          agenteRanking = agenteRanking.filter(
            a => a.totalSegundos >= (input.minTempoSeg ?? 0)
          );
        if (input.minChamadas)
          agenteRanking = agenteRanking.filter(
            a => a.totalChamadas >= (input.minChamadas ?? 0)
          );

        const supervisorRanking = Object.values(bySupervisor)
          .map(s => ({
            supervisor: s.supervisor,
            ocorrencias: s.ocorrencias,
            totalSegundos: s.totalSegundos,
            totalChamadas: s.totalChamadas,
            agentesCount: s.agentesSet.size,
            tempoFormatado: secToHMS(s.totalSegundos),
          }))
          .sort((a, b) => b.ocorrencias - a.ocorrencias)
          .slice(0, 10);

        // Ranking unificado por agente+tabulação (excedidas + tempo segurado)
        let agenteTabRanking = Object.values(byAgenteTab)
          .map(a => ({ ...a, tempoFormatado: secToHMS(a.totalSegundos) }))
          .sort((a, b) => b.ocorrencias - a.ocorrencias);
        if (input.minTempoSeg)
          agenteTabRanking = agenteTabRanking.filter(
            a => a.totalSegundos >= (input.minTempoSeg ?? 0)
          );
        if (input.minChamadas)
          agenteTabRanking = agenteTabRanking.filter(
            a => a.totalChamadas >= (input.minChamadas ?? 0)
          );

        return {
          rows,
          agenteRanking: agenteRanking.slice(0, 20),
          supervisorRanking,
          agenteTabRanking: agenteTabRanking.slice(0, 50),
          tabulacoesDisponiveis,
        };
      }),

    // ─── Cards de Resumo Executivo ─────────────────────────────────────────
    getSummary: protectedProcedure
      .input(z.object({ sessionIds: z.array(z.number()).optional() }))
      .query(async ({ input }) => {
        const [agentDayRows, reasonRows, dispositionRows, discagemDates] =
          await Promise.all([
            getAgentDayRecords({ sessionIds: input.sessionIds }),
            getReasonAgentRecords({ sessionIds: input.sessionIds }),
            getDispositionAgentRecords({ sessionIds: input.sessionIds }),
            getDiscagemReferenceDates(),
          ]);
        const discagemRows = discagemDates[0]
          ? await getDiscagemRecords({ referenceDate: discagemDates[0] })
          : [];

        const agentesLogados = Array.from(
          new Set(agentDayRows.map(r => r.agente).filter(Boolean))
        ).length;
        const totalChamadas = agentDayRows.reduce(
          (s, r) => s + (r.totalChamadas || 0),
          0
        );
        const totalContatos = agentDayRows.reduce(
          (s, r) => s + (r.totalContatos || 0),
          0
        );
        const totalPausas = reasonRows.reduce(
          (s, r) => s + (r.pausasTotalizadoPorCampanha || 0),
          0
        );
        const totalTabulacoesSucesso = agentDayRows.reduce(
          (s, r) => s + (r.tabulacoesSucesso || 0),
          0
        );
        const totalTabulacoesExcedidas = dispositionRows.reduce(
          (s, r) => s + (r.totalChamadas || 0),
          0
        );
        const totalCampanhas = new Set(
          discagemRows.map(r => r.campanha).filter(Boolean)
        ).size;

        return {
          agentesLogados,
          totalChamadas,
          totalContatos,
          totalPausas,
          totalTabulacoesSucesso,
          totalTabulacoesExcedidas,
          totalCampanhas,
        };
      }),

    // ─── Relatório Executivo Consolidado ─────────────────────────────────────
    // ─── Boletim Diário Consolidado — junta Baixa Produção + NR17 por
    // Supervisor + funil de Discagem num só lugar, pra exportar de uma vez
    // (reaproveita o seletor de datas e o export PNG/PDF do Executivo). ────
    getBoletimDiario: protectedProcedure
      .input(z.object({ sessionIds: z.array(z.number()).optional() }))
      .query(async ({ input }) => {
        const [
          agentRows,
          reasonRows,
          discagemRowsRaw,
          dimRows,
          settings,
          PAUSE_LIMITS,
        ] = await Promise.all([
          getAgentDayRecords({ sessionIds: input.sessionIds }),
          getReasonAgentRecords({ sessionIds: input.sessionIds }),
          input.sessionIds
            ? getDiscagemRecordsBySessionIds(input.sessionIds)
            : Promise.resolve([]),
          getDimensionamento({}),
          getAppSettings(["baixaProducao.tempoMinLogadoMin"]),
          getEffectivePauseLimits(),
        ]);
        const dimMap = buildDimMap(dimRows);
        function getSupervisor(agente: string): string {
          const nomeKey = agente.trim().toUpperCase();
          const loginKey = `LOGIN:${agente.trim().toLowerCase()}`;
          return (
            dimMap[nomeKey]?.supervisor ||
            dimMap[loginKey]?.supervisor ||
            "Sem supervisor"
          );
        }
        const tempoMinSeg =
          Number(settings["baixaProducao.tempoMinLogadoMin"] ?? 30) * 60;

        // Baixa Produção
        const humanRows = agentRows.filter(
          r => r.login && r.login.trim() !== ""
        );
        const elegiveis = humanRows.filter(
          r => timeToSeconds(r.tempoLogado) >= tempoMinSeg
        );
        const zerados = elegiveis.filter(r => (r.chamadasAtendidas ?? 0) === 0);
        const bySupBaixa = new Map<
          string,
          { total: number; zerados: number }
        >();
        for (const r of elegiveis) {
          const sup = getSupervisor(r.agente || "");
          const g = bySupBaixa.get(sup) || { total: 0, zerados: 0 };
          g.total += 1;
          if ((r.chamadasAtendidas ?? 0) === 0) g.zerados += 1;
          bySupBaixa.set(sup, g);
        }
        const baixaProducaoPorSupervisor = Array.from(bySupBaixa.entries())
          .map(([supervisor, g]) => ({
            supervisor,
            totalAgentes: g.total,
            zerados: g.zerados,
            pctZerados: g.total > 0 ? (g.zerados / g.total) * 100 : 0,
          }))
          .sort((a, b) => b.pctZerados - a.pctZerados)
          .slice(0, 10);

        // NR17 por supervisor
        const bySupNR17 = new Map<string, number>();
        for (const row of reasonRows) {
          const motivo = (row.motivoDePausa || "").toLowerCase().trim();
          const segundos = timeToSeconds(row.tempoTotalDePausa);
          for (const [key, limiteSeg] of Object.entries(PAUSE_LIMITS)) {
            if (motivo.includes(key) && segundos > limiteSeg) {
              const sup = getSupervisor(row.agente || "");
              bySupNR17.set(
                sup,
                (bySupNR17.get(sup) || 0) + (segundos - limiteSeg)
              );
              break;
            }
          }
        }
        const nr17PorSupervisor = Array.from(bySupNR17.entries())
          .map(([supervisor, excedidoSegundos]) => ({
            supervisor,
            excedidoSegundos,
          }))
          .sort((a, b) => b.excedidoSegundos - a.excedidoSegundos)
          .slice(0, 10);

        // Funil de discagem (usa o mesmo classificador da Performance por Campanha)
        let discagens = 0,
          atendidas = 0,
          cpc = 0,
          cpca = 0,
          promessa = 0;
        for (const r of discagemRowsRaw) {
          const flags = classifyDiscagem(r.status);
          discagens += r.quantidade;
          if (flags.atendida) atendidas += r.quantidade;
          if (flags.cpc) cpc += r.quantidade;
          if (flags.cpca) cpca += r.quantidade;
          if (flags.promessa) promessa += r.quantidade;
        }

        return {
          zeradosCount: zerados.length,
          totalElegiveis: elegiveis.length,
          baixaProducaoPorSupervisor,
          nr17PorSupervisor,
          funil: { discagens, atendidas, cpc, cpca, promessa },
        };
      }),

    getExecutiveReport: protectedProcedure
      .input(z.object({ sessionIds: z.array(z.number()).optional() }))
      .query(async ({ input }) => {
        const [agentDayRows, reasonRows, dispositionRows] = await Promise.all([
          getAgentDayRecords({ sessionIds: input.sessionIds }),
          getReasonAgentRecords({ sessionIds: input.sessionIds }),
          getDispositionAgentRecords({ sessionIds: input.sessionIds }),
        ]);

        // ── Faixa 1: Top/Bottom por chamadas atendidas (apenas agentes com login) ──
        const humanAgents = agentDayRows.filter(
          r => r.login && r.login.trim() !== ""
        );
        const sortedByChamadas = [...humanAgents].sort(
          (a, b) => (b.chamadasAtendidas ?? 0) - (a.chamadasAtendidas ?? 0)
        );
        const top5Chamadas = sortedByChamadas.slice(0, 5).map(r => ({
          agente: r.agente ?? "",
          valor: r.chamadasAtendidas ?? 0,
          detalhe: `CPC: ${r.contatoEfetivo ?? 0}`,
        }));
        // "Baixa Produtividade" = muitas chamadas/tentativas mas poucos acordos ou CPC
        // Métrica: chamadas atendidas >= mediana, mas CPC + acordos abaixo da mediana
        // Ordenado por: maior razão (chamadas / (cpc + acordos + 1)) — esforço sem resultado
        const agentsWithActivity = humanAgents.filter(
          r => (r.chamadasAtendidas ?? 0) >= 5
        );
        const bottom5Chamadas = [...agentsWithActivity]
          .map(r => {
            const chamadas = r.chamadasAtendidas ?? 0;
            const cpc = r.contatoEfetivo ?? 0;
            const acordos = (r as any).tabulacoesSucessoNegocio ?? 0;
            const resultado = cpc + acordos;
            const esforcoSemResultado = chamadas / (resultado + 1); // +1 evita divisão por zero
            return {
              r,
              chamadas,
              cpc,
              acordos,
              resultado,
              esforcoSemResultado,
            };
          })
          .sort((a, b) => b.esforcoSemResultado - a.esforcoSemResultado)
          .slice(0, 5)
          .map(({ r, chamadas, cpc, acordos }) => ({
            agente: r.agente ?? "",
            valor: chamadas,
            detalhe: `CPC: ${cpc} · Acordos: ${acordos}`,
          }));

        // ── Top 5 Suspeitos: alto CPC, baixo acordo (conversão suspeita) ──────────
        // Métrica: CPC >= 5 mas taxa de conversão CPC→Acordo muito baixa
        // Ordenado por: maior CPC com menor taxa de conversão
        const top5Suspeitos = [...humanAgents]
          .filter(r => (r.contatoEfetivo ?? 0) >= 5) // precisa ter CPC relevante
          .map(r => {
            const cpc = r.contatoEfetivo ?? 0;
            const acordos = (r as any).tabulacoesSucessoNegocio ?? 0;
            const taxaConversao = cpc > 0 ? (acordos / cpc) * 100 : 0;
            return { r, cpc, acordos, taxaConversao };
          })
          .sort((a, b) => {
            // Prioriza: mais CPC com menor conversão
            const scoreA = a.cpc * (1 - a.taxaConversao / 100);
            const scoreB = b.cpc * (1 - b.taxaConversao / 100);
            return scoreB - scoreA;
          })
          .slice(0, 5)
          .map(({ r, cpc, acordos, taxaConversao }) => ({
            agente: r.agente ?? "",
            valor: cpc,
            detalhe: `Acordos: ${acordos} · Conv: ${taxaConversao.toFixed(1)}%`,
          }));

        // ── Faixa 2: Top 5 por pausas improdutivas ──────────────────────────────
        function isImprodutiva(motivo: string): boolean {
          const m = motivo.toLowerCase().trim();
          if (m.includes("feedback")) return false;
          if (
            m.includes("erro de sistema") ||
            m.includes("erro sistema") ||
            m === "erro"
          )
            return false;
          if (m.includes("atendimento chat") || m === "chat") return false;
          return true;
        }
        const byAgenteImprod: Record<
          string,
          { agente: string; totalSegundos: number; totalPausas: number }
        > = {};
        for (const row of reasonRows) {
          const motivo = row.motivoDePausa || "";
          if (!isImprodutiva(motivo)) continue;
          const agente = row.agente || "Desconhecido";
          const seg = timeToSeconds(row.tempoTotalDePausa);
          const pausas = row.pausasTotalizadoPorCampanha || 0;
          if (!byAgenteImprod[agente])
            byAgenteImprod[agente] = {
              agente,
              totalSegundos: 0,
              totalPausas: 0,
            };
          byAgenteImprod[agente].totalSegundos += seg;
          byAgenteImprod[agente].totalPausas += pausas;
        }
        const secToHMS = (s: number) => {
          const h = Math.floor(s / 3600);
          const m = Math.floor((s % 3600) / 60);
          const sec = s % 60;
          return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
        };
        const top5Pausas = Object.values(byAgenteImprod)
          .sort((a, b) => b.totalSegundos - a.totalSegundos)
          .slice(0, 5)
          .map(r => ({
            agente: r.agente,
            valor: r.totalSegundos,
            detalhe: secToHMS(r.totalSegundos),
          }));

        // ── Faixa 4: Top 5 por tabulações excedidas ────────────────────────────
        // Agrega por agente com mesma lógica do getDispositionAgent
        const byAgenteDisp: Record<
          string,
          {
            agente: string;
            ocorrencias: number;
            totalSegundos: number;
            totalChamadas: number;
            supervisor: string;
          }
        > = {};
        for (const row of dispositionRows) {
          const agente = row.agente || "Desconhecido";
          const seg = timeToSeconds(row.tempoTabulacao);
          const chamadas = row.totalChamadas || 0;
          if (!byAgenteDisp[agente])
            byAgenteDisp[agente] = {
              agente,
              ocorrencias: 0,
              totalSegundos: 0,
              totalChamadas: 0,
              supervisor: row.nomeSupervisor || "",
            };
          byAgenteDisp[agente].ocorrencias += 1;
          byAgenteDisp[agente].totalSegundos += seg;
          byAgenteDisp[agente].totalChamadas += chamadas;
        }
        const totalTabulacoesExcedidasExec = Object.values(byAgenteDisp).reduce(
          (s, r) => s + r.ocorrencias,
          0
        );
        const top5Tabulacoes = Object.values(byAgenteDisp)
          .sort((a, b) => b.ocorrencias - a.ocorrencias)
          .slice(0, 5)
          .map(r => ({
            agente: r.agente,
            valor: r.ocorrencias,
            totalChamadas: r.totalChamadas,
            tempoTabulado: secToHMS(r.totalSegundos),
            supervisor: r.supervisor || "—",
          }));

        return {
          top5Chamadas,
          bottom5Chamadas,
          top5Pausas,
          top5Tabulacoes,
          totalTabulacoesExcedidas: totalTabulacoesExcedidasExec,
          top5Suspeitos,
        };
      }),

    // ─── Filtros disponíveis ───────────────────────────────────────────────
    // Todas as sessões de import (todos os tipos), com data de referência —
    // usado pelo Relatório Executivo pra montar o seletor de intervalo de dias.
    getAllSessions: protectedProcedure.query(async () => {
      const sessions = await getUploadSessions();
      return sessions.map(s => ({
        id: s.id,
        reportType: s.reportType,
        referenceDate: s.referenceDate,
      }));
    }),

    getFilters: protectedProcedure
      .input(z.object({ sessionIds: z.array(z.number()).optional() }))
      .query(async ({ input }) => {
        const [agentDayRows, dispositionRows, discagemDates] =
          await Promise.all([
            getAgentDayRecords({ sessionIds: input.sessionIds }),
            getDispositionAgentRecords({ sessionIds: input.sessionIds }),
            getDiscagemReferenceDates(),
          ]);
        const discagemRows = discagemDates[0]
          ? await getDiscagemRecords({ referenceDate: discagemDates[0] })
          : [];

        const agentes = Array.from(
          new Set(agentDayRows.map(r => r.agente).filter(Boolean))
        ).sort() as string[];
        const ufs = Array.from(
          new Set(agentDayRows.map(r => r.uf).filter(Boolean))
        ).sort() as string[];
        const campanhas = Array.from(
          new Set(discagemRows.map(r => r.campanha).filter(Boolean))
        ).sort() as string[];
        // Filtra supervisores: remove valores nulos, vazios e IDs numéricos
        const supervisores = Array.from(
          new Set(
            dispositionRows
              .map(r => r.nomeSupervisor)
              .filter(v => v && v.trim() && !/^\d+$/.test(v.trim()))
          )
        ).sort() as string[];

        return { agentes, ufs, campanhas, supervisores };
      }),

    // ─── Configuração de Limites de Pausa (NR17) ────────────────────────────
    // Antes hardcoded no código — agora editável em runtime. Motivo sem
    // override usa o padrão (isCustom: false); "resetar" = deletar o override.
    // ─── Resumo de alertas (sininho no menu) ───────────────────────────────
    // ─── Tendência histórica: % zerados e NR17 excedido por supervisor,
    // dia a dia — pra ver se é um dia ruim isolado ou um padrão. ────────────
    getTendenciaSupervisor: protectedProcedure
      .input(z.object({ dias: z.number().min(1).max(90).default(14) }))
      .query(async ({ input }) => {
        const [
          agentAllSessions,
          reasonAllSessions,
          dimRows,
          settings,
          PAUSE_LIMITS,
        ] = await Promise.all([
          getUploadSessions("AgentDay"),
          getUploadSessions("ReasonAgent"),
          getDimensionamento({}),
          getAppSettings(["baixaProducao.tempoMinLogadoMin"]),
          getEffectivePauseLimits(),
        ]);
        const dimMap = buildDimMap(dimRows);
        function getSupervisor(agente: string): string {
          const nomeKey = agente.trim().toUpperCase();
          const loginKey = `LOGIN:${agente.trim().toLowerCase()}`;
          return (
            dimMap[nomeKey]?.supervisor ||
            dimMap[loginKey]?.supervisor ||
            "Sem supervisor"
          );
        }
        const tempoMinSeg =
          Number(settings["baixaProducao.tempoMinLogadoMin"] ?? 30) * 60;

        // Últimas N datas com dado (união dos dois tipos de relatório)
        const datasSet = new Set([
          ...agentAllSessions.map(s => s.referenceDate),
          ...reasonAllSessions.map(s => s.referenceDate),
        ]);
        const datasOrdenadas = Array.from(datasSet)
          .filter((d): d is string => !!d)
          .sort((a, b) => {
            // DD/MM/AAAA -> comparável trocando pra AAAA-MM-DD
            const toIso = (s: string) => {
              const [dd, mm, yyyy] = s.split("/");
              return `${yyyy}-${mm}-${dd}`;
            };
            return toIso(a).localeCompare(toIso(b));
          })
          .slice(-input.dias);

        const porDia: {
          data: string;
          pctZeradosGeral: number;
          excedidoSegundosGeral: number;
          porSupervisor: {
            supervisor: string;
            pctZerados: number;
            excedidoSegundos: number;
          }[];
        }[] = [];

        for (const data of datasOrdenadas) {
          const agentSessionIds = agentAllSessions
            .filter(s => s.referenceDate === data)
            .map(s => s.id);
          const reasonSessionIds = reasonAllSessions
            .filter(s => s.referenceDate === data)
            .map(s => s.id);

          const [agentRows, reasonRows] = await Promise.all([
            agentSessionIds.length > 0
              ? getAgentDayRecords({ sessionIds: agentSessionIds })
              : Promise.resolve([]),
            reasonSessionIds.length > 0
              ? getReasonAgentRecords({ sessionIds: reasonSessionIds })
              : Promise.resolve([]),
          ]);

          const humanRows = agentRows.filter(
            r => r.login && r.login.trim() !== ""
          );
          const elegiveis = humanRows.filter(
            r => timeToSeconds(r.tempoLogado) >= tempoMinSeg
          );

          const bySupNaoAtendido = new Map<
            string,
            { total: number; zerados: number }
          >();
          for (const r of elegiveis) {
            const sup = getSupervisor(r.agente || "");
            const g = bySupNaoAtendido.get(sup) || { total: 0, zerados: 0 };
            g.total += 1;
            if ((r.chamadasAtendidas ?? 0) === 0) g.zerados += 1;
            bySupNaoAtendido.set(sup, g);
          }

          const bySupExcedido = new Map<string, number>();
          for (const row of reasonRows) {
            const motivo = (row.motivoDePausa || "").toLowerCase().trim();
            const segundos = timeToSeconds(row.tempoTotalDePausa);
            let limiteAchado: number | null = null;
            for (const [key, limiteSeg] of Object.entries(PAUSE_LIMITS)) {
              if (motivo.includes(key)) {
                limiteAchado = limiteSeg;
                break;
              }
            }
            if (limiteAchado !== null && segundos > limiteAchado) {
              const sup = getSupervisor(row.agente || "");
              bySupExcedido.set(
                sup,
                (bySupExcedido.get(sup) || 0) + (segundos - limiteAchado)
              );
            }
          }

          const supervisoresDoDia = new Set([
            ...Array.from(bySupNaoAtendido.keys()),
            ...Array.from(bySupExcedido.keys()),
          ]);
          const porSupervisor = Array.from(supervisoresDoDia).map(sup => {
            const nz = bySupNaoAtendido.get(sup);
            return {
              supervisor: sup,
              pctZerados:
                nz && nz.total > 0 ? (nz.zerados / nz.total) * 100 : 0,
              excedidoSegundos: bySupExcedido.get(sup) || 0,
            };
          });

          const totalElegiveis = elegiveis.length;
          const totalZerados = elegiveis.filter(
            r => (r.chamadasAtendidas ?? 0) === 0
          ).length;
          const totalExcedido = Array.from(bySupExcedido.values()).reduce(
            (s, v) => s + v,
            0
          );

          porDia.push({
            data,
            pctZeradosGeral:
              totalElegiveis > 0 ? (totalZerados / totalElegiveis) * 100 : 0,
            excedidoSegundosGeral: totalExcedido,
            porSupervisor,
          });
        }

        return { porDia };
      }),

    getAlertsSummary: protectedProcedure.query(async () => {
      const hoje = new Date().toLocaleDateString("pt-BR", {
        timeZone: "America/Sao_Paulo",
      });

      const [agentSessionsAll, reasonSessionsAll] = await Promise.all([
        getUploadSessions("AgentDay"),
        getUploadSessions("ReasonAgent"),
      ]);
      const agentSessions = agentSessionsAll.filter(
        s => s.referenceDate === hoje
      );
      const reasonSessions = reasonSessionsAll.filter(
        s => s.referenceDate === hoje
      );

      const [agentRows, reasonRows, settings] = await Promise.all([
        agentSessions.length > 0
          ? getAgentDayRecords({ sessionIds: agentSessions.map(s => s.id) })
          : Promise.resolve([]),
        reasonSessions.length > 0
          ? getReasonAgentRecords({
              sessionIds: reasonSessions.map(s => s.id),
            })
          : Promise.resolve([]),
        getAppSettings(["baixaProducao.tempoMinLogadoMin"]),
      ]);

      const tempoMinSeg =
        Number(settings["baixaProducao.tempoMinLogadoMin"] ?? 30) * 60;

      const humanRows = agentRows.filter(r => r.login && r.login.trim() !== "");
      const zerados = humanRows.filter(
        r =>
          timeToSeconds(r.tempoLogado) >= tempoMinSeg &&
          (r.chamadasAtendidas ?? 0) === 0
      );

      const PAUSE_LIMITS = await getEffectivePauseLimits();
      let pausasExcedidasCount = 0;
      for (const row of reasonRows) {
        const motivo = (row.motivoDePausa || "").toLowerCase().trim();
        const segundos = timeToSeconds(row.tempoTotalDePausa);
        for (const [key, limiteSeg] of Object.entries(PAUSE_LIMITS)) {
          if (motivo.includes(key) && segundos > limiteSeg) {
            pausasExcedidasCount += 1;
            break;
          }
        }
      }

      // Conformidade de horário — reaproveita discagem_records de hoje,
      // já sincronizado (sem chamada nova à OLOS aqui).
      let foraHorarioCount = 0;
      const discagemHojeSessions = (await getUploadSessions("Discagem")).filter(
        s => s.referenceDate === hoje
      );
      if (discagemHojeSessions.length > 0) {
        const discagemHoje = await getDiscagemRecords({ referenceDate: hoje });
        const diaSemanaHoje = new Date().getDay();
        for (const r of discagemHoje) {
          const hora = r.hora || "";
          const foraDaFaixa = hora !== "" && (hora < "08" || hora >= "20");
          if (diaSemanaHoje === 0 || foraDaFaixa)
            foraHorarioCount += r.quantidade;
        }
      }

      return {
        referenceDate: hoje,
        temDadosHoje: agentSessions.length > 0 || reasonSessions.length > 0,
        zeradosCount: zerados.length,
        zerados: zerados.slice(0, 15).map(r => ({
          agente: r.agente,
          tempoLogado: r.tempoLogado,
        })),
        pausasExcedidasCount,
        foraHorarioCount,
      };
    }),

    // ─── Configurações genéricas (chave/valor) ─────────────────────────────
    appSettings: router({
      get: protectedProcedure
        .input(z.object({ keys: z.array(z.string()) }))
        .query(async ({ input }) => {
          return getAppSettings(input.keys);
        }),
      set: protectedProcedure
        .input(z.object({ key: z.string().min(1), value: z.string() }))
        .mutation(async ({ input }) => {
          await setAppSetting(input.key, input.value);
          return { success: true };
        }),
    }),

    pauseLimits: router({
      list: protectedProcedure.query(async () => {
        const overrides = await getPauseLimits();
        const overrideMap = new Map(
          overrides.map(o => [o.motivo, o.limiteSegundos])
        );
        const allMotivos = new Set([
          ...Object.keys(DEFAULT_PAUSE_LIMITS),
          ...Array.from(overrideMap.keys()),
        ]);
        return Array.from(allMotivos)
          .sort()
          .map(motivo => ({
            motivo,
            limiteSegundos:
              overrideMap.get(motivo) ?? DEFAULT_PAUSE_LIMITS[motivo],
            limiteMin: Math.round(
              (overrideMap.get(motivo) ?? DEFAULT_PAUSE_LIMITS[motivo]) / 60
            ),
            isCustom: overrideMap.has(motivo),
            isDefault: motivo in DEFAULT_PAUSE_LIMITS,
          }));
      }),

      upsert: protectedProcedure
        .input(
          z.object({
            motivo: z.string().min(1),
            limiteMin: z.number().min(1).max(480),
          })
        )
        .mutation(async ({ input }) => {
          await upsertPauseLimit(
            input.motivo,
            Math.round(input.limiteMin * 60)
          );
          return { success: true };
        }),

      reset: protectedProcedure
        .input(z.object({ motivo: z.string().min(1) }))
        .mutation(async ({ input }) => {
          await deletePauseLimit(input.motivo);
          return { success: true };
        }),
    }),

    // ─── Discagem (dump TabAuto) — funil por campanha ──────────────────────
    getDiscagemAvailableDates: protectedProcedure.query(async () => {
      return getDiscagemReferenceDates();
    }),

    // Conformidade de horário — Lei do Superendividamento / práticas de
    // cobrança recomendam contato só entre 8h-20h, dias úteis (sem
    // domingo). Calculado inteiramente a partir de discagem_records que
    // JÁ está sincronizado (tem "hora" por linha) — não precisa de
    // nenhuma sincronização nova, nenhum acesso à OLOS aqui.
    getConformidadeHorario: protectedProcedure
      .input(z.object({ referenceDate: z.string().optional() }).optional())
      .query(async ({ input }) => {
        let referenceDate = input?.referenceDate;
        if (!referenceDate) {
          const dates = await getDiscagemReferenceDates();
          referenceDate = dates[0];
        }
        if (!referenceDate)
          return { referenceDate: null, ehDomingo: false, campanhas: [] };

        const records = await getDiscagemRecords({ referenceDate });

        const [dd, mm, yyyy] = referenceDate.split("/");
        const diaSemana = new Date(
          Number(yyyy),
          Number(mm) - 1,
          Number(dd)
        ).getDay();
        const ehDomingo = diaSemana === 0;

        type Acc = {
          organizacao: string;
          campanha: string;
          total: number;
          foraHorario: number;
          porHora: Record<string, number>;
        };
        const byCampanha = new Map<string, Acc>();

        for (const r of records) {
          const key = `${r.organizacao}|${r.campanha}`;
          const acc = byCampanha.get(key) || {
            organizacao: r.organizacao,
            campanha: r.campanha,
            total: 0,
            foraHorario: 0,
            porHora: {} as Record<string, number>,
          };
          acc.total += r.quantidade;
          const hora = r.hora || "";
          const foraDaFaixa = hora !== "" && (hora < "08" || hora >= "20");
          if (ehDomingo || foraDaFaixa) acc.foraHorario += r.quantidade;
          acc.porHora[hora] = (acc.porHora[hora] || 0) + r.quantidade;
          byCampanha.set(key, acc);
        }

        const campanhas = Array.from(byCampanha.values())
          .map(c => ({
            organizacao: c.organizacao,
            campanha: c.campanha,
            total: c.total,
            foraHorario: c.foraHorario,
            pctForaHorario: c.total > 0 ? (c.foraHorario / c.total) * 100 : 0,
          }))
          .filter(c => c.foraHorario > 0)
          .sort((a, b) => b.foraHorario - a.foraHorario);

        return { referenceDate, ehDomingo, campanhas };
      }),

    getDiscagemPorCampanha: protectedProcedure
      .input(z.object({ referenceDate: z.string().optional() }).optional())
      .query(async ({ input }) => {
        let referenceDate = input?.referenceDate;
        if (!referenceDate) {
          const dates = await getDiscagemReferenceDates();
          referenceDate = dates[0];
        }
        if (!referenceDate) return { referenceDate: null, campanhas: [] };

        const records = await getDiscagemRecords({ referenceDate });
        const mailingMap = await getCampanhaMailingMap();

        type Acc = {
          organizacao: string;
          campanha: string;
          discagens: number;
          atendidas: number;
          cpc: number;
          cpca: number;
          promessa: number;
          cpcaSemConversao: Record<string, number>;
        };
        const byCampanha = new Map<string, Acc>();

        for (const r of records) {
          const key = `${r.organizacao}|${r.campanha}`;
          const acc = byCampanha.get(key) || {
            organizacao: r.organizacao,
            campanha: r.campanha,
            discagens: 0,
            atendidas: 0,
            cpc: 0,
            cpca: 0,
            promessa: 0,
            cpcaSemConversao: {},
          };
          const flags = classifyDiscagem(r.status);
          acc.discagens += r.quantidade;
          if (flags.atendida) acc.atendidas += r.quantidade;
          if (flags.cpc) acc.cpc += r.quantidade;
          if (flags.cpca) acc.cpca += r.quantidade;
          if (flags.promessa) acc.promessa += r.quantidade;
          if (isCpcaSemConversao(r.status)) {
            acc.cpcaSemConversao[r.status] =
              (acc.cpcaSemConversao[r.status] || 0) + r.quantidade;
          }
          byCampanha.set(key, acc);
        }

        const pct = (num: number, den: number) =>
          den > 0 ? (num / den) * 100 : 0;

        const campanhas = Array.from(byCampanha.values())
          .map(c => {
            const mailing = mailingMap[c.campanha] ?? 0;
            const totalSemConversao = Object.values(c.cpcaSemConversao).reduce(
              (a, b) => a + b,
              0
            );
            return {
              organizacao: c.organizacao,
              campanha: c.campanha,
              mailing,
              spin: mailing > 0 ? c.discagens / mailing : null,
              discagens: c.discagens,
              atendidas: c.atendidas,
              pctAtendidas: pct(c.atendidas, c.discagens),
              cpc: c.cpc,
              pctCpc: pct(c.cpc, c.atendidas),
              cpca: c.cpca,
              pctCpca: pct(c.cpca, c.cpc),
              promessa: c.promessa,
              pctPromessa: pct(c.promessa, c.cpca),
              cpcaSemConversao: Object.entries(c.cpcaSemConversao)
                .map(([status, quantidade]) => ({
                  status,
                  quantidade,
                  pctRepresentatividade: pct(quantidade, totalSemConversao),
                }))
                .sort((a, b) => b.quantidade - a.quantidade),
            };
          })
          .sort((a, b) => b.discagens - a.discagens);

        return { referenceDate, campanhas };
      }),

    // ─── Qualidade Técnica (caixa postal, caiu/desligou, mudo) por dia ──────
    // Compara a produção entre dias: quanto da discagem "morreu" em ruído
    // técnico (não é simples não-atendimento, é sinal de rota/qualidade ruim).
    // ─── Ruído técnico por organização (dia mais recente) — usado pra
    // cruzar com Baixa Produção: agente zerado numa organização com ruído
    // alto pode ser rota ruim, não o agente. ────────────────────────────────
    getRuidoPorOrganizacaoHoje: protectedProcedure.query(async () => {
      const dates = await getDiscagemReferenceDates();
      if (dates.length === 0)
        return { referenceDate: null, porOrganizacao: [] };
      const records = await getDiscagemRecords({ referenceDate: dates[0] });

      const RUIDO_PATTERNS = [
        "no answer",
        "carrier message",
        "answering machine",
        "caixa postal",
        "caixa_postal",
        "caiu_desligou",
        "ligacao caiu",
        "queda",
        "mudo",
        "muda",
        "congestionamento",
        "busy",
        "fax",
        "silence",
      ];
      function isRuido(status: string): boolean {
        const s = status.toLowerCase();
        return RUIDO_PATTERNS.some(p => s.includes(p));
      }

      const byOrg: Record<string, { discagens: number; ruido: number }> = {};
      for (const r of records) {
        const org = r.organizacao || "Sem organização";
        if (!byOrg[org]) byOrg[org] = { discagens: 0, ruido: 0 };
        byOrg[org].discagens += r.quantidade;
        if (isRuido(r.status)) byOrg[org].ruido += r.quantidade;
      }

      const porOrganizacao = Object.entries(byOrg).map(([organizacao, v]) => ({
        organizacao,
        discagens: v.discagens,
        pctRuido: v.discagens > 0 ? (v.ruido / v.discagens) * 100 : 0,
      }));

      return { referenceDate: dates[0], porOrganizacao };
    }),

    getQualidadeTecnica: protectedProcedure
      .input(z.object({ organizacao: z.string().optional() }).optional())
      .query(async ({ input }) => {
        const dates = await getDiscagemReferenceDates();
        const porDia: {
          referenceDate: string;
          discagens: number;
          caixaPostal: number;
          caiuDesligou: number;
          mudo: number;
          outroRuido: number;
          totalRuido: number;
          pctRuido: number;
        }[] = [];

        // Rota só faz sentido pro dia mais recente (visão operacional do dia)
        const porRotaMaisRecente: Record<
          string,
          { discagens: number; totalRuido: number }
        > = {};

        for (let i = 0; i < dates.length; i++) {
          const date = dates[i];
          let records = await getDiscagemRecords({ referenceDate: date });
          if (input?.organizacao) {
            records = records.filter(r => r.organizacao === input.organizacao);
          }

          let discagens = 0;
          let caixaPostal = 0;
          let caiuDesligou = 0;
          let mudo = 0;
          let outroRuido = 0;

          for (const r of records) {
            discagens += r.quantidade;
            const cat = classifyQualidade(r.status);
            if (cat === "caixaPostal") caixaPostal += r.quantidade;
            else if (cat === "caiuDesligou") caiuDesligou += r.quantidade;
            else if (cat === "mudo") mudo += r.quantidade;
            else if (cat === "outroRuido") outroRuido += r.quantidade;

            if (i === 0) {
              const rota = r.rota || "Sem rota";
              const acc = porRotaMaisRecente[rota] || {
                discagens: 0,
                totalRuido: 0,
              };
              acc.discagens += r.quantidade;
              if (cat) acc.totalRuido += r.quantidade;
              porRotaMaisRecente[rota] = acc;
            }
          }

          const totalRuido = caixaPostal + caiuDesligou + mudo + outroRuido;
          porDia.push({
            referenceDate: date,
            discagens,
            caixaPostal,
            caiuDesligou,
            mudo,
            outroRuido,
            totalRuido,
            pctRuido: discagens > 0 ? (totalRuido / discagens) * 100 : 0,
          });
        }

        const porRota = Object.entries(porRotaMaisRecente)
          .map(([rota, v]) => ({
            rota,
            discagens: v.discagens,
            totalRuido: v.totalRuido,
            pctRuido: v.discagens > 0 ? (v.totalRuido / v.discagens) * 100 : 0,
          }))
          .sort((a, b) => b.pctRuido - a.pctRuido);

        // Ordena por data (mais recente primeiro, já que dates já vem assim)
        return { porDia, porRota, referenciaRota: dates[0] || null };
      }),

    campanhaMailing: router({
      list: protectedProcedure.query(async () => {
        return getCampanhaMailingMap();
      }),
      upsert: protectedProcedure
        .input(
          z.object({ campanha: z.string().min(1), mailing: z.number().min(0) })
        )
        .mutation(async ({ input }) => {
          await upsertCampanhaMailing(input.campanha, input.mailing);
          return { success: true };
        }),
    }),
  }),

  // ─── Dimensionamento ────────────────────────────────────────────────────────
  dimensionamento: router({
    list: protectedProcedure
      .input(
        z
          .object({
            celula: z.string().optional(),
            supervisor: z.string().optional(),
            turno: z.string().optional(),
            uf: z.string().optional(),
            status: z.string().optional(),
            search: z.string().optional(),
          })
          .optional()
      )
      .query(async ({ input }) => {
        return await getDimensionamento(input || {});
      }),

    stats: protectedProcedure.query(async () => {
      return await getDimensionamentoStats();
    }),

    create: protectedProcedure
      .input(
        z.object({
          nome: z.string().min(1),
          login: z.string().optional(),
          loginOlos: z.number().optional(),
          email: z.string().optional(),
          supervisor: z.string().optional(),
          admissao: z.string().optional(),
          nascimento: z.string().optional(),
          cpf: z.string().optional(),
          funcao: z.string().optional(),
          cargo: z.string().optional(),
          departamento: z.string().optional(),
          uf: z.string().optional(),
          status: z.string().optional(),
          discador: z.string().optional(),
          celula: z.string().optional(),
          skill: z.string().optional(),
          turno: z.string().optional(),
          escalaHora: z.string().optional(),
          escala: z.string().optional(),
          entrada: z.string().optional(),
          saida: z.string().optional(),
          entradaS: z.string().optional(),
          saidaS: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await insertDimensionamento(input);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().min(1).optional(),
          login: z.string().optional(),
          loginOlos: z.number().optional(),
          email: z.string().optional(),
          supervisor: z.string().optional(),
          admissao: z.string().optional(),
          nascimento: z.string().optional(),
          cpf: z.string().optional(),
          funcao: z.string().optional(),
          cargo: z.string().optional(),
          departamento: z.string().optional(),
          uf: z.string().optional(),
          status: z.string().optional(),
          discador: z.string().optional(),
          celula: z.string().optional(),
          skill: z.string().optional(),
          turno: z.string().optional(),
          escalaHora: z.string().optional(),
          escala: z.string().optional(),
          entrada: z.string().optional(),
          saida: z.string().optional(),
          entradaS: z.string().optional(),
          saidaS: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await updateDimensionamento(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteDimensionamento(input.id);
        return { success: true };
      }),
    // Sincronização automática: cruza AgentDay com Dimensionamento e adiciona quem já existe no banco
    syncAgentDay: protectedProcedure
      .input(z.object({ sessionIds: z.array(z.number()).optional() }))
      .mutation(async ({ input }) => {
        const { autoAdded, stillMissing } = await syncAgentesComDimensionamento(
          input.sessionIds
        );
        return {
          autoAdded,
          stillMissing,
          totalAutoAdded: autoAdded.length,
          totalStillMissing: stillMissing.length,
        };
      }),
    // Cruzamento: quem está no AgentDay mas não no Dimensionamento
    crossCheck: protectedProcedure
      .input(z.object({ sessionIds: z.array(z.number()).optional() }))
      .query(async ({ input }) => {
        const [agentRows, dimRows] = await Promise.all([
          getAgentDayRecords({ sessionIds: input.sessionIds }),
          getDimensionamento({}),
        ]);
        // Nomes normalizados do dimensionamento
        const dimNomes = new Set(
          dimRows.map(d => (d.nome || "").trim().toUpperCase())
        );
        const dimLogins = new Set(
          dimRows.map(d => (d.login || "").trim().toLowerCase()).filter(Boolean)
        );
        // Agentes únicos do AgentDay
        const agentesMap = new Map<
          string,
          { agente: string; login: string; campanha: string; uf: string }
        >();
        for (const row of agentRows) {
          const nome = (row.agente || "").trim();
          if (!nome) continue;
          if (!agentesMap.has(nome)) {
            agentesMap.set(nome, {
              agente: nome,
              login: row.login || "",
              campanha: row.produto || "",
              uf: row.uf || "",
            });
          }
        }
        // Filtrar quem não está no dimensionamento
        const naoNoDimensionamento = Array.from(agentesMap.values()).filter(
          a => {
            const nomeUp = a.agente.toUpperCase();
            const loginLow = a.login.toLowerCase();
            return (
              !dimNomes.has(nomeUp) && !(loginLow && dimLogins.has(loginLow))
            );
          }
        );
        return {
          totalAgentDay: agentesMap.size,
          totalDimensionamento: dimRows.length,
          naoNoDimensionamento,
        };
      }),
  }),
});
export type AppRouter = typeof appRouter;
