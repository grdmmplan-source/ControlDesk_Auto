import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getBookReferenceDates,
  getBookSheetTypesForDate,
  getBookRecords,
  getAllBookRecordsBySheetType,
  createBookUploadSession,
  insertBookRecords,
  getDiscagemRecords,
} from "../db";
import {
  parseBookReport,
  BOOK_SHEET_LABELS,
  type BookSheetType,
} from "../bookParser";

// mysql2/drizzle às vezes devolve a coluna JSON como string crua — normaliza
// pros dois casos (já objeto, ou string a parsear).
function normalizeDataField(raw: unknown): Record<string, string> {
  if (raw && typeof raw === "object") return raw as Record<string, string>;
  if (typeof raw === "string") {
    try {
      return JSON.parse(raw);
    } catch {
      return {};
    }
  }
  return {};
}

export const bookOperacionalRouter = router({
  processReport: protectedProcedure
    .input(z.object({ htmlContent: z.string(), fileName: z.string() }))
    .mutation(async ({ input }) => {
      const parsed = parseBookReport(input.htmlContent);
      if (parsed.rows.length === 0) {
        throw new Error(
          "Não encontrei nenhuma linha de dados válida nesse arquivo. Confira se colou o relatório certo."
        );
      }

      const session = await createBookUploadSession({
        sheetType: parsed.sheetType,
        fileName: input.fileName,
        referenceDate: parsed.referenceDate,
        totalRows: parsed.rows.length,
      });

      await insertBookRecords(
        session.id,
        parsed.sheetType,
        parsed.referenceDate,
        parsed.rows
      );

      return {
        success: true,
        sheetType: parsed.sheetType,
        sheetLabel: BOOK_SHEET_LABELS[parsed.sheetType],
        referenceDate: parsed.referenceDate,
        totalRows: parsed.rows.length,
      };
    }),

  getAvailableDates: protectedProcedure.query(async () => {
    return getBookReferenceDates();
  }),

  getSheetTypes: protectedProcedure
    .input(z.object({ referenceDate: z.string() }))
    .query(async ({ input }) => {
      const tipos = await getBookSheetTypesForDate(input.referenceDate);
      return tipos.map(t => ({
        sheetType: t,
        label: BOOK_SHEET_LABELS[t as BookSheetType] || t,
      }));
    }),

  getRecords: protectedProcedure
    .input(z.object({ referenceDate: z.string(), sheetType: z.string() }))
    .query(async ({ input }) => {
      const records = await getBookRecords(input);
      // Reconstrói a lista de colunas a partir da união de todas as linhas
      // (evita depender de uma única linha ter todas as colunas).
      const colunas = new Set<string>();
      for (const r of records) {
        for (const k of Object.keys(normalizeDataField(r.data))) {
          colunas.add(k);
        }
      }
      return {
        colunas: Array.from(colunas),
        linhas: records.map(r => ({
          id: r.id,
          agente: r.agente,
          login: r.login,
          campanha: r.campanha,
          motivo: r.motivo,
          data: normalizeDataField(r.data),
        })),
      };
    }),

  // ─── KPIs por agente/mês ─────────────────────────────────────────────────
  // Calculado a partir do BCampHC já importado, usando as fórmulas exatas
  // documentadas na aba "Índice" da planilha original — nada chutado.
  getKpisPorAgente: protectedProcedure.query(async () => {
    const raw = await getAllBookRecordsBySheetType("BCampHC");

    function toNumber(v: unknown): number {
      if (v === null || v === undefined) return 0;
      const s = String(v).trim();
      if (!s) return 0;
      // HH:MM:SS -> segundos
      const tempo = s.match(/^(\d{1,3}):(\d{2}):(\d{2})$/);
      if (tempo) {
        return (
          parseInt(tempo[1], 10) * 3600 +
          parseInt(tempo[2], 10) * 60 +
          parseInt(tempo[3], 10)
        );
      }
      const cleaned = s
        .replace(/\./g, "")
        .replace(/,(\d+)$/, ".$1")
        .replace(/[^\d.-]/g, "");
      const n = parseFloat(cleaned);
      return isNaN(n) ? 0 : n;
    }

    type Acc = {
      agente: string;
      campanha: string;
      anoMes: string;
      tentativas: number;
      atendidas: number;
      cpc: number;
      acordo: number;
      tempoLogado: number;
      tempoPausa: number;
      tempoOcioso: number;
      tempoFalando: number;
      tempoTabulacao: number;
      diasComDado: Set<string>;
    };
    const acc = new Map<string, Acc>();

    for (const r of raw) {
      const agente = r.agente || "—";
      const campanha = r.campanha || "Sem campanha";
      const d = normalizeDataField(r.data);
      // referenceDate no formato DD/MM/AAAA
      const m = r.referenceDate.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
      const anoMes = m ? `${m[3]}-${m[2]}` : r.referenceDate;
      const key = `${agente}|${campanha}|${anoMes}`;

      const entry = acc.get(key) || {
        agente,
        campanha,
        anoMes,
        tentativas: 0,
        atendidas: 0,
        cpc: 0,
        acordo: 0,
        tempoLogado: 0,
        tempoPausa: 0,
        tempoOcioso: 0,
        tempoFalando: 0,
        tempoTabulacao: 0,
        diasComDado: new Set<string>(),
      };

      entry.tentativas += toNumber(d["TOTAL DE TENTATIVAS (CHAMADAS)"]);
      entry.atendidas += toNumber(d["TOTAL DE ATENDIDAS NA P.A"]);
      entry.cpc += toNumber(d["CPC (TOTAL DE CONTATOS)"]);
      entry.acordo += toNumber(d["TABULAÇÕES SUCESSO NEGÓCIO"]);
      entry.tempoLogado += toNumber(d["TEMPO LOGADO"]);
      entry.tempoPausa += toNumber(d["TEMPO PAUSA"]);
      entry.tempoOcioso += toNumber(d["TEMPO OCIOSO"]);
      entry.tempoFalando += toNumber(d["TEMPO FALANDO"]);
      entry.tempoTabulacao += toNumber(d["TEMPO DE TABULAÇÃO"]);
      entry.diasComDado.add(r.referenceDate);

      acc.set(key, entry);
    }

    const div = (a: number, b: number) => (b > 0 ? a / b : 0);

    const linhasBase = Array.from(acc.values())
      .map(e => {
        const du = e.diasComDado.size;
        return {
          agente: e.agente,
          campanha: e.campanha,
          anoMes: e.anoMes,
          du,
          tentativas: e.tentativas,
          atendidas: e.atendidas,
          cpc: e.cpc,
          acordo: e.acordo,
          pctCpc: div(e.cpc, e.atendidas) * 100,
          pctAcordo: div(e.acordo, e.atendidas) * 100,
          pctAcordoCpc: div(e.acordo, e.cpc) * 100,
          pctAlo: div(e.atendidas, e.tentativas) * 100,
          esforcoDiscagem: div(e.tentativas, e.atendidas),
          tma: div(e.tempoFalando + e.tempoTabulacao, e.atendidas),
          tmo: div(e.tempoOcioso, e.atendidas),
          pctOcupacao:
            div(e.tempoTabulacao + e.tempoFalando, e.tempoLogado) * 100,
          pctPausa: div(e.tempoPausa, e.tempoLogado) * 100,
          pctIdle: div(e.tempoOcioso, e.tempoLogado) * 100,
          tempoProdutivo: e.tempoLogado - e.tempoPausa,
          atendDU: div(e.atendidas, du),
          cpcDU: div(e.cpc, du),
          acordoDU: div(e.acordo, du),
          // Campos brutos (segundos/contagem) — pra dar pra somar
          // corretamente entre agentes num mês (não dá pra fazer média de
          // %, tem que somar os brutos primeiro e só depois dividir nos
          // agregados mensais no frontend).
          tempoLogadoBruto: e.tempoLogado,
          tempoPausaBruto: e.tempoPausa,
          tempoOciosoBruto: e.tempoOcioso,
          tempoFalandoBruto: e.tempoFalando,
          tempoTabulacaoBruto: e.tempoTabulacao,
        };
      })
      .sort((a, b) => b.atendidas - a.atendidas);

    // Quartil por % Acordo, calculado dentro de cada mês (mín. 10 atendidas
    // pra entrar no ranking — evita quartil distorcido por volume baixo).
    const porMes = new Map<string, typeof linhasBase>();
    for (const l of linhasBase) {
      if (!porMes.has(l.anoMes)) porMes.set(l.anoMes, []);
      porMes.get(l.anoMes)!.push(l);
    }
    const quartilPorChave = new Map<string, "Q1" | "Q2" | "Q3" | "Q4" | null>();
    Array.from(porMes.values()).forEach(grupo => {
      const elegiveis = grupo
        .filter(l => l.atendidas >= 10)
        .sort((a, b) => b.pctAcordo - a.pctAcordo);
      const n = elegiveis.length;
      elegiveis.forEach((l, i) => {
        const pos = i / n; // 0 = melhor
        const q =
          pos < 0.25 ? "Q1" : pos < 0.5 ? "Q2" : pos < 0.75 ? "Q3" : "Q4";
        quartilPorChave.set(`${l.agente}|${l.campanha}|${l.anoMes}`, q);
      });
    });

    const linhas = linhasBase.map(l => ({
      ...l,
      quartil:
        quartilPorChave.get(`${l.agente}|${l.campanha}|${l.anoMes}`) ?? null,
    }));

    const campanhasDisponiveis = Array.from(
      new Set(linhas.map(l => l.campanha))
    ).sort();

    return {
      linhas,
      campanhasDisponiveis,
      totalRegistrosBrutos: raw.length,
    };
  }),

  // Comparativo por Organização × Mês — a organização não vem no relatório
  // BCampHC (só tem Agente x Campanha), então usa o mapeamento campanha ->
  // organização que já existe em discagem_records (vem certo da OLOS,
  // mais confiável que adivinhar pelo nome da campanha).
  getComparativoOrganizacao: protectedProcedure.query(async () => {
    const [raw, discagemRows] = await Promise.all([
      getAllBookRecordsBySheetType("BCampHC"),
      getDiscagemRecords({}),
    ]);

    const orgPorCampanha = new Map<string, string>();
    for (const d of discagemRows) {
      if (d.campanha && d.organizacao && !orgPorCampanha.has(d.campanha)) {
        orgPorCampanha.set(d.campanha, d.organizacao);
      }
    }

    function toNumber(v: unknown): number {
      if (v === null || v === undefined) return 0;
      const s = String(v).trim();
      if (!s) return 0;
      const cleaned = s
        .replace(/\./g, "")
        .replace(/,(\d+)$/, ".$1")
        .replace(/[^\d.-]/g, "");
      const n = parseFloat(cleaned);
      return isNaN(n) ? 0 : n;
    }

    type Acc = {
      organizacao: string;
      anoMes: string;
      tentativas: number;
      atendidas: number;
      cpc: number;
      acordo: number;
    };
    const acc = new Map<string, Acc>();

    for (const r of raw) {
      const d = normalizeDataField(r.data);
      const campanha = r.campanha || "Sem campanha";
      const organizacao = orgPorCampanha.get(campanha) || "Sem organização";
      const m = r.referenceDate.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
      const anoMes = m ? `${m[3]}-${m[2]}` : r.referenceDate;
      const key = `${organizacao}|${anoMes}`;

      const entry = acc.get(key) || {
        organizacao,
        anoMes,
        tentativas: 0,
        atendidas: 0,
        cpc: 0,
        acordo: 0,
      };
      entry.tentativas += toNumber(d["TOTAL DE TENTATIVAS (CHAMADAS)"]);
      entry.atendidas += toNumber(d["TOTAL DE ATENDIDAS NA P.A"]);
      entry.cpc += toNumber(d["CPC (TOTAL DE CONTATOS)"]);
      entry.acordo += toNumber(d["TABULAÇÕES SUCESSO NEGÓCIO"]);
      acc.set(key, entry);
    }

    const div = (a: number, b: number) => (b > 0 ? a / b : 0);
    const linhas = Array.from(acc.values())
      .map(e => ({
        ...e,
        pctAlo: div(e.atendidas, e.tentativas) * 100,
        pctCpc: div(e.cpc, e.atendidas) * 100,
        pctAcordo: div(e.acordo, e.atendidas) * 100,
      }))
      .sort(
        (a, b) =>
          a.organizacao.localeCompare(b.organizacao) ||
          a.anoMes.localeCompare(b.anoMes)
      );

    const organizacoesDisponiveis = Array.from(
      new Set(linhas.map(l => l.organizacao))
    ).sort();
    const mesesDisponiveis = Array.from(
      new Set(linhas.map(l => l.anoMes))
    ).sort();

    return { linhas, organizacoesDisponiveis, mesesDisponiveis };
  }),
});
