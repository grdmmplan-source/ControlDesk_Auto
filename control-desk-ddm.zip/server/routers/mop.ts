import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  listMopAlocacoes,
  createMopAlocacao,
  deleteMopAlocacao,
  getDimensionamento,
} from "../db";

export const mopRouter = router({
  getAlocacoes: protectedProcedure.query(async () => {
    return listMopAlocacoes();
  }),

  getOperadoresDisponiveis: protectedProcedure.query(async () => {
    const dim = await getDimensionamento({});
    return dim
      .filter(a => (a.status || "").toUpperCase() === "ATIVO")
      .map(a => ({
        nome: a.nome,
        login: a.login,
        celula: a.celula,
        supervisor: a.supervisor,
      }))
      .sort((a, b) => (a.nome || "").localeCompare(b.nome || ""));
  }),

  create: protectedProcedure
    .input(
      z.object({
        operadorNome: z.string().min(1),
        operadorLogin: z.string().nullable(),
        campanha: z.string().min(1),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const result = await createMopAlocacao({
        ...input,
        alocadoPor: ctx.user!.openId,
      });
      if (result.alreadyExists) {
        throw new Error("Esse operador já está alocado nessa campanha.");
      }
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteMopAlocacao(input.id);
      return { success: true };
    }),
});
