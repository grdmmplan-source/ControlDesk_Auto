import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { OLOS_SYNC_CONFIGURED } from "../_core/env";
import {
  testOlosConnection,
  syncDiscagemFromOlos,
  syncPausasFromOlos,
  syncAgentDayFromOlos,
  syncTabulacoesExcedidasFromOlos,
  syncMailingFromOlos,
  getLastSyncResult,
} from "../olosSync";

export const olosSyncRouter = router({
  getStatus: protectedProcedure.query(async () => {
    return {
      configured: OLOS_SYNC_CONFIGURED,
      lastSync: getLastSyncResult(),
    };
  }),

  testConnection: protectedProcedure.mutation(async () => {
    return testOlosConnection();
  }),

  syncDiscagemAgora: protectedProcedure
    .input(z.object({ referenceDate: z.string().optional() }).optional())
    .mutation(async ({ input }) => {
      return syncDiscagemFromOlos(input?.referenceDate);
    }),

  syncPausasAgora: protectedProcedure
    .input(z.object({ referenceDate: z.string().optional() }).optional())
    .mutation(async ({ input }) => {
      return syncPausasFromOlos(input?.referenceDate);
    }),

  syncAgentDayAgora: protectedProcedure
    .input(z.object({ referenceDate: z.string().optional() }).optional())
    .mutation(async ({ input }) => {
      return syncAgentDayFromOlos(input?.referenceDate);
    }),

  syncTabulacoesAgora: protectedProcedure
    .input(z.object({ referenceDate: z.string().optional() }).optional())
    .mutation(async ({ input }) => {
      return syncTabulacoesExcedidasFromOlos(input?.referenceDate);
    }),

  syncMailingAgora: protectedProcedure
    .input(z.object({ referenceDate: z.string().optional() }).optional())
    .mutation(async ({ input }) => {
      return syncMailingFromOlos(input?.referenceDate);
    }),
});
