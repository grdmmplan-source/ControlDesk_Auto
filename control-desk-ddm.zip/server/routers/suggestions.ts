import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  listSuggestions,
  createSuggestion,
  updateSuggestionStatus,
} from "../db";

export const suggestionsRouter = router({
  list: protectedProcedure.query(async () => {
    return listSuggestions();
  }),

  create: protectedProcedure
    .input(
      z.object({
        texto: z.string().min(3, "Escreve um pouco mais, por favor."),
        categoria: z.string().default("Geral"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await createSuggestion({
        userOpenId: ctx.user!.openId,
        userName: ctx.user!.name,
        categoria: input.categoria,
        texto: input.texto,
      });
      return { success: true };
    }),

  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["aberta", "em_analise", "concluida"]),
      })
    )
    .mutation(async ({ input }) => {
      await updateSuggestionStatus(input.id, input.status);
      return { success: true };
    }),
});
