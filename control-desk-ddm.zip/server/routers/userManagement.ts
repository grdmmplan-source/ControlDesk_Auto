import { z } from "zod";
import { adminProcedure, router } from "../_core/trpc";
import { listUsers, upsertUser, deleteUser, getUserByOpenId } from "../db";
import { hashPassword } from "../_core/auth";

// Gestão de usuários — só admin/control mexe aqui. Papel "user" no banco =
// Supervisor/Coordenador na UI (nav restrita); "admin" = Control/Analista
// de Planejamento (acesso total, sem mudança nenhuma pra quem já usa hoje).
export const userManagementRouter = router({
  list: adminProcedure.query(async () => {
    const users = await listUsers();
    return users.map(({ passwordHash, ...u }) => u);
  }),

  create: adminProcedure
    .input(
      z.object({
        openId: z.string().min(3).max(64),
        name: z.string().min(1).max(255),
        password: z.string().min(4),
        role: z.enum(["user", "admin"]),
        carteiraResponsavel: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const openId = input.openId.trim().toLowerCase();
      const existing = await getUserByOpenId(openId);
      if (existing) {
        throw new Error("Já existe um usuário com esse login.");
      }
      const passwordHash = await hashPassword(input.password);
      await upsertUser({
        openId,
        name: input.name,
        passwordHash,
        role: input.role,
        carteiraResponsavel: input.carteiraResponsavel || null,
      });
      return { success: true };
    }),

  update: adminProcedure
    .input(
      z.object({
        openId: z.string(),
        name: z.string().min(1).max(255).optional(),
        password: z.string().min(4).optional(),
        role: z.enum(["user", "admin"]).optional(),
        carteiraResponsavel: z.string().nullable().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const existing = await getUserByOpenId(input.openId);
      if (!existing) {
        throw new Error("Usuário não encontrado.");
      }
      const passwordHash = input.password
        ? await hashPassword(input.password)
        : undefined;
      await upsertUser({
        openId: input.openId,
        name: input.name,
        passwordHash,
        role: input.role,
        carteiraResponsavel: input.carteiraResponsavel,
      });
      return { success: true };
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteUser(input.id);
      return { success: true };
    }),
});
