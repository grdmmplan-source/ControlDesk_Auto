/**
 * Rota Express: POST /api/upload-book-xlsb
 * Recebe o arquivo .xlsb original do Book Operacional (várias abas, meses
 * de histórico) e importa todas as abas conhecidas (B1, B2, B3, B4,
 * BCampHC, BCamp, B-abs) de uma vez, agrupando cada linha pela sua própria
 * data — não pela data do arquivo. Isolado de tudo mais (mesma regra do
 * import diário do Book).
 */
import { Express } from "express";
import multer from "multer";
import * as XLSX from "xlsx";
import { bulkReplaceBookRecords } from "./db";
import { authenticateRequest } from "./_core/auth";
import { BOOK_XLSB_SHEETS, parseBookXlsbSheet } from "./bookParser";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 200 * 1024 * 1024 },
});

export function registerUploadBookXlsb(app: Express) {
  app.post(
    "/api/upload-book-xlsb",
    (req, res, next) => {
      upload.single("file")(req, res, (err: any) => {
        if (err) {
          console.error("[upload-book-xlsb] erro no multer:", err);
          if (err.code === "LIMIT_FILE_SIZE") {
            res
              .status(413)
              .json({ error: "Arquivo maior que o limite permitido (200MB)." });
            return;
          }
          res
            .status(400)
            .json({
              error: err.message || "Erro ao processar o arquivo enviado.",
            });
          return;
        }
        next();
      });
    },
    async (req, res) => {
      try {
        const user = await authenticateRequest(req).catch(() => null);
        if (!user) {
          res.status(401).json({ error: "Faça login para importar o Book." });
          return;
        }

        if (!req.file) {
          res.status(400).json({ error: "Nenhum arquivo enviado." });
          return;
        }

        const wb = XLSX.read(req.file.buffer, { type: "buffer" });

        const resultados: {
          sheetType: string;
          totalRows: number;
          datas: number;
          semData: number;
        }[] = [];
        const naoEncontradas: string[] = [];

        for (const sheetName of Object.keys(BOOK_XLSB_SHEETS)) {
          const ws = wb.Sheets[sheetName];
          if (!ws) {
            naoEncontradas.push(sheetName);
            continue;
          }
          const rawRows: any[][] = XLSX.utils.sheet_to_json(ws, {
            header: 1,
            raw: false,
            defval: "",
          });
          const parsed = parseBookXlsbSheet(sheetName, rawRows);
          if (!parsed || parsed.totalRows === 0) continue;

          const { datas, totalInserted } = await bulkReplaceBookRecords(
            parsed.sheetType,
            req.file.originalname,
            parsed.porData
          );

          resultados.push({
            sheetType: parsed.sheetType,
            totalRows: totalInserted,
            datas,
            semData: parsed.semData,
          });
        }

        if (resultados.length === 0) {
          res.status(400).json({
            error:
              "Nenhuma aba reconhecida encontrada no arquivo (esperado: B1, B2, B3, B4, BCampHC, BCamp, B-abs).",
          });
          return;
        }

        res.json({ success: true, resultados, naoEncontradas });
      } catch (error: any) {
        console.error("[upload-book-xlsb] erro:", error);
        res
          .status(500)
          .json({ error: error?.message || "Erro ao processar o arquivo." });
      }
    }
  );
}
