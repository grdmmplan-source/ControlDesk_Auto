/**
 * Rota Express: POST /api/upload-discagem
 * Recebe o dump "TabAuto" (.txt, pipe-delimited, um dial por linha) e agrega
 * em memória por (organizacao, campanha, rota, hora, status) antes de gravar
 * — o dump bruto tem centenas de milhares de linhas por dia, o agregado fica
 * na casa de 1-2 mil linhas. Ver server/discagemClassifier.ts pra régua do funil.
 */
import { Express } from "express";
import multer from "multer";
import { createUploadSession, insertDiscagemRecords } from "./db";
import { authenticateRequest } from "./_core/auth";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 500 * 1024 * 1024 },
});

const EXPECTED_HEADER = [
  "DataHora",
  "Organizacao",
  "Campanha",
  "IdCLiente",
  "CPF",
  "DDD",
  "Telefone",
  "Status",
  "DispositionId",
  "Rota",
  "Carteira",
];

function extractReferenceDate(firstDataHora: string | undefined): string {
  // "2026-08-28 08:00:16" -> "28/08/2026" (mesmo formato usado nas outras sessões)
  if (firstDataHora) {
    const m = firstDataHora.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  }
  return new Date().toLocaleDateString("pt-BR");
}

export function registerUploadDiscagem(app: Express) {
  app.post(
    "/api/upload-discagem",
    (req, res, next) => {
      upload.single("file")(req, res, (err: any) => {
        if (err) {
          console.error("[upload-discagem] erro no multer:", err);
          if (err.code === "LIMIT_FILE_SIZE") {
            res.status(413).json({
              error: "Arquivo maior que o limite permitido (500MB).",
            });
            return;
          }
          res
            .status(400)
            .json({
              error: err.message || "Erro ao processar o arquivo enviado.",
            });
          return;
        }
        next();
      });
    },
    async (req, res) => {
      try {
        const user = await authenticateRequest(req).catch(() => null);
        if (!user) {
          res
            .status(401)
            .json({ error: "Faça login para importar o dump de discagem." });
          return;
        }

        if (!req.file) {
          res.status(400).json({ error: "Nenhum arquivo enviado." });
          return;
        }

        const text = req.file.buffer.toString("utf-8");
        // Aceita tanto \r\n quanto \n
        const lines = text.split(/\r?\n/);
        if (lines.length < 2) {
          res.status(400).json({ error: "Arquivo vazio ou sem dados." });
          return;
        }

        const header = lines[0].split("|").map(h => h.trim());
        const missingCols = EXPECTED_HEADER.filter(h => !header.includes(h));
        if (missingCols.length > 0) {
          res.status(400).json({
            error: `Cabeçalho não reconhecido. Colunas esperadas ausentes: ${missingCols.join(", ")}.`,
          });
          return;
        }

        const idx = {
          dataHora: header.indexOf("DataHora"),
          organizacao: header.indexOf("Organizacao"),
          campanha: header.indexOf("Campanha"),
          status: header.indexOf("Status"),
          rota: header.indexOf("Rota"),
          carteira: header.indexOf("Carteira"),
        };

        type Key = string;
        const groups = new Map<
          Key,
          {
            organizacao: string;
            campanha: string;
            rota: string;
            hora: string;
            status: string;
            quantidade: number;
          }
        >();

        let firstDataHora: string | undefined;
        let totalRows = 0;
        let skipped = 0;

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i];
          if (!line) continue;
          const parts = line.split("|");
          if (parts.length < header.length) {
            skipped++;
            continue;
          }
          const dataHora = parts[idx.dataHora];
          const organizacao = parts[idx.organizacao]?.trim() || "";
          const campanha = parts[idx.campanha]?.trim() || "";
          const status = parts[idx.status]?.trim() || "";
          const rota = parts[idx.rota]?.trim() || "";
          if (!organizacao || !campanha || !status) {
            skipped++;
            continue;
          }
          if (!firstDataHora) firstDataHora = dataHora;
          const hora = dataHora?.slice(11, 13) || "";

          const key = `${organizacao}|${campanha}|${rota}|${hora}|${status}`;
          const g = groups.get(key);
          if (g) {
            g.quantidade++;
          } else {
            groups.set(key, {
              organizacao,
              campanha,
              rota,
              hora,
              status,
              quantidade: 1,
            });
          }
          totalRows++;
        }

        if (totalRows === 0) {
          res
            .status(400)
            .json({ error: "Nenhuma linha válida encontrada no arquivo." });
          return;
        }

        const referenceDate = extractReferenceDate(firstDataHora);

        const session = await createUploadSession({
          reportType: "Discagem",
          fileName: req.file.originalname,
          referenceDate,
          totalRows,
        });

        const rows = Array.from(groups.values()).map(g => ({
          sessionId: session.id,
          referenceDate,
          organizacao: g.organizacao,
          campanha: g.campanha,
          rota: g.rota || null,
          hora: g.hora || null,
          status: g.status,
          quantidade: g.quantidade,
        }));

        await insertDiscagemRecords(rows);

        res.json({
          success: true,
          sessionId: session.id,
          referenceDate,
          totalRows,
          aggregatedRows: rows.length,
          skipped,
        });
      } catch (error: any) {
        console.error("[upload-discagem] erro:", error);
        res
          .status(500)
          .json({ error: error?.message || "Erro ao processar o arquivo." });
      }
    }
  );
}
